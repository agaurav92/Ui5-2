sap.ui.define([
	"FIM/FIM/test/unit/controller/Root.controller"
], function () {
	"use strict";
});