sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"../Util/OdataHelper",
	"../Util/Constants",
	"../Util/Utility"
], function (BaseController, MessageBox, JSONModel, Filter, MessageToast, Fragment, ODataHelper, Constants, Utility) {
	"use strict";

	return BaseController.extend("FIM.FIM.controller.GLExtend", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf FIM.FIM.view.GLExtend
		 */
		onInit: function () {
			//Initialize busy indicator
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			this.oGlobalBusyDialog.open();
			// // Router login
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteGLExtend").attachMatched(this._onRouteFound, this);
			//populate tax category
			this._populateTaxCat();
			// this._odatareadset(Constants.VALUEHELP_SRV_URL, "/TaxCatSet", "TaxCatModel", "msg.err.TaxCatFetchError");
			//populate sort key
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/SortingKeySet", "SortKeyModel", "msg.err.SortKeyFetchError");
			// this._loadBSValue();
			//combinedModel
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/BSCombinedSet", "directModel", "msg.err.DirectorFetchError");
			this.oGlobalBusyDialog.close();
		},
		_onRouteFound: function (oEvt) {
			var oArgument = oEvt.getParameter("arguments");
			//Initialize and bind input elements
			var oModel = new JSONModel();
			var oFilter = [];
			if ((oArgument.SelectItem === Constants.EDITREQUEST)) {
				oModel.setData({
					"EditFields": true,
					"EditGLField": true,
					"EditRefFields": true,
					"BSVisible": false,
					"Openitem": true,
					"REVVisible": false,
					"PLVisible": false
				});
				oFilter.push(new sap.ui.model.Filter("GlCheckbox", "EQ", "YES"));
			} else {
				oModel.setData({
					"EditFields": false,
					"EditGLField": false,
					"EditRefFields": false,
					"BSVisible": true,
					"Openitem": true,
					"REVVisible": true,
					"PLVisible": true
				});
				oFilter.push(new sap.ui.model.Filter("GlCheckbox", "EQ", "SUB"));
			}
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/TCompCodeSet", "CompModel", "msg.err.CompFetchError", oFilter);
			this.getView().setModel(oModel, "EditModel");
			if (oArgument.SubReq !== undefined && oArgument.SubReq !== "") {
				var oGLSubModel = new JSONModel();
				oGLSubModel.setData({
					"data": {
						"FimReq": oArgument.request,
						"subreqno": oArgument.SubReq
					}
				});
				this.getView().setModel(oGLSubModel, "GLSubModel");
				//load existing data of the Subrequest which is already saved in the table
				this._loadsubrequest(oArgument.request, oArgument.SubReq, Constants.GL_SRV_URL);
			}
		},
		_loadsubrequest: function (request, subrequest, sURL) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			var oModel = new JSONModel();
			that.getView().setModel(oModel, "GLExtendModel");
			this.oGlobalBusyDialog.open();
			oDataModel.read("/GLItemSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')", {
				urlParameters: {
					"$expand": "GLItemToCCNav"
				},
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					oModel.setData({
						"Director": oData.Director,
						"GrpAccNum": oData.GrpAccNum,
						"Explanation": oData.Explanation,
						"TitleEn": oData.TitleEn,
						"TitleFr": oData.TitleFr,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
						"AccCurr": oData.AccCurr,
						"TaxCat": oData.TaxCat,
						"ReconAcTyp": oData.ReconAcTyp,
						"AltAcNo": oData.AltAcNo,
						"SortKey": oData.SortKey,
						"PlanningLevel": oData.PlanningLevel,
						"HouseBank": oData.HouseBank,
						"AccId": oData.AccId,
						"IntrestCalcFr": oData.IntrestCalcFr,
						"Notes": oData.Notes,
						"RefGlFlag": that.checkreference(oData.RefComp, oData.RefGl)
					});
					that.getView().byId("ip_glaccount").setValue(oData.GlNum);
					if (oData.AccType === Constants.PL) {
						that.getView().byId("ip_pltype").setValue(oData.PlAccType);
					}
					//chartgroup
					that.getView().byId("ip_chartgroup").setValue(oData.ChartGrp);
					that.getView().byId("ip_acctypebs").setValue(oData.AccType);
					that._loadcheckbox(oData, that);
					that.getView().byId("ip_refcomp").setValue(oData.RefComp);
					that.getView().byId("ip_refgl").setValue(oData.RefGl);
					var value = oData.GLItemToCCNav;
					that._loadCompTable(value, request, subrequest, that);
					that.getView().setModel(oModel, "GLExtendModel");
					that._setEditModel(oData.GlNum, oData.AccType, that);
					that._setEditRefModel(oData.RefGl, oData.RefComp, that);
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
				}
			});
		},
		_loadCompTable: function (value, request, subrequest, that) {
			var oFsgTableModel = new JSONModel();
			var companyCodeData = {};
			var items = [];
			if (value.results.length === 0) {
				companyCodeData = {
					"ItemNo": 1,
					"FimReq": request,
					"SubreqNo": subrequest,
					"CompCode": "",
					"FldStgrp": ""
				};
				items.push(companyCodeData);
			} else {
				for (var i = 0; i < value.results.length; i++) {
					companyCodeData = {
						"ItemNo": i + 1,
						"FimReq": request,
						"SubreqNo": subrequest,
						"CompCode": value.results[i].CompCode,
						"FldStgrp": value.results[i].FldStgrp
					};
					items.push(companyCodeData);
				}
			}
			oFsgTableModel.setProperty("/data", items);
			that.getView().byId("tbl_Fsg").setModel(oFsgTableModel, "FsgTableModel");
		},
		_setEditRefModel: function (RefGl, RefComp, that) {
			var oModel = that.getView().getModel("EditModel");
			if ((RefGl !== undefined && RefGl !== null && RefGl !== "") && (RefComp !== undefined && RefComp !== null && RefComp !== "")) {
				oModel.setProperty("/EditRefFields", false);
			} else {
				if (oModel.getData().EditFields === true) {
					oModel.setProperty("/EditRefFields", true);
				}
			}
			that.getView().setModel(oModel, "EditModel");
		},
		checkreference: function (RefComp, RefGl) {
			if ((RefGl !== undefined && RefGl !== null && RefGl !== "") && (RefComp !== undefined && RefComp !== null && RefComp !== "")) {
				return "X";
			} else {
				return "";
			}
		},
		_setEditModel: function (sSelectedGl, acctype, that) {
			var oModel = that.getView().getModel("EditModel");
			var oModModel = new JSONModel();
			if (acctype === Constants.BS) {
				oModel.setProperty("/BSVisible", true);
				oModel.setProperty("/PLVisible", false);
				//Belongs to PL so set it empty when value is changed
				that.getView().byId("ip_pltype").setValue("");
			} //PL account
			else if (acctype === Constants.PL) {
				oModel.setProperty("/PLVisible", true);
				oModel.setProperty("/BSVisible", false);
				that.getView().byId("ip_pltype").setValue(Constants.RE);
				//Belongs to BS so set it empty when value is changed
				that.getView().byId("cb_direct").setSelectedKey("");
			}
			if (sSelectedGl !== undefined && sSelectedGl !== null && sSelectedGl !== "") {
				oModel.setProperty("/EditGLField", false);
			}
			that._resetvaluestatus(that);
			that.getView().setModel(oModel, "EditModel");
		},
		_validateGlStart: function (sSelectedGl, that) {
			//BS
			if (sSelectedGl[0] === "1" || sSelectedGl[0] === "2" || sSelectedGl[0] === "3") {
				return Constants.BS;
			} //PL account
			else if (sSelectedGl[0] === "4" || sSelectedGl[0] === "6" || sSelectedGl[0] === "7") {
				return Constants.PL;
			}
		},
		onSubmitManualGl: function (oEvent) {
			var gl = this.getView().byId("ip_glaccount");
			if (!this._validateGl(gl, "msg.val.GlError", this)) {
				return;
			}
			this.oGlobalBusyDialog.open();
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			var setname = "/GLModifySet(GlNum='" + gl.getValue() + "',Category='" + Constants.GL + "')";
			oDataModel.read(setname, {
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						"Director": oData.Director,
						"GrpAccNum": oData.GrpAccNum,
						// "Explanation": oData.Explanation,
						"TitleEn": oData.TitleEn,
						"TitleFr": oData.TitleFr,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
						"AccCurr": oData.AccCurr,
						"TaxCat": oData.TaxCat,
						"ReconAcTyp": oData.ReconAcTyp,
						"AltAcNo": oData.AltAcNo,
						"SortKey": oData.SortKey,
						"PlanningLevel": oData.PlanningLevel,
						"HouseBank": oData.HouseBank,
						"AccId": oData.AccId,
						"IntrestCalcFr": oData.IntrestCalcFr,
						"Notes": oData.Notes,
					});
					if (oData.AccType === Constants.PL) {
						that.getView().byId("ip_pltype").setValue(oData.PlAccType);
					}
					//chartgroup
					that.getView().byId("ip_chartgroup").setValue(oData.ChartGrp);
					that.getView().byId("ip_acctypebs").setValue(oData.AccType);
					that._loadcheckbox(oData, that);
					var GLSubModel = that.getView().getModel("GLSubModel");
					that.getView().setModel(oModel, "GLExtendModel");
					that._setEditModel(oData.GlNum, oData.AccType, that);
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "GLExtendModel");
					gl.setValue("");
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				}
			});
		},
		onSelectComp: function (oEvent) {
			var oTableModel = this.getView().byId("tbl_Fsg").getModel("FsgTableModel");
			var rowid = oEvent.oSource.sId;
			var iRowIndex = rowid.split('-')[6]; //gets the rowindex from this value '__xmlview3--cb_comp-__xmlview3--tbl_Fsg-10'
			var value = oEvent.mParameters.value;
			if (value !== undefined && value !== null && value !== "") {
				if (!this.checkOnSelection(oEvent)) {
					return;
				}
			} else {
				this.getView().byId("cb_comp").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("cb_comp").setValueStateText("");
			}
			oTableModel.setProperty("/data/" + iRowIndex + "/FldStgrp", "");
			this.getView().byId("tbl_Fsg").setModel(oTableModel, "FsgTableModel");
		},
		onValidateCombo: function (oEvent) {
			var bValid = oEvent.getSource().getSelectedKey();
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (sComboId === "cb_direct") {
				if (!this.checkOnSelection(oEvent)) {
					this.getView().byId(sComboId).setSelectedKey("");
					return;
				}
			} else if (value !== "" && value !== " - BLANK") {
				if (!this.checkOnSelection(oEvent)) {
					return;
				}
			} else {
				this.getView().byId(sComboId).setValueState(sap.ui.core.ValueState.None);
				this.getView().byId(sComboId).setValueStateText("");
			}
		},
		onSubmitRef: function (oEvt) {
			var glnum = this.getView().byId("ip_glaccount");
			if (!this._validateGl(glnum, "msg.val.GlError", this)) {
				return false;
			}
			var refcompcode = this.getView().byId("ip_refcomp").getValue();
			var refgl = this.getView().byId("ip_refgl").getValue();
			var subModel = this.getView().getModel("GLSubModel");
			var oGLExtendModel = this.getView().getModel("GLExtendModel");
			//if both values are empty
			if ((refcompcode === undefined || refcompcode === null || refcompcode === "") &&
				(refgl === undefined || refgl === null || refgl === "")) {
				if (oGLExtendModel.getData().RefGlFlag === "X") {
					oGLExtendModel.setProperty("/RefGlFlag", "");
					this.getView().setModel(oGLExtendModel, "GLExtendModel");
					this._clearRefGlValues(subModel.getData().data.FimReq, subModel.getData().data.subreqno, this);
				}
				this.resetValueState(this.getView().byId("ip_refgl"));
				this.resetValueState(this.getView().byId("ip_refcomp"));
			}
			//If ref gl is entered without company code display error
			if (!this._validateRefGlComp(refgl, refcompcode, glnum, this)) {
				return false;
			}
			if (refcompcode !== undefined && refcompcode !== null && refcompcode !== "" && refgl !== undefined && refgl !== null && refgl !==
				"") {
				this.resetValueState(this.getView().byId("ip_refgl"));
				this.resetValueState(this.getView().byId("ip_refcomp"));
				var setname = "/GLReferenceSet(ImCc='" + refcompcode + "',ImGl='" + refgl + "')";
				var that = this;
				var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
				this.oGlobalBusyDialog.open();
				ODataHelper.callODataREAD(oDataModel, setname)
					.then(function onSuccess(oData, oResponse) {
						that.getView().byId("cb_currency").setSelectedKey(oData.ExAcurr);
						that.getView().byId("ip_altaccno").setValue(oData.ExAltacc);
						that.getView().byId("ip_planninglevel").setValue(oData.ExFdlev);
						that.getView().byId("ip_housebank").setValue(oData.ExHbkid);
						that.getView().byId("ip_accid").setValue(oData.ExHktid);
						that.getView().byId("cb_recon").setSelectedKey(oData.ExRecon);
						var oEditModel = that.getView().getModel("EditModel");
						oEditModel.setProperty("/EditRefFields", false);
						if ((oData.ExRecon === undefined || oData.ExRecon === null || oData.ExRecon === "") && oData.ExOpitm ===
							"X") {
							that.getView().byId("cb_openitem").setSelected(true);
							oEditModel.setProperty("/Openitem", true);
						} else if (oData.ExRecon !== undefined && oData.ExRecon !== null && oData.ExRecon !== "") {
							that.getView().byId("cb_openitem").setSelected(false);
							oEditModel.setProperty("/Openitem", false);
						}
						that.getView().setModel(oEditModel, "EditModel");
						if (oData.ExXgkon === "X") {
							that.getView().byId("cb_relevantcash").setSelected(true);
						} else {
							that.getView().byId("cb_relevantcash").setSelected(false);
						}
						if (oData.ExXkres === "X") {
							that.getView().byId("cb_lineitem").setSelected(true);
						} else {
							that.getView().byId("cb_lineitem").setSelected(false);
						}
						if (oData.ExXsalh === "X") {
							that.getView().byId("cb_balancelocal").setSelected(true);
						} else {
							that.getView().byId("cb_balancelocal").setSelected(false);
						}
						if (oData.ExXmwno === "X") {
							that.getView().byId("cb_withouttax").setSelected(true);
						} else {
							that.getView().byId("cb_withouttax").setSelected(false);
						}
						that.getView().byId("cb_taxcat").setSelectedKey(oData.ExTaxcat);
						that.getView().byId("ip_interestfreq").setValue(oData.ExZinrt);
						that.getView().byId("cb_sortkey").setSelectedKey(oData.ExZuawa);
						if (oData.ExFstag !== undefined && oData.ExFstag !== null && oData.ExFstag !== "") {
							var oFsgTableModel = new JSONModel();
							var compmodel = that.getView().getModel("CompModel").getData().data;
							var compcode;
							for (var i = 0; i < compmodel.length; i++) {
								if (compmodel[i]["CompCode"] === refcompcode) {
									compcode = refcompcode;
								}
							}
							oFsgTableModel.setData({
								"data": [{
									"ItemNo": 1,
									"FimReq": subModel.getData().data.FimReq,
									"SubreqNo": subModel.getData().data.subreqno,
									"CompCode": compcode,
									"FldStgrp": oData.ExFstag
								}]
							});
							that.getView().byId("tbl_Fsg").setModel(oFsgTableModel, "FsgTableModel");
						}
						that.getView().setModel(oEditModel, "EditModel");
						oGLExtendModel.setProperty("/RefGlFlag", "X");
						that.getView().setModel(oGLExtendModel, "GLExtendModel");
						that.oGlobalBusyDialog.close();
					})
					.catch(function onError(oError) {
						// MessageToast.show("Error while saving the request");
						that.getView().byId("ip_refcomp").setValue();
						that.getView().byId("ip_refgl").setValue();
						oGLExtendModel.setProperty("/RefGlFlag", "");
						that.getView().setModel(oGLExtendModel, "GLExtendModel");
						var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
						var sMsg = "";
						for (var i = 1; i < arr.length; i++) {
							sMsg = sMsg + '\n' + arr[i].message + '\n';
						}
						var msgTitle = that.getResourceBundleText("title.errorMessage");
						MessageBox.error(sMsg, {
							title: msgTitle, // default
							onClose: null, // default
							styleClass: "", // default
							actions: sap.m.MessageBox.Action.CLOSE, // default
							emphasizedAction: null, // default
							initialFocus: null, // default
							textDirection: sap.ui.core.TextDirection.Inherit // default
						});
						that.oGlobalBusyDialog.close();
						return;

					});
			}
		},
		onSubmitClearRef: function (oEvt) {
			var refgl = this.getView().byId("ip_refgl").getValue();
			var refcompcode = this.getView().byId("ip_refcomp").getValue();
			if ((refgl !== undefined && refgl !== null && refgl !== "") || (refcompcode !== undefined && refcompcode !== null && refcompcode !==
					"")) {
				var subModel = this.getView().getModel("GLSubModel");
				var oGLExtendModel = this.getView().getModel("GLExtendModel");
				oGLExtendModel.setProperty("/RefGlFlag", "");
				this.getView().setModel(oGLExtendModel, "GLExtendModel");
				this.getView().byId("ip_refcomp").setValue("");
				this.getView().byId("ip_refgl").setValue("");
				this._clearRefGlValues(subModel.getData().data.FimReq, subModel.getData().data.subreqno, this);
				this._setEditRefModel("", "", this);
			}
		},

		_validateRefGlComp: function (refgl, refcompcode, glnum, that) {
			var found = false;
			if ((refgl === undefined || refgl === "" || refgl === null) &&
				(refcompcode === undefined || refcompcode === "" || refcompcode === "")) {
				this.resetValueState(this.getView().byId("ip_refgl"));
				this.resetValueState(this.getView().byId("ip_refcomp"));
				return true;
			} else if (refcompcode === undefined || refcompcode === null || refcompcode === "") {
				that.getView().byId("ip_refcomp").setValueState(sap.ui.core.ValueState.Error);

				MessageToast.show(that.getMessageBundleText("msg.val.RefCompError"));
				return false;
			} else if (refgl === undefined || refgl === "" || refgl === null) {
				that.getView().byId("ip_refgl").setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText("msg.val.RefGlError"));
				return false;
			} else if (refgl !== undefined && refgl !== null && refgl !== "") {
				if (refgl.length !== 7) {
					that.getView().byId("ip_refgl").setValueState(sap.ui.core.ValueState.Error);

					MessageToast.show(that.getMessageBundleText("msg.val.RefGlError"));
					return false;
				} else {
					that.resetValueState(that.getView().byId("ip_refgl"));
					found = true;
				}
				var acctypegl = that._validateGlStart(glnum.getValue(), that);
				var acctyperef = that._validateGlStart(refgl, that);
				if (acctypegl !== acctyperef) {
					that.getView().byId("ip_refgl").setValueState(sap.ui.core.ValueState.Error);
					MessageToast.show(that.getMessageBundleText(("msg.val.RefGlAcctypeError"), [acctypegl]));
					return false;
				} else {
					this.resetValueState(that.getView().byId("ip_refgl"));
					found = true;
				}
			}
			that.resetValueState(that.getView().byId("ip_refcomp"));
			found = true;
			return found;
		},

		onAddNewRow: function (oEvent) {
			//Pass table id and model name
			var oGLSubModel = this.getView().getModel("GLSubModel");
			this._addNewRowGL(oEvent, "tbl_Fsg", "FsgTableModel", oGLSubModel.getData().data.FimReq, oGLSubModel.getData().data.subreqno);
		},
		onRemoveRow: function (oEvent) {
			this._removeRowGL(oEvent, "tbl_Fsg", "FsgTableModel");
		},
		onPressLoadFSG: function (oEvent) {
			var oView = this.getView();
			var fragmentSearchFSG = "FIM.FIM.view.fragment.SearchFSG";
			var oTableModel = this.getView().byId("tbl_Fsg").getModel("FsgTableModel");
			var rowid = oEvent.oSource.sId;
			var iRowIndex = rowid.split('-')[4];
			var sselectComp = oTableModel.getData().data[iRowIndex].CompCode;
			if (sselectComp !== undefined && sselectComp !== null && sselectComp !== "") {
				sap.ui.core.BusyIndicator.show(0);
				var DialogComp = new JSONModel;
				DialogComp.setData({
					"Comp": sselectComp,
					"rowindex": iRowIndex
				});
				this.getView().setModel(DialogComp, "DialogComp");
				var oFilter = [];
				oFilter.push(new sap.ui.model.Filter("Bukrs", "EQ", sselectComp));
				var that = this;
				var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
				ODataHelper.callODataREAD(oDataModel, "/GLFLDSTGRPSet", oFilter)
					.then(function onSuccess(oData, oResponse) {
						var oModel = new JSONModel();
						oModel.setData({
							data: oData.results
						});
						that.getView().setModel(oModel, "FsgModel");
						sap.ui.core.BusyIndicator.hide();
						if (!that.byId("dlg_searchfsg")) {
							Fragment.load({
								id: oView.getId(),
								name: fragmentSearchFSG,
								type: "XML",
								controller: that
							}).then(function (oDialog) {
								oView.addDependent(oDialog);
								oDialog.open();
							});
							that._oDialogSearchFSG = sap.ui.xmlfragment(fragmentSearchFSG, that);
						} else {
							that.byId("dlg_searchfsg").open();
						}
					})
					.catch(function onError(oError) {
						MessageToast.show(that.getMessageBundleText("msg.err.FsgFetchError"));
						sap.ui.core.BusyIndicator.hide();
					});
			}
		},
		onSelectSearchFSG: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var sSelected = oSelectedItem.getCells()[0].getText();
			var DialogComp = this.getView().getModel("DialogComp");
			var oTableModel = this.getView().byId("tbl_Fsg").getModel("FsgTableModel");
			if (typeof sSelected !== "undefined" && sSelected !== null && sSelected !== "") {
				oTableModel.setProperty("/data/" + DialogComp.getData().rowindex + "/FldStgrp", sSelected);
				this.getView().byId("tbl_Fsg").setModel(oTableModel, "FsgTableModel");
				this.byId("dlg_searchfsg").close();
			}
		},
		_clearF4FSG: function () {
			var oModel = new JSONModel();
			this.getView().setModel(oModel, "DialogComp");
			this.getView().setModel(oModel, "FsgModel");
		},
		onCloseF4FSG: function (oEvent) {
			this._clearF4FSG();
			this.byId("dlg_searchfsg").close();
		},
		onPressSaveExtend: function (oEvt) {
			if (!this._validateGl(this.getView().byId("ip_glaccount"), "msg.val.GlError", this)) {
				return false;
			}
			//Validate RefGl and RefComp code
			var refgl = this.getView().byId("ip_refgl").getValue();
			var refcompcode = this.getView().byId("ip_refcomp").getValue();
			if (!this._validateRefGlComp(refgl, refcompcode, this.getView().byId("ip_glaccount"), this)) {
				return false;
			}
			var oEntry = {};
			var oGLExtendModel = this.getView().getModel("GLExtendModel");
			var oGLSubModel = this.getView().getModel("GLSubModel");
			var that = this;
			if ((refgl !== undefined && refgl !== null && refgl !== "") && (refcompcode !== undefined && refcompcode !== null && refcompcode !==
					"") &&
				(oGLExtendModel.getData().RefGlFlag === "" || oGLExtendModel.getData().RefGlFlag === undefined || oGLExtendModel.getData().RefGlFlag ===
					null)) {
				//set the first tab as default
				that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
				that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
				that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
				var sMsg = that.getMessageBundleText("msg.val.RefValidationError");
				var msgTitle = that.getResourceBundleText("title.errorMessage");
				MessageBox.error(sMsg, {
					title: msgTitle, // default
					onClose: null, // default
					styleClass: "", // default
					actions: sap.m.MessageBox.Action.CLOSE, // default
					emphasizedAction: null, // default
					initialFocus: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
				return false;
			}

			oEntry.FimReq = oGLSubModel.getData().data.FimReq;
			oEntry.SubreqNo = oGLSubModel.getData().data.subreqno;
			oEntry.Actionid = Constants.EXTEND;
			oEntry.Category = Constants.GL;
			oEntry.GlNum = this.getView().byId("ip_glaccount").getValue();
			oEntry.ChartGrp = this.getView().byId("ip_chartgroup").getValue();
			oEntry.AccType = this.getView().byId("ip_acctypebs").getValue();
			oEntry.Coa = this.getView().byId("ip_chartacc").getValue();
			if (oEntry.AccType === Constants.PL) {
				oEntry.PlAccType = this.getView().byId("ip_pltype").getValue();
			}

			var oFsgTableModel = this.getView().byId("tbl_Fsg").getModel("FsgTableModel");
			var oTableList = oFsgTableModel.getProperty("/data");
			var oCompanyList = oTableList.map(function (obj) {
				return {
					FimReq: obj.FimReq,
					SubreqNo: obj.SubreqNo,
					CompCode: obj.CompCode,
					FldStgrp: obj.FldStgrp
				};
			});
			oEntry.GLItemToCCNav = oCompanyList;
			oEntry.Explanation = oGLExtendModel.getData().Explanation;
			oEntry.GrpAccNum = oGLExtendModel.getData().GrpAccNum;
			oEntry.TitleEn = oGLExtendModel.getData().TitleEn;
			oEntry.TitleFr = oGLExtendModel.getData().TitleFr;
			oEntry.LtextEn = oGLExtendModel.getData().LtextEn;
			oEntry.LtextFr = oGLExtendModel.getData().LtextFr;
			oEntry.DescEn = oGLExtendModel.getData().DescEn;
			oEntry.DescFr = oGLExtendModel.getData().DescFr;
			oEntry.Director = oGLExtendModel.getData().Director;
			oEntry.AccCurr = oGLExtendModel.getData().AccCurr;
			oEntry.TaxCat = oGLExtendModel.getData().TaxCat;
			oEntry.ReconAcTyp = oGLExtendModel.getData().ReconAcTyp;
			oEntry.AltAcNo = oGLExtendModel.getData().AltAcNo;
			oEntry.SortKey = oGLExtendModel.getData().SortKey;
			oEntry.PlanningLevel = oGLExtendModel.getData().PlanningLevel;
			oEntry.HouseBank = oGLExtendModel.getData().HouseBank;
			oEntry.AccId = oGLExtendModel.getData().AccId;
			oEntry.IntrestCalcFr = oGLExtendModel.getData().IntrestCalcFr;
			oEntry.Notes = oGLExtendModel.getData().Notes;
			oEntry.RefComp = this.getView().byId("ip_refcomp").getValue();
			oEntry.RefGl = this.getView().byId("ip_refgl").getValue();
			oEntry.PostingWta = " ";
			oEntry.BalLocCurr = " ";
			oEntry.OpenItemMt = " ";
			oEntry.LineItemDis = " ";
			oEntry.RelCashFlow = " ";
			//CheckBox
			if (this.getView().byId("cb_relevantcash").getSelected()) {
				oEntry.RelCashFlow = "X";
			}
			if (this.getView().byId("cb_lineitem").getSelected()) {
				oEntry.LineItemDis = "X";
			}
			if (this.getView().byId("cb_openitem").getSelected()) {
				if (oEntry.ReconAcTyp === undefined || oEntry.ReconAcTyp === null || oEntry.ReconAcTyp === "") {
					oEntry.OpenItemMt = "X";
				}
			}
			if (this.getView().byId("cb_balancelocal").getSelected()) {
				oEntry.BalLocCurr = "X";
			}
			if (this.getView().byId("cb_withouttax").getSelected()) {
				oEntry.PostingWta = "X";
			}
			// var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			ODataHelper.callODataCREATE(oDataModel, "/GLItemSet", oEntry)
				.then(function onSuccess(oResult, oResponse) {
					that.oGlobalBusyDialog.close();
					that._clearScreenValues(that);
					//Data submitted successfully!
					var msg = that.getMessageBundleText("msg.success.submitForm", [oGLSubModel.getData().data.subreqno]);
					//Show success message and return to 1st screen
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								that.onNavigateBack(oEvt, that, oGLSubModel.getData().data.FimReq, "RouteGLExtend");
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {
					// MessageToast.show("Error while saving the request");
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				});
		},
		_resetvaluestatus: function (that) {
			that.resetValueState(that.getView().byId("ip_refgl"));
			that.resetValueState(that.getView().byId("ip_refcomp"));
			that.resetValueState(that.getView().byId("ip_glaccount"));
			that.resetValueState(that.getView().byId("ip_groupac"));
			that.resetValueState(that.getView().byId("ip_explain"));
			//combo box
			that.resetValueState(that.getView().byId("cb_direct"));
			that.resetValueState(that.getView().byId("cb_recon"));
			that.resetValueState(that.getView().byId("cb_sortkey"));
			that.resetValueState(that.getView().byId("cb_currency"));
			that.resetValueState(that.getView().byId("cb_taxcat"));
			that.resetValueState(that.getView().byId("cb_comp"));
		},
		_clearScreenValues: function (that) {
			that._resetvaluestatus(that);
			var oModel = new JSONModel();
			that.getView().byId("ip_refgl").setValue("");
			that.getView().byId("ip_refcomp").setValue("");
			that.getView().byId("ip_glaccount").setValue("");
			that.getView().byId("ip_chartgroup").setValue("");
			that.getView().byId("ip_acctypebs").setValue("");
			that.getView().byId("cb_relevantcash").setSelected(false);
			that.getView().byId("cb_lineitem").setSelected(false);
			that.getView().byId("cb_openitem").setSelected(false);
			that.getView().byId("cb_balancelocal").setSelected(false);
			that.getView().byId("cb_withouttax").setSelected(false);
			that.getView().setModel(oModel, "GLExtendModel");
			var oEditModel = that.getView().getModel("EditModel");
			that.getView().byId("cb_openitem").setSelected(false);
			oEditModel.setProperty("/Openitem", true);
			that.getView().setModel(oEditModel, "EditModel");

			var GLSubModel = this.getView().getModel("GLSubModel");
			var oFsgTableModel = new JSONModel();
			oFsgTableModel.setData({
				"data": [{
					"ItemNo": 1,
					"FimReq": GLSubModel.getData().data.FimReq,
					"SubreqNo": GLSubModel.getData().data.subreqno,
					"CompCode": "",
					"FldStgrp": ""
				}]
			});
			this.getView().byId("tbl_Fsg").setModel(oFsgTableModel, "FsgTableModel");

			//set the first tab as default
			that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
			that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
			that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
		},
		_clearRefGlValues: function (request, subrequest, that) {
			that.getView().byId("cb_currency").setSelectedKey("");
			that.getView().byId("ip_altaccno").setValue("");
			that.getView().byId("ip_planninglevel").setValue("");
			that.getView().byId("ip_housebank").setValue("");
			that.getView().byId("ip_accid").setValue("");
			that.getView().byId("cb_recon").setSelectedKey("");
			that.getView().byId("cb_taxcat").setSelectedKey("");
			that.getView().byId("ip_interestfreq").setValue("");
			that.getView().byId("cb_sortkey").setSelectedKey("");

			that.getView().byId("cb_relevantcash").setSelected(false);
			that.getView().byId("cb_lineitem").setSelected(false);
			that.getView().byId("cb_balancelocal").setSelected(false);
			that.getView().byId("cb_withouttax").setSelected(false);
			//Edit model
			var oEditModel = that.getView().getModel("EditModel");
			that.getView().byId("cb_openitem").setSelected(false);
			oEditModel.setProperty("/Openitem", true);
			that.getView().setModel(oEditModel, "EditModel");

			// set the table for comp code and FSG empty
			var oFsgTableModel = new JSONModel();
			oFsgTableModel.setData({
				"data": [{
					"ItemNo": 1,
					"FimReq": request,
					"SubreqNo": subrequest,
					"CompCode": "",
					"FldStgrp": ""
				}]
			});
			that.getView().byId("tbl_Fsg").setModel(oFsgTableModel, "FsgTableModel");
		},
		onPressCancelExtend: function (oEvt) {
			this._clearScreenValues(this);
			var oModel = new JSONModel();
			oModel.setData({
				"EditFields": true,
				"EditGLField": true,
				"BSVisible": false,
				"Openitem": true,
				"REVVisible": false,
				"PLVisible": false
			});
			this.getView().setModel(oModel, "EditModel");
		},
		onPressDeleteSub: function (oEvt) {
			var GLSubModel = this.getView().getModel("GLSubModel");
			this._deleteSubRequest(GLSubModel.getData().data.FimReq, GLSubModel.getData().data.subreqno, oEvt, this);
		},
		onNavBack: function (oEvt) {
			var subModel = this.getView().getModel("GLSubModel");
			var request = subModel.getData().data.FimReq;
			this._clearScreenValues(this);
			this.onNavigateBack(oEvt, this, request, "RouteGLExtend");
		}
	});

});