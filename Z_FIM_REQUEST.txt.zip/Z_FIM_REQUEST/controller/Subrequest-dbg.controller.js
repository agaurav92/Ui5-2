sap.ui.define([
	"./BaseController",
	"../Util/Constants",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/format/DateFormat",
	"../Util/OdataHelper",
	"sap/m/MessageBox",
	"sap/f/library"
], function (BaseController, Constants, JSONModel, MessageToast, DateFormat, ODataHelper, MessageBox, fioriLibrary) {
	"use strict";
	return BaseController.extend("FIM.FIM.controller.Subrequest", {
		onInit: function () {
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			var oOwnerComponent = this.getOwnerComponent();
			this.oRouter = oOwnerComponent.getRouter();
			this.oModel = oOwnerComponent.getModel();
			this.oRouter.getRoute("request").attachPatternMatched(this._onSubrequestMatched, this);
			this.oRouter.getRoute("subrequest").attachMatched(this._onSubrequestMatched, this);
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/UserInfoSet", "UserModel", "msg.err.UserdetailsError");
		},
		_onSubrequestMatched: function (oEvt) {
			var that = this;

			var oArgument = oEvt.getParameter("arguments");
			var request = oArgument.request;
			//End of conctants
			if (request !== undefined && request !== null && request !== "") {
				var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
				this.oGlobalBusyDialog.open();
				oDataModel.read("/GLHeaderSet('" + request + "')", {
					urlParameters: {
						"$expand": "GLHeadToItemLandNav"
					},
					success: function onSuccess(oData, oResponse) {
						//Store Selection Screen Entries
						var Effdate = "";
						if (oData.Effdate !== undefined && oData.Effdate !== null) {
							Effdate = that._FormatDate(oData.Effdate);
						}
						var oSubModel = new JSONModel();
						var oModel = new JSONModel();
						//pass header data
						oModel.setData({
							"data": {
								"ReqNo": oData.FimReq,
								"CompName": oData.CompName,
								"Dept": oData.Dept,
								"Ernam": oData.Ernam,
								"Zname": oData.Zname,
								"Status": oData.Status,
								"Effdate": Effdate,
								"Erdat": that._FormatDate(new Date())
							}
						});
						var value = oData.GLHeadToItemLandNav;
						//Format data 
						var tDate = "";
						for (var i = 0; i < value.results.length; i++) {
							tDate = value.results[i].Erdat;
							if (tDate !== undefined && tDate !== null) {
								value.results[i].Erdat = that._FormatDate(tDate);
							}
						}
						oSubModel.setData({
							data: value.results
						});
						that.getView().setModel(oModel, "SubReqModel");
						that.getView().setModel(oSubModel, "SubModel");
						that.oGlobalBusyDialog.close();
					},
					error: function onError(oError) {
						that.oGlobalBusyDialog.close();
						MessageToast.show(that.getMessageBundleText("msg.err.SubRequestFetch", []));
					}
				});
			}
		},
		// getDateHelper: function (sDate) {
		// 	var fromDate = sDate;
		// 	var dformattedDate;
		// 	if (fromDate && typeof (fromDate) === "object") {
		// 		var finalDate = fromDate.getTime() - (fromDate.getTimezoneOffset() * 60 * 1000);
		// 		var fromDatefinal = new Date(finalDate);
		// 		var timeZone = fromDatefinal.toString().split(" ")[4];
		// 		var sCalMonth = fromDate.getMonth() + 1;
		// 		var sCalDate = fromDate.getDate();
		// 		if (sCalMonth < 10) {
		// 			sCalMonth = "0" + sCalMonth;
		// 		}

		// 		if (sCalDate < 10) {
		// 			sCalDate = "0" + fromDate.getDate();
		// 		}

		// 		// dformattedDate = fromDate.getFullYear() + "-" + sCalMonth + "-" + sCalDate + "T" + timeZone;
		// 		dformattedDate = fromDate.getFullYear() + "." + sCalMonth + "." + sCalDate;
		// 	} else {
		// 		dformattedDate = fromDate;
		// 	}
		// 	return dformattedDate;
		// },
		onCreateSubrequest: function (oEvent) {
			var oView = this.getView();
			var fragmentCreateSubrequest = "FIM.FIM.view.fragment.CreateSubrequest";
			if (!this.dlg_req) {
				this.dlg_req = this.loadFragment({
					name: fragmentCreateSubrequest
				});
				this.dlg_req.then(function (oDialog) {
					oDialog.open();
				});
			} else {
				this.byId("dlg_createsubrequest").open();
			}

		},
		onValidateCombo: function (oEvent) {
			var bValid = oEvent.getSource().getSelectedKey();
			var sId = oEvent.mParameters.id;
			// var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (!this.checkOnSelection(oEvent)) {
				this.getView().byId(sComboId).setSelectedKey("");
				return;
			} else {
				this.getView().byId(sComboId).setValueState(sap.ui.core.ValueState.None);
				this.getView().byId(sComboId).setValueStateText("");
				return;
			}
		},
		onCloseCreateSubrequest: function (oEvent) {
			this._clearCreateSubrequest();
			this.byId("dlg_createsubrequest").close();
		},
		_clearCreateSubrequest: function () {
			// this.getView().byId("ip_Subrequest").setValue("");
			this.getView().byId("cb_category").setSelectedKey("");
			this.getView().byId("cb_Object").setSelectedKey("");
			this.resetValueState(this.getView().byId("cb_category"));
			this.resetValueState(this.getView().byId("cb_Object"));
		},
		onSaveSubrequest: function (oEvent) {
			var oSubModel = this.getView().byId("tbl_subreq").getModel("SubModel");
			var SubReqModel = this.getView().getModel("SubReqModel");
			var that = this;
			var oEntry = {};
			oEntry.FimReq = SubReqModel.getData().data.ReqNo;
			oEntry.SubreqNo = "";
			oEntry.Category = this.getView().byId("cb_category").getSelectedKey();
			oEntry.Actionid = this.getView().byId("cb_Object").getSelectedKey();
			oEntry.Erdat = this.getView().byId("ip_Creationdate1").getValue();
			if (oEntry.Category !== Constants.RAC && oEntry.Category !== Constants.GL) {
				this.getView().byId("cb_category").setValueState(sap.ui.core.ValueState.Error);
				return false;
			}
			var SubReqGLModel = this.getView().getModel("SubReqGLModel").getData().data;
			if (!this.validateSuggestions(this.getView().byId("cb_Object"), oEntry.Actionid, "Object", SubReqGLModel, "")) {
				this.getView().byId("cb_Object").setValueState(sap.ui.core.ValueState.Error);
				return false;
			}
			oEntry.Erdat = this._correctDateFormat(oEntry.Erdat);
			this.oGlobalBusyDialog.open();
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			ODataHelper.callODataCREATE(oDataModel, "/GLItemSet", oEntry)
				.then(function onSuccess(oResult, oResponse) {
					//Scenario: Submission is successful.
					var items = oSubModel.getProperty("/data");
					var tDate = oResult.Erdat;
					var createdrequest = {
						"FimReq": oResult.FimReq,
						"SubreqNo": oResult.SubreqNo,
						"Category": oResult.Category,
						"Actionid": oResult.Actionid,
						"Erdat": that._FormatDate(tDate)
					};
					items.push(createdrequest);

					oSubModel.setProperty("/data", items);
					sap.ui.getCore().setModel(oSubModel, "SubModel");
					MessageToast.show(that.getMessageBundleText("msg.suc.SubRequestCreate", [oResult.SubreqNo]));

					that.oGlobalBusyDialog.close();
				})
				.catch(function onError(oError) {
					that.oGlobalBusyDialog.close();
					MessageToast.show(that.getMessageBundleText("msg.err.SubmitReqCreateError", []));
					return;
				});
			this._clearCreateSubrequest();
			this.byId("dlg_createsubrequest").close();
		},
		_ParseDate: function (sDate) {
			if (!sDate) {
				return sDate;
			}
			var sdateformat = DateFormat.getDateTimeInstance({
					pattern: "yyyy.MM.dd"
				},
				sap.ui.getCore().getConfiguration().getLocale());
			return sdateformat.parse(sDate); // parse to, for ex: Sat Aug 01 2020 00:00:00 <timezone information,ex:GMT-0400>
		},
		onSelectionChangeSub: function (oEvent) {
			var selectkey = oEvent.getSource().getSelectedKey();
			//everytime GL/RAC is selected empty the value populated in the object
			var userModel = this.getView().getModel("UserModel");
			var oModel = new JSONModel();
			if (selectkey === "GL") {
				if (userModel.oData.data[0].Admin === "X") {
					oModel.setData({
						"data": [{
							Object: Constants.CREATE
						}, {
							Object: Constants.MODIFY
						}, {
							Object: Constants.EXTEND
						}, {
							Object: Constants.BLOCK
						}, {
							Object: Constants.CANCEL
						}]
					});
				} else {
					oModel.setData({
						"data": [{
							Object: Constants.CREATE
						}, {
							Object: Constants.MODIFY
						}, {
							Object: Constants.EXTEND
						}, {
							Object: Constants.BLOCK
						}]
					});
				}
			} else if (selectkey === "RAC") {
				if (userModel.oData.data[0].Admin === "X") {
					oModel.setData({
						"data": [{
							Object: Constants.CREATE
						}, {
							Object: Constants.MODIFY
						}, {
							Object: Constants.CANCEL
						}]
					});
				} else {
					oModel.setData({
						"data": [{
							Object: Constants.CREATE
						}, {
							Object: Constants.MODIFY
						}]
					});
				}
			}
			this.getView().setModel(oModel, "SubReqGLModel");
		}, //OnselectionChange
		onSubmitRequest: function (oEvent) {
			var that = this;
			var oModel = this.getView().getModel("SubReqModel");
			var oSubModel = this.getView().getModel("SubModel");
			var sMsg = '';
			if (oSubModel === undefined) {
				var sMsg = this.getMessageBundleText("msg.err.NoSubReq", [oModel.getData().data.ReqNo]);

			} else if (oSubModel.getProperty("/data").length === 0) {
				var sMsg = this.getMessageBundleText("msg.err.NoSubReq", [oModel.getData().data.ReqNo]);
			}
			if (sMsg !== '') {
				var msgTitle = this.getResourceBundleText("title.errorMessage");
				MessageBox.error(sMsg, {
					title: msgTitle, // default
					onClose: null, // default
					styleClass: "", // default
					actions: sap.m.MessageBox.Action.CLOSE, // default
					emphasizedAction: null, // default
					initialFocus: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
				return;
			}
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			var setname = "/GLSubmitSet('" + oModel.getData().data.ReqNo + "')";
			this.oGlobalBusyDialog.open();
			ODataHelper.callODataREAD(oDataModel, setname)
				.then(function onSuccess(oData, oResponse) {
					that.oGlobalBusyDialog.close();
					that._closeSubRequest(that);
					var msg = that.getMessageBundleText("msg.suc.SubmitSuccess", [oModel.getData().data.ReqNo]);
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								return;
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {
					// MessageToast.show(that.getMessageBundleText("msg.err.SubmitRequestError", [oModel.getData().data.ReqNo]));
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				});
		},
		onSubRequestNavigate: function (oEvent) {
			var sPath = oEvent.getSource().getBindingContextPath(); //spath will return data/rowindex selected
			var iRowIndex = sPath.split('/')[2];
			var oSubReqModel = this.getView().byId("tbl_subreq").getModel("SubModel");
			var ReqModel = this.getView().getModel("SubReqModel");
			var request = ReqModel.getData().data.ReqNo;
			var subreq = oSubReqModel.getData().data[iRowIndex].SubreqNo;
			var object = oSubReqModel.getData().data[iRowIndex].Actionid;
			var category = oSubReqModel.getData().data[iRowIndex].Category;
			var editvalue;
			var oModel = this.getView().getModel("SubReqModel");
			if (oModel.getData().data.Status === Constants.DRAFT || oModel.getData().data.Status === Constants.DRAFT_FR) {
				editvalue = "1";
			} else {
				editvalue = "2";
			}
			if (category === Constants.GL && object === Constants.CREATE && subreq !== undefined) {
				this.oRouter.navTo("RouteGLCreate", {
					layout: fioriLibrary.LayoutType.EndColumnFullScreen,
					SelectItem: editvalue, //with edit access 1=edit
					request: request,
					SubReq: subreq
				});
			} else if (category === Constants.GL && object === Constants.MODIFY && subreq !== undefined) {
				if (oModel.getData().data.Status === Constants.COMPLETE || oModel.getData().data.Status === Constants.COMPLETE_FR ||
					oModel.getData().data.Status === Constants.REJECT || oModel.getData().data.Status === Constants.REJECT_FR) {
					editvalue = "3";
				}
				this.oRouter.navTo("RouteGLModify", {
					layout: fioriLibrary.LayoutType.EndColumnFullScreen,
					SelectItem: editvalue,
					request: request,
					SubReq: subreq
				});
			} else if (category === Constants.GL && object === Constants.CANCEL && subreq !== undefined) {
				this.oRouter.navTo("RouteGLCancel", {
					layout: fioriLibrary.LayoutType.EndColumnFullScreen,
					SelectItem: editvalue,
					request: request,
					SubReq: subreq
				});
			} else if (category === Constants.GL && (object === Constants.BLOCK || object === Constants.BLK || object === Constants.UNBLK) &&
				subreq !== undefined) {
				this.oRouter.navTo("RouteGLBlock", {
					layout: fioriLibrary.LayoutType.EndColumnFullScreen,
					SelectItem: editvalue,
					request: request,
					SubReq: subreq
				});
			} else if (category === Constants.GL && object === Constants.EXTEND && subreq !== undefined) {
				this.oRouter.navTo("RouteGLExtend", {
					layout: fioriLibrary.LayoutType.EndColumnFullScreen,
					SelectItem: editvalue,
					request: request,
					SubReq: subreq
				});
			} else if (category === Constants.RAC && object === Constants.CREATE && subreq !== undefined) {
				this.oRouter.navTo("RouteRacCreate", {
					layout: fioriLibrary.LayoutType.EndColumnFullScreen,
					SelectItem: editvalue,
					request: request,
					SubReq: subreq
				});
			} else if (category === Constants.RAC && object === Constants.CANCEL && subreq !== undefined) {
				this.oRouter.navTo("RouteRacCancel", {
					layout: fioriLibrary.LayoutType.EndColumnFullScreen,
					SelectItem: editvalue,
					request: request,
					SubReq: subreq
				});
			} else if (category === Constants.RAC && object === Constants.MODIFY && subreq !== undefined) {
				if (oModel.getData().data.Status === Constants.COMPLETE || oModel.getData().data.Status === Constants.COMPLETE_FR ||
					oModel.getData().data.Status === Constants.REJECT || oModel.getData().data.Status === Constants.REJECT_FR) {
					editvalue = "3";
				}
				this.oRouter.navTo("RouteRacModify", {
					layout: fioriLibrary.LayoutType.EndColumnFullScreen,
					SelectItem: editvalue,
					request: request,
					SubReq: subreq
				});
			}
		},
		onDeleteRequest: function (oEvt) {
			var request = this.getView().getModel("SubReqModel").getData().data.ReqNo;
			var setname = "/GLHeaderSet('" + request + "')";
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			var that = this;
			oDataModel.remove(setname, {
				method: "DELETE",
				success: function (data) {
					that._closeSubRequest(that);
					that.oGlobalBusyDialog.close();
					var msg = that.getMessageBundleText("msg.suc.DeleteRequest", [request]);
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								return;
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				},
				error: function (e) {
					MessageToast.show(that.getMessageBundleText("msg.err.DeleteRequestError", [request]));
					that.oGlobalBusyDialog.close();
				}
			});
		},
		_closeSubRequest: function (that) {
			var sNextLayout = fioriLibrary.LayoutType.OneColumn;
			that.oRouter.navTo("request", {
				layout: sNextLayout
			});
		},
		onPressClose: function (oEvt) {
			this._closeSubRequest(this);
		}
	});
});