sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"../Util/OdataHelper",
	"../Util/Constants",
	"sap/f/library",
	"../Util/Utility"
], function (BaseController, MessageBox, JSONModel, Filter, MessageToast, Fragment, ODataHelper, Constants, fioriLibrary,
	Utility) {
	"use strict";

	return BaseController.extend("FIM.FIM.controller.GLCreate", {

		//* Called when a controller is instantiated and its View controls (if available) are already created.
		//* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		//* @memberOf FIM.FIM.view.GLCreate
		//*/
		onInit: function () {
			//Initialize busy indicator
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			this.oGlobalBusyDialog.open();
			// Router login
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteGLCreate").attachMatched(this._onRouteFound, this);
			//populate company code in the drop down
			//populate tax category
			this._populateTaxCat();
			// this._odatareadset(Constants.VALUEHELP_SRV_URL, "/TaxCatSet", "TaxCatModel", "msg.err.TaxCatFetchError");
			//populate sort key
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/SortingKeySet", "SortKeyModel", "msg.err.SortKeyFetchError");
			this.oGlobalBusyDialog.close();
		},
		_onRouteFound: function (oEvt) {
			var oArgument = oEvt.getParameter("arguments");
			//Initialize and bind input elements
			var oModel = new JSONModel();
			var oFilter = [];
			this._loadBSValue();
			if ((oArgument.SelectItem === Constants.EDITREQUEST)) {
				oModel.setData({
					"EditFields": true,
					"EditGLField": true,
					"EditRefFields": true,
					"BSVisible": false,
					"Openitem": true,
					"REVVisible": false,
					"PLVisible": false
				});
				oFilter.push(new sap.ui.model.Filter("GlCheckbox", "EQ", "YES"));
			} else {
				oModel.setData({
					"EditFields": false,
					"EditGLField": false,
					"EditRefFields": false,
					"BSVisible": true,
					"Openitem": true,
					"REVVisible": true,
					"PLVisible": true
				});
				//get all the comp codes available other than draft
				oFilter.push(new sap.ui.model.Filter("GlCheckbox", "EQ", "SUB"));
			}
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/TCompCodeSet", "CompModel", "msg.err.CompFetchError", oFilter);
			this.getView().setModel(oModel, "EditModel");
			if (oArgument.SubReq !== undefined && oArgument.SubReq !== "") {
				var oGLSubModel = new JSONModel();
				oGLSubModel.setData({
					"data": {
						"FimReq": oArgument.request,
						"subreqno": oArgument.SubReq
					}
				});
				this.getView().setModel(oGLSubModel, "GLSubModel");
				//load existing data of the Subrequest which is already saved in the table
				this._loadsubrequest(oArgument.request, oArgument.SubReq, Constants.GL_SRV_URL, oArgument.SelectItem);
			}

		},
		_loadsubrequest: function (request, subrequest, sURL, selectitem) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			this.oGlobalBusyDialog.open();
			oDataModel.read("/GLItemSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')", {
				urlParameters: {
					"$expand": "GLItemToCCNav"
				},
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						"GlNum": oData.GlNum,
						"RecycleCode": oData.RecycleCode,
						"AccType": oData.AccType,
						"Explanation": oData.Explanation,
						"TitleEn": oData.TitleEn,
						"TitleFr": oData.TitleFr,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
						// "ExpAnnBal": oData.ExpAnnBal,
						"ExpAnnBal": that.formatamount(oData.ExpAnnBal),
						"BillSys": oData.BillSys,
						"GrpAccNum": oData.GrpAccNum,
						"ReconAcTyp": oData.ReconAcTyp,
						"AltAcNo": oData.AltAcNo,
						"PlanningLevel": oData.PlanningLevel,
						"HouseBank": oData.HouseBank,
						"AccId": oData.AccId,
						"ValueOfExp": that.formatamount(oData.ValueOfExp),
						"Notes": oData.Notes,
						"RsnRGL": oData.RsnRGL,
						"RefGlFlag": that.checkreference(oData.RefComp, oData.RefGl)
					});
					that.getView().byId("ip_acctypebs").setValue(oData.AccType);
					that.getView().byId("ip_chartgroup").setValue(oData.ChartGrp);
					that.getView().byId("cb_direct").setSelectedKey(oData.Director);
					if (selectitem !== Constants.EDITREQUEST) {
						that._GetDirectorName(oData.Director, that);
					}
					if (oData.AccType === Constants.PL) {
						that.getView().byId("ip_pltype").setSelectedKey(oData.PlAccType);
					}
					that.getView().byId("cb_currency").setSelectedKey(oData.AccCurr);
					that.getView().byId("cb_taxcat").setSelectedKey(oData.TaxCat);
					that.getView().byId("cb_recon").setSelectedKey(oData.ReconAcTyp);
					that.getView().byId("cb_sortkey").setSelectedKey(oData.SortKey);
					that.getView().byId("ip_interestfreq").setValue(oData.IntrestCalcFr);

					that.getView().byId("ip_refcomp").setValue(oData.RefComp);
					that.getView().byId("ip_refgl").setValue(oData.RefGl);

					that._loadcheckbox(oData, that);
					var oFsgTableModel = new JSONModel();
					var companyCodeData = {};
					var items = [];
					var value = oData.GLItemToCCNav;
					if (value.results.length === 0) {
						companyCodeData = {
							"ItemNo": 1,
							"FimReq": request,
							"SubreqNo": subrequest,
							"CompCode": "",
							"FldStgrp": ""
						};
						items.push(companyCodeData);
					} else {
						for (var i = 0; i < value.results.length; i++) {
							companyCodeData = {
								"ItemNo": i + 1,
								"FimReq": request,
								"SubreqNo": subrequest,
								"CompCode": value.results[i].CompCode,
								"FldStgrp": value.results[i].FldStgrp
							};
							items.push(companyCodeData);
						}
					}
					oFsgTableModel.setProperty("/data", items);
					that.getView().setModel(oFsgTableModel, "FsgTableModel");
					that.getView().setModel(oModel, "GLCreateModel");
					that._setEditModel(oData.GlNum, that);
					that._setEditRefModel(oData.RefGl, oData.RefComp, that);
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "GLCreateModel");
					MessageToast.show(that.getMessageBundleText("msg.err.subreqFetchError", [subrequest]));

				}
			});
		},
		_GetDirectorName: function (id, that) {
			var setname = "/BSCombinedSet('" + id + "')";
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			ODataHelper.callODataREAD(oDataModel, setname)
				.then(function onSuccess(oData, oResponse) {
					var oModel = new JSONModel();
					oModel.setData({
						"data": [{
							"CpId": oData.CpId,
							"NameFirst": oData.NameFirst,
							"NameLast": oData.NameLast
						}]
					});
					that.getView().setModel(oModel, "directModel");
				})
				.catch(function onError(oError) {});

		},
		checkreference: function (RefComp, RefGl) {
			if ((RefGl !== undefined && RefGl !== null && RefGl !== "") && (RefComp !== undefined && RefComp !== null && RefComp !== "")) {
				return "X";
			} else {
				return "";
			}
		},

		onValidateCombo: function (oEvent) {
			var bValid = oEvent.getSource().getSelectedKey();
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (sComboId === "cb_direct") {
				if (!this.checkOnSelection(oEvent)) {
					this.getView().byId(sComboId).setSelectedKey("");
					return;
				}
			} else if (value !== "" && value !== " - BLANK") {
				if (!this.checkOnSelection(oEvent)) {
					return;
				}
			} else {
				this.getView().byId(sComboId).setValueState(sap.ui.core.ValueState.None);
				this.getView().byId(sComboId).setValueStateText("");
			}
		},
		_clearRefGlValues: function (request, subrequest, that) {
			that.getView().byId("cb_currency").setSelectedKey("");
			that.getView().byId("ip_altaccno").setValue("");
			that.getView().byId("ip_planninglevel").setValue("");
			that.getView().byId("ip_housebank").setValue("");
			that.getView().byId("ip_accid").setValue("");
			that.getView().byId("cb_recon").setSelectedKey("");
			that.getView().byId("cb_taxcat").setSelectedKey("");
			that.getView().byId("ip_interestfreq").setValue("");
			that.getView().byId("cb_sortkey").setSelectedKey("");

			that.getView().byId("cb_relevantcash").setSelected(false);
			that.getView().byId("cb_lineitem").setSelected(false);
			that.getView().byId("cb_balancelocal").setSelected(false);
			that.getView().byId("cb_withouttax").setSelected(false);
			//Edit model
			var oEditModel = that.getView().getModel("EditModel");
			that.getView().byId("cb_openitem").setSelected(false);
			oEditModel.setProperty("/Openitem", true);
			that.getView().setModel(oEditModel, "EditModel");

			// set the table for comp code and FSG empty
			var oFsgTableModel = new JSONModel();
			oFsgTableModel.setData({
				"data": [{
					"ItemNo": 1,
					"FimReq": request,
					"SubreqNo": subrequest,
					"CompCode": "",
					"FldStgrp": ""
				}]
			});
			that.getView().setModel(oFsgTableModel, "FsgTableModel");
		},
		onSubmitRef: function (oEvt) {
			var glnum = this.getView().byId("ip_glaccount");
			if (!this._validateGl(glnum, "msg.val.GlError", this)) {
				return false;
			}
			var refcompcode = this.getView().byId("ip_refcomp").getValue();
			var refgl = this.getView().byId("ip_refgl").getValue();
			var subModel = this.getView().getModel("GLSubModel");
			var oGLCreateModel = this.getView().getModel("GLCreateModel");
			//if both values are empty
			if ((refcompcode === undefined || refcompcode === null || refcompcode === "") &&
				(refgl === undefined || refgl === null || refgl === "")) {
				if (oGLCreateModel.getData().RefGlFlag === "X") {
					oGLCreateModel.setProperty("/RefGlFlag", "");
					this.getView().setModel(oGLCreateModel, "GLCreateModel");
					this._clearRefGlValues(subModel.getData().data.FimReq, subModel.getData().data.subreqno, this);
				}
				this.resetValueState(this.getView().byId("ip_refgl"));
				this.resetValueState(this.getView().byId("ip_refcomp"));
			}
			//If ref gl is entered without company code display error
			if (!this._validateRefGlComp(refgl, refcompcode, glnum, this)) {
				return false;
			}
			if (refcompcode !== undefined && refcompcode !== null && refcompcode !== "" && refgl !== undefined && refgl !== null && refgl !==
				"") {
				this.resetValueState(this.getView().byId("ip_refgl"));
				this.resetValueState(this.getView().byId("ip_refcomp"));
				var setname = "/GLReferenceSet(ImCc='" + refcompcode + "',ImGl='" + refgl + "')";

				var that = this;
				var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
				this.oGlobalBusyDialog.open();
				ODataHelper.callODataREAD(oDataModel, setname)
					.then(function onSuccess(oData, oResponse) {
						that.getView().byId("cb_currency").setSelectedKey(oData.ExAcurr);
						that.getView().byId("ip_altaccno").setValue(oData.ExAltacc);
						that.getView().byId("ip_planninglevel").setValue(oData.ExFdlev);
						that.getView().byId("ip_housebank").setValue(oData.ExHbkid);
						that.getView().byId("ip_accid").setValue(oData.ExHktid);
						that.getView().byId("cb_recon").setSelectedKey(oData.ExRecon);
						var oEditModel = that.getView().getModel("EditModel");
						oEditModel.setProperty("/EditRefFields", false);
						if ((oData.ExRecon === undefined || oData.ExRecon === null || oData.ExRecon === "") && oData.ExOpitm ===
							"X") {
							that.getView().byId("cb_openitem").setSelected(true);
							oEditModel.setProperty("/Openitem", true);
						} else if (oData.ExRecon !== undefined && oData.ExRecon !== null && oData.ExRecon !== "") {
							that.getView().byId("cb_openitem").setSelected(false);
							oEditModel.setProperty("/Openitem", false);
						}
						that.getView().setModel(oEditModel, "EditModel");
						if (oData.ExXgkon === "X") {
							that.getView().byId("cb_relevantcash").setSelected(true);
						} else {
							that.getView().byId("cb_relevantcash").setSelected(false);
						}
						if (oData.ExXkres === "X") {
							that.getView().byId("cb_lineitem").setSelected(true);
						} else {
							that.getView().byId("cb_lineitem").setSelected(false);
						}
						if (oData.ExXsalh === "X") {
							that.getView().byId("cb_balancelocal").setSelected(true);
						} else {
							that.getView().byId("cb_balancelocal").setSelected(false);
						}
						if (oData.ExXmwno === "X") {
							that.getView().byId("cb_withouttax").setSelected(true);
						} else {
							that.getView().byId("cb_withouttax").setSelected(false);
						}
						that.getView().byId("cb_taxcat").setSelectedKey(oData.ExTaxcat);
						that.getView().byId("ip_interestfreq").setValue(oData.ExZinrt);
						that.getView().byId("cb_sortkey").setSelectedKey(oData.ExZuawa);
						if (oData.ExFstag !== undefined && oData.ExFstag !== null && oData.ExFstag !== "") {
							var oFsgTableModel = new JSONModel();
							var compmodel = that.getView().getModel("CompModel").getData().data;
							var compcode;
							for (var i = 0; i < compmodel.length; i++) {
								if (compmodel[i]["CompCode"] === refcompcode) {
									compcode = refcompcode;
								}
							}
							oFsgTableModel.setData({
								"data": [{
									"ItemNo": 1,
									"FimReq": subModel.getData().data.FimReq,
									"SubreqNo": subModel.getData().data.subreqno,
									"CompCode": compcode,
									"FldStgrp": oData.ExFstag
								}]
							});
							that.getView().setModel(oFsgTableModel, "FsgTableModel");
						}
						that.getView().setModel(oEditModel, "EditModel");
						oGLCreateModel.setProperty("/RefGlFlag", "X");
						that.getView().setModel(oGLCreateModel, "GLCreateModel");
						that.oGlobalBusyDialog.close();
					})
					.catch(function onError(oError) {
						that.getView().byId("ip_refcomp").setValue();
						that.getView().byId("ip_refgl").setValue();

						oGLCreateModel.setProperty("/RefGlFlag", "");
						that.getView().setModel(oGLCreateModel, "GLCreateModel");

						var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
						var sMsg = "";
						for (var i = 1; i < arr.length; i++) {
							sMsg = sMsg + '\n' + arr[i].message + '\n';
						}
						var msgTitle = that.getResourceBundleText("title.errorMessage");
						MessageBox.error(sMsg, {
							title: msgTitle, // default
							onClose: null, // default
							styleClass: "", // default
							actions: sap.m.MessageBox.Action.CLOSE, // default
							emphasizedAction: null, // default
							initialFocus: null, // default
							textDirection: sap.ui.core.TextDirection.Inherit // default
						});
						that.oGlobalBusyDialog.close();
						return;
					});
			}
		},

		onSubmitClearRef: function (oEvt) {
			var refgl = this.getView().byId("ip_refgl").getValue();
			var refcompcode = this.getView().byId("ip_refcomp").getValue();
			if ((refgl !== undefined && refgl !== null && refgl !== "") || (refcompcode !== undefined && refcompcode !== null && refcompcode != "")) {
				var subModel = this.getView().getModel("GLSubModel");
				var oGLCreateModel = this.getView().getModel("GLCreateModel");
				oGLCreateModel.setProperty("/RefGlFlag", "");
				this.getView().setModel(oGLCreateModel, "GLCreateModel");
				this.getView().byId("ip_refcomp").setValue("");
				this.getView().byId("ip_refgl").setValue("");
				this._clearRefGlValues(subModel.getData().data.FimReq, subModel.getData().data.subreqno, this);
				this._setEditRefModel("", "", this);
			}
		},
		_validateRefGlComp: function (refgl, refcompcode, glnum, that) {
			var found = false;
			if ((refgl === undefined || refgl === "" || refgl === null) &&
				(refcompcode === undefined || refcompcode === "" || refcompcode === "")) {
				this.resetValueState(this.getView().byId("ip_refgl"));
				this.resetValueState(this.getView().byId("ip_refcomp"));
				return true;
			} else if (refcompcode === undefined || refcompcode === null || refcompcode === "") {
				that.getView().byId("ip_refcomp").setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText("msg.val.RefCompError"));
				return false;
			} else if (refgl === undefined || refgl === "" || refgl === null) {
				that.getView().byId("ip_refgl").setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText("msg.val.RefGlError"));
				return false;
			} else if (refgl !== undefined && refgl !== null && refgl !== "") {
				if (refgl.length !== 7) {
					that.getView().byId("ip_refgl").setValueState(sap.ui.core.ValueState.Error);
					MessageToast.show(that.getMessageBundleText("msg.val.RefGlError"));
					return false;
				} else {
					that.resetValueState(that.getView().byId("ip_refgl"));
					found = true;
				}
				var acctypegl = that._validateGlStart(glnum.getValue(), that);
				var acctyperef = that._validateGlStart(refgl, that);
				if (acctypegl !== acctyperef) {
					that.getView().byId("ip_refgl").setValueState(sap.ui.core.ValueState.Error);
					MessageToast.show(that.getMessageBundleText(("msg.val.RefGlAcctypeError"), [acctypegl]));
					return false;
				} else {
					this.resetValueState(that.getView().byId("ip_refgl"));
					found = true;
				}
			}
			that.resetValueState(that.getView().byId("ip_refcomp"));
			found = true;
			return found;
		},

		onSelectComp: function (oEvent) {
			var oTableModel = this.getView().byId("tbl_Fsg").getModel("FsgTableModel");
			var rowid = oEvent.oSource.sId;
			var iRowIndex = rowid.split('-')[6]; //gets the rowindex from this value '__xmlview3--cb_comp-__xmlview3--tbl_Fsg-10'
			var value = oEvent.mParameters.value;
			if (value !== undefined && value !== null && value !== "") {
				if (!this.checkOnSelection(oEvent)) {

					return;
				}
			} else {
				this.getView().byId("cb_comp").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("cb_comp").setValueStateText("");
			}
			oTableModel.setProperty("/data/" + iRowIndex + "/FldStgrp", "");
			this.getView().setModel(oTableModel, "FsgTableModel");

		},
		onPressLoadFSG: function (oEvent) {
			var oView = this.getView();
			var fragmentSearchFSG = "FIM.FIM.view.fragment.SearchFSG";
			var oTableModel = this.getView().byId("tbl_Fsg").getModel("FsgTableModel");
			var rowid = oEvent.oSource.sId;
			var iRowIndex = rowid.split('-')[4];
			var sselectComp = oTableModel.getData().data[iRowIndex].CompCode;
			if (sselectComp !== undefined && sselectComp !== null && sselectComp !== "") {
				sap.ui.core.BusyIndicator.show(0);
				var DialogComp = new JSONModel;
				DialogComp.setData({
					"Comp": sselectComp,
					"rowindex": iRowIndex
				});
				this.getView().setModel(DialogComp, "DialogComp");
				var oFilter = [];
				oFilter.push(new sap.ui.model.Filter("Bukrs", "EQ", sselectComp));
				var that = this;
				var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
				ODataHelper.callODataREAD(oDataModel, "/GLFLDSTGRPSet", oFilter)
					.then(function onSuccess(oData, oResponse) {
						var oModel = new JSONModel();
						oModel.setData({
							data: oData.results
						});
						that.getView().setModel(oModel, "FsgModel");
						sap.ui.core.BusyIndicator.hide();
						if (!that.byId("dlg_searchfsg")) {
							Fragment.load({
								id: oView.getId(),
								name: fragmentSearchFSG,
								type: "XML",
								controller: that
							}).then(function (oDialog) {
								oView.addDependent(oDialog);
								oDialog.open();
							});
							that._oDialogSearchFSG = sap.ui.xmlfragment(fragmentSearchFSG, that);
						} else {
							that.byId("dlg_searchfsg").open();
						}
					})
					.catch(function onError(oError) {
						MessageToast.show(that.getMessageBundleText("msg.err.FsgFetchError"));
						sap.ui.core.BusyIndicator.hide();
					});
			}
		},
		onSelectSearchFSG: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var sSelected = oSelectedItem.getCells()[0].getText();
			var DialogComp = this.getView().getModel("DialogComp");
			var oTableModel = this.getView().byId("tbl_Fsg").getModel("FsgTableModel");
			if (typeof sSelected !== "undefined" && sSelected !== null && sSelected !== "") {
				oTableModel.setProperty("/data/" + DialogComp.getData().rowindex + "/FldStgrp", sSelected);
				this.getView().setModel(oTableModel, "FsgTableModel");
				this.byId("dlg_searchfsg").close();
			}
		},
		_clearF4FSG: function () {
			var oModel = new JSONModel();
			this.getView().setModel(oModel, "DialogComp");
			this.getView().setModel(oModel, "FsgModel");
		},
		onCloseF4FSG: function (oEvent) {
			this._clearF4FSG();
			this.byId("dlg_searchfsg").close();
		},

		onInputGlChange: function (oEvt) {
			var sGl = oEvt.getSource().getValue();
			if (!this._validateGl(this.getView().byId("ip_glaccount"), "msg.val.GlError", this)) {
				return;
			}
			// check if the GL is existing 
			this._loadChartGroup(sGl, this);
		},
		onAddNewRow: function (oEvent) {
			//Pass table id and model name
			var oGLSubModel = this.getView().getModel("GLSubModel");
			this._addNewRowGL(oEvent, "tbl_Fsg", "FsgTableModel", oGLSubModel.getData().data.FimReq, oGLSubModel.getData().data.subreqno);

		},
		onRemoveRow: function (oEvent) {
			this._removeRowGL(oEvent, "tbl_Fsg", "FsgTableModel");

		},

		onPressRecycle: function (oEvent) {
			var oView = this.getView();
			var fragmentSearchGlAccount = "FIM.FIM.view.fragment.SearchGlAccount";
			this.oGlobalBusyDialog.open();
			if (!this.byId("dlg_searchglaccount")) {
				Fragment.load({
					id: oView.getId(),
					name: fragmentSearchGlAccount,
					type: "XML",
					controller: this
				}).then(function (oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
				this._oDialogSearchGlAccount = sap.ui.xmlfragment(fragmentSearchGlAccount, this);
			} else {
				this.byId("dlg_searchglaccount").open();
				this.getView().byId("cb_glaccount").setValue("");
			}

			this.oGlobalBusyDialog.close();
		},
		onF4ChangeGl: function (oEvent) {
			var gl = oEvent.getSource().getValue();
			var check = false;
			if (gl === undefined || gl === null || gl === "" || gl === "*") {
				this.getView().byId("cb_glaccount").setValue("");
				this.getView().byId("cb_glaccount").setValueState(sap.ui.core.ValueState.Error);
				return;
			}
			for (var i = 0; i < gl.length; i++) {
				if ((gl[i].match(/^[0-9]+$/) === null) && i === 0) {
					this.getView().byId("cb_glaccount").setValue("");
					this.getView().byId("cb_glaccount").setValueState(sap.ui.core.ValueState.Error);
					return;
				} else {
					if (gl[i].match("[0-9*]+") === null) {
						this.getView().byId("cb_glaccount").setValue("");
						this.getView().byId("cb_glaccount").setValueState(sap.ui.core.ValueState.Error);
						return;
					}
					//gl search should contain atleast one *
					if (gl[i] === "*" && gl.length !== 7) {
						check = true;
					} else if (gl.length === 7) {
						check = true;
					}
				}
			}
			if (!check) {
				this.getView().byId("cb_glaccount").setValue("");
				this.getView().byId("cb_glaccount").setValueState(sap.ui.core.ValueState.Error);
				return;
			}
			this.resetValueState(this.getView().byId("cb_glaccount"));
			//Call Odata to fill the GL search table
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			var oFilter = [];
			oFilter.push(new sap.ui.model.Filter("ImCreate", "EQ", "X"));
			oFilter.push(new sap.ui.model.Filter("ImGlnum", "EQ", gl));
			oFilter.push(new sap.ui.model.Filter("ImRgl", "EQ", "X"));

			this.oGlobalBusyDialog.open();
			oDataModel.read("/GLValidListSet", {
				async: false,
				filters: oFilter,
				success: function (oData, response) {
					var oGlsearchModel = new sap.ui.model.json.JSONModel();
					oGlsearchModel.setData({
						data: oData.results
					});
					that.getView().byId("tbl_glsearch").setVisible((oData.results.length > 0));
					that.getView().byId("tbl_glsearch").setModel(oGlsearchModel, "GlsearchModel");
					that.oGlobalBusyDialog.close();
				},
				error: function (oError) {
					that.getView().byId("cb_glaccount").setValue("");
					that.getView().byId("cb_glaccount").setValueState(sap.ui.core.ValueState.Error);
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
				}
			});
		},
		onCloseF4GlAccount: function (oEvent) {
			this._clearF4GlAccount();
			this.byId("dlg_searchglaccount").close();
		},
		onSelectSearchGl: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var sSelectedGl = oSelectedItem.getCells()[0].getText();
			var oGLCreateModel = this.getView().getModel("GLCreateModel");
			if (typeof sSelectedGl !== "undefined" && sSelectedGl !== null && sSelectedGl !== "") {
				//Set Recycled GL account flag as true
				oGLCreateModel.setProperty("/GlNum", sSelectedGl);
				oGLCreateModel.setProperty("/RecycleCode", "X");
				oGLCreateModel.setProperty("/RsnRGL", "");
				this.getView().setModel(oGLCreateModel, "GLCreateModel");
				//Load the chart grouo whenever GL account number is changed
				this._loadChartGroup(sSelectedGl, this);
				this._setEditModel(sSelectedGl, this);
				this._clearF4GlAccount();
				this.byId("dlg_searchglaccount").close();
			} else {
				MessageToast.show(this.getMessageBundleText("msg.val.InvalidGLError", [k]));
			}
		},
		_validateGlStart: function (sSelectedGl, that) {
			//BS
			if (sSelectedGl[0] === "1" || sSelectedGl[0] === "2" || sSelectedGl[0] === "3") {
				return Constants.BS;
			} //PL account
			else if (sSelectedGl[0] === "4" || sSelectedGl[0] === "6" || sSelectedGl[0] === "7") {
				return Constants.PL;
			}
		},
		_setEditModel: function (sSelectedGl, that) {
			var oModel = that.getView().getModel("EditModel");
			//BS account
			//set cp4 value and director
			var acctype = that._validateGlStart(sSelectedGl, that);
			if (acctype === Constants.BS) {
				that.getView().byId("ip_acctypebs").setValue(Constants.BS);
				oModel.setProperty("/BSVisible", true);
				oModel.setProperty("/PLVisible", false);
				oModel.setProperty("/REVVisible", false);
				//Belongs to PL so set it empty when value is changed
				that.getView().byId("ip_pstamt").setValue("");
				that.getView().byId("ip_pltype").setSelectedKey("");
				that.getView().byId("ip_billingsystem").setValue("");
			} //PL account
			else if (acctype === Constants.PL) {
				that.getView().byId("ip_acctypebs").setValue(Constants.PL);
				oModel.setProperty("/PLVisible", true);
				oModel.setProperty("/BSVisible", false);
				that.getView().byId("ip_pltype").setSelectedKey(Constants.RE);
				//Belongs to BS so set it empty when value is changed
				that.getView().byId("cb_direct").setSelectedKey("");
				that.getView().byId("ip_balance").setValue("");
				if (sSelectedGl[0] === "4") {
					oModel.setProperty("/REVVisible", true);
				} else {
					oModel.setProperty("/REVVisible", false);
					that.getView().byId("ip_billingsystem").setValue("");
				}

			}
			if (sSelectedGl !== undefined && sSelectedGl !== null && sSelectedGl !== "") {
				oModel.setProperty("/EditGLField", false);
			}

			that._resetvaluestatus(that);
			that.getView().setModel(oModel, "EditModel");
		},
		_setEditRefModel: function (RefGl, RefComp, that) {
			var oModel = that.getView().getModel("EditModel");

			if ((RefGl !== undefined && RefGl !== null && RefGl !== "") && (RefComp !== undefined && RefComp !== null && RefComp !== "")) {
				oModel.setProperty("/EditRefFields", false);
			} else {
				if (oModel.getData().EditFields === true) {
					oModel.setProperty("/EditRefFields", true);
				}
			}
			that.getView().setModel(oModel, "EditModel");
		},
		onSubmitManualGl: function (oEvent) {
			var gl = this.getView().byId("ip_glaccount");
			if (!this._validateGl(gl, "msg.val.GlError", this)) {
				return;
			}
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			var oFilter = [];
			oFilter.push(new sap.ui.model.Filter("ImCreate", "EQ", "X"));
			oFilter.push(new sap.ui.model.Filter("ImGlnum", "EQ", gl.getValue()));
			oFilter.push(new sap.ui.model.Filter("ImRgl", "EQ", ""));
			this.oGlobalBusyDialog.open();
			oDataModel.read("/GLValidListSet", {
				async: false,
				filters: oFilter,
				success: function (oData, response) {
					var oGLCreateModel = that.getView().getModel("GLCreateModel");
					oGLCreateModel.setProperty("/GlNum", gl.getValue());
					oGLCreateModel.setProperty("/RecycleCode", "");
					that.getView().setModel(oGLCreateModel, "GLCreateModel");
					that._loadChartGroup(gl.getValue(), that);
					that._setEditModel(gl.getValue(), that);
					that.oGlobalBusyDialog.close();
				},
				error: function (oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
				}
			});
		},
		_clearF4GlAccount: function () {
			this.resetValueState(this.getView().byId("cb_glaccount"));
			this.getView().byId("cb_glaccount").setValue("");
			this.getView().byId("ms_searchglaccount").setVisible(false);
			this.byId("tbl_glsearch").setVisible(false);
			var oModel = new sap.ui.model.json.JSONModel();
			this.byId("tbl_glsearch").setModel(oModel);
		},
		onSubmitExplain: function (oEvt) {
			if (!this._validateValue(this.getView().byId("ip_explain"), "msg.val.explain", this)) {
				return false;
			}
			return true;
		},
		onSubmitBill: function (oEvt) {
			if (!this._validateValue(this.getView().byId("ip_billingsystem"), "msg.val.billingsystem", this)) {
				return false;
			}
			return true;
		},
		// onSubmitPstamt: function (oEvt) {
		// 	if (!this._validateValue(this.getView().byId("ip_pstamt"), "msg.val.invalidvalueof", this)) {
		// 		return false;
		// 	}
		// 	return true;
		// },
		onPressSaveGL: function (oEvt) {
			//Validate Gl value
			if (!this._validateGl(this.getView().byId("ip_glaccount"), "msg.val.GlError", this)) {
				return false;
			}
			//Validate RefGl and RefComp code
			var refgl = this.getView().byId("ip_refgl").getValue();
			var refcompcode = this.getView().byId("ip_refcomp").getValue();
			if (!this._validateRefGlComp(refgl, refcompcode, this.getView().byId("ip_glaccount"), this)) {
				return false;
			}
			var oEntry = {};
			var oGLCreateModel = this.getView().getModel("GLCreateModel");
			var oFsgTableModel = this.getView().getModel("FsgTableModel");

			var that = this;
			if ((refgl !== undefined && refgl !== null && refgl !== "") && (refcompcode !== undefined && refcompcode !== null && refcompcode !==
					"") &&
				(oGLCreateModel.getData().RefGlFlag === "" || oGLCreateModel.getData().RefGlFlag === undefined || oGLCreateModel.getData().RefGlFlag ===
					null)) {
				//set the first tab as default
				that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
				that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
				that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
				var sMsg = that.getMessageBundleText("msg.val.RefValidationError");
				var msgTitle = that.getResourceBundleText("title.errorMessage");
				MessageBox.error(sMsg, {
					title: msgTitle, // default
					onClose: null, // default
					styleClass: "", // default
					actions: sap.m.MessageBox.Action.CLOSE, // default
					emphasizedAction: null, // default
					initialFocus: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
				return false;
			}

			//validate amount field
			if (this.getView().byId("ip_acctypebs").getValue() === Constants.BS) {
				if (!this.onSubmitAnnual()) {
					return false;
				}
			} else {
				if (!this.onSubmitPstamt()) {
					return false;
				}
			}

			var oTableList = oFsgTableModel.getProperty("/data");
			var oCompanyList = oTableList.map(function (obj) {
				return {
					FimReq: obj.FimReq,
					SubreqNo: obj.SubreqNo,
					CompCode: obj.CompCode,
					FldStgrp: obj.FldStgrp
				};
			});
			oEntry.GLItemToCCNav = oCompanyList;
			var oGLSubModel = this.getView().getModel("GLSubModel");
			oEntry.GlNum = oGLCreateModel.getData().GlNum;
			oEntry.RecycleCode = oGLCreateModel.getData().RecycleCode;
			if (oEntry.RecycleCode === undefined || oEntry.RecycleCode === null || oEntry.RecycleCode === "") {
				oEntry.RsnRGL = oGLCreateModel.getData().RsnRGL;
			}

			oEntry.AccType = oGLCreateModel.getData().AccType;
			oEntry.Explanation = oGLCreateModel.getData().Explanation;
			oEntry.TitleEn = oGLCreateModel.getData().TitleEn;
			oEntry.TitleFr = oGLCreateModel.getData().TitleFr;
			oEntry.LtextEn = oGLCreateModel.getData().LtextEn;
			oEntry.LtextFr = oGLCreateModel.getData().LtextFr;
			oEntry.DescEn = oGLCreateModel.getData().DescEn;
			oEntry.DescFr = oGLCreateModel.getData().DescFr;
			// oEntry.ExpAnnBal = oGLCreateModel.getData().ExpAnnBal;
			if (this.getView().byId("ip_acctypebs").getValue() === Constants.BS) {
				oEntry.ExpAnnBal = this.parseamount(oGLCreateModel.getData().ExpAnnBal);

			} else {
				oEntry.ExpAnnBal = oGLCreateModel.getData().ExpAnnBal;
			}
			// oEntry.ValueOfExp = oGLCreateModel.getData().ValueOfExp;
			// if (oGLCreateModel.getData().ValueOfExp !== null &&
			// 	oGLCreateModel.getData().ValueOfExp !== undefined && oGLCreateModel.getData().ValueOfExp !== "") {
			if (this.getView().byId("ip_acctypebs").getValue() === Constants.PL) {
				oEntry.ValueOfExp = this.parseamount(oGLCreateModel.getData().ValueOfExp);
			} else {
				oEntry.ValueOfExp = oGLCreateModel.getData().ValueOfExp;
			}
			oEntry.BillSys = oGLCreateModel.getData().BillSys;
			oEntry.GrpAccNum = oGLCreateModel.getData().GrpAccNum;
			oEntry.ReconAcTyp = oGLCreateModel.getData().ReconAcTyp;
			oEntry.AltAcNo = oGLCreateModel.getData().AltAcNo;
			oEntry.PlanningLevel = oGLCreateModel.getData().PlanningLevel;
			oEntry.HouseBank = oGLCreateModel.getData().HouseBank;
			oEntry.AccId = oGLCreateModel.getData().AccId;

			oEntry.Notes = oGLCreateModel.getData().Notes;
			oEntry.PostingWta = " ";
			oEntry.BalLocCurr = " ";
			oEntry.OpenItemMt = " ";
			oEntry.LineItemDis = " ";
			oEntry.RelCashFlow = " ";
			//CheckBox
			if (this.getView().byId("cb_relevantcash").getSelected()) {
				oEntry.RelCashFlow = "X";
			}
			if (this.getView().byId("cb_lineitem").getSelected()) {
				oEntry.LineItemDis = "X";
			}
			if (this.getView().byId("cb_openitem").getSelected()) {
				if (oEntry.ReconAcTyp === undefined || oEntry.ReconAcTyp === null || oEntry.ReconAcTyp === "") {
					oEntry.OpenItemMt = "X";
				}
			}
			if (this.getView().byId("cb_balancelocal").getSelected()) {
				oEntry.BalLocCurr = "X";
			}
			if (this.getView().byId("cb_withouttax").getSelected()) {
				oEntry.PostingWta = "X";
			}
			oEntry.FimReq = oGLSubModel.getData().data.FimReq;
			oEntry.SubreqNo = oGLSubModel.getData().data.subreqno;
			oEntry.Actionid = Constants.CREATE;
			oEntry.Category = Constants.GL;

			oEntry.AccType = this.getView().byId("ip_acctypebs").getValue();
			if (oEntry.AccType === Constants.PL) {
				oEntry.PlAccType = this.getView().byId("ip_pltype").getSelectedKey();
			}
			oEntry.Coa = this.getView().byId("ip_chartacc").getValue();
			oEntry.ChartGrp = this.getView().byId("ip_chartgroup").getValue();
			oEntry.Director = this.getView().byId("cb_direct").getSelectedKey();

			oEntry.AccCurr = this.getView().byId("cb_currency").getSelectedKey();
			oEntry.TaxCat = this.getView().byId("cb_taxcat").getSelectedKey();
			oEntry.ReconAcTyp = this.getView().byId("cb_recon").getSelectedKey();
			oEntry.SortKey = this.getView().byId("cb_sortkey").getSelectedKey();
			oEntry.IntrestCalcFr = this.getView().byId("ip_interestfreq").getValue();

			oEntry.RefComp = this.getView().byId("ip_refcomp").getValue();
			oEntry.RefGl = this.getView().byId("ip_refgl").getValue();

			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			ODataHelper.callODataCREATE(oDataModel, "/GLItemSet", oEntry)
				.then(function onSuccess(oResult, oResponse) {
					that.oGlobalBusyDialog.close();
					that._clearScreenValues(that);
					//Data submitted successfully!
					var msg = that.getMessageBundleText("msg.success.submitForm", [oGLSubModel.getData().data.subreqno]);

					//Show success message and return to 1st screen
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								that.onNavigateBack(oEvt, that, oGLSubModel.getData().data.FimReq, "RouteGLCreate");
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {
					that.oGlobalBusyDialog.close();
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					return;
				});
		},
		onPressDeleteSub: function (oEvt) {
			var GLSubModel = this.getView().getModel("GLSubModel");
			this._deleteSubRequest(GLSubModel.getData().data.FimReq, GLSubModel.getData().data.subreqno, oEvt, this);
		},
		_resetvaluestatus: function (that) {
			that.resetValueState(that.getView().byId("ip_refgl"));
			that.resetValueState(that.getView().byId("ip_refcomp"));
			that.resetValueState(that.getView().byId("ip_glaccount"));
			that.resetValueState(that.getView().byId("ip_groupac"));
			that.resetValueState(that.getView().byId("ip_pstamt"));
			that.resetValueState(that.getView().byId("ip_balance"));
			that.resetValueState(that.getView().byId("ip_explain"));
			that.resetValueState(that.getView().byId("ip_billingsystem"));
			//combo box
			that.resetValueState(that.getView().byId("cb_direct"));
			that.resetValueState(that.getView().byId("cb_recon"));
			that.resetValueState(that.getView().byId("cb_sortkey"));
			that.resetValueState(that.getView().byId("cb_currency"));
			that.resetValueState(that.getView().byId("cb_taxcat"));
			that.resetValueState(that.getView().byId("cb_comp"));

		},
		_clearScreenValues: function (that) {
			that._resetvaluestatus(that);
			var oGLCreateModel = new JSONModel();
			that.getView().setModel(oGLCreateModel, "GLCreateModel");
			that.getView().byId("ip_chartgroup").setValue("");
			that.getView().byId("ip_acctypebs").setValue("");
			that.getView().byId("cb_direct").setSelectedKey("");
			that.getView().byId("ip_pltype").setSelectedKey("");
			that.getView().byId("ip_refcomp").setValue("");
			that.getView().byId("ip_refgl").setValue("");
			that.getView().byId("cb_currency").setSelectedKey("");
			that.getView().byId("cb_taxcat").setSelectedKey("");
			that.getView().byId("cb_recon").setSelectedKey("");
			that.getView().byId("cb_sortkey").setSelectedKey("");
			that.getView().byId("ip_interestfreq").setValue("");
			that.getView().byId("cb_relevantcash").setSelected(false);
			that.getView().byId("cb_lineitem").setSelected(false);
			that.getView().byId("cb_openitem").setSelected(false);
			that.getView().byId("cb_balancelocal").setSelected(false);
			that.getView().byId("cb_withouttax").setSelected(false);

			//set the first tab as default
			that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
			that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
			that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
		},
		onNavBack: function (oEvt) {
			var subModel = this.getView().getModel("GLSubModel");
			var request = subModel.getData().data.FimReq;
			this._clearScreenValues(this);
			this.onNavigateBack(oEvt, this, request, "RouteGLCreate");
		}

	});

});