sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/f/library",
	"sap/ui/core/Fragment",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/format/NumberFormat",
	"../Util/OdataHelper",
	"../Util/Constants",
	"../Util/Utility"
], function (jQuery, Controller, MessageToast, JSONModel, History, fioriLibrary, Fragment, DateFormat, NumberFormat, ODataHelper,
	Constants, Utility) {
	"use strict";

	return Controller.extend("FIM.FIM.controller.BaseController", {
		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return this.getOwnerComponent().getRouter();
		},

		/**
		 * Convenience method to get the resource bundle.
		 * @public
		 * @returns resource text in the i18n resourceModel that corresponds to the sKey
		 */
		getResourceBundleText: function (sKey) {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sKey);
		},
		//while passing the date to the backend date is considered to be yesterday's date
		_correctDateFormat: function (sDate) {
			if (!sDate) {
				return sDate;
			}
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var oDate = dateFormat.format(new Date(sDate));
			oDate = oDate + "T00:00:00";
			return oDate;
		},
		/**
		 * Convenience method to get a resource text from the message bundle based on the provided key
		 * @public
		 * @returns messageText in the message Bundle that corresponds to the sKey
		 */
		getMessageBundleText: function (sKey, mArgs) {
			jQuery.sap.require("jquery.sap.resources");
			var sLocale = sap.ui.getCore().getConfiguration().getLanguage();
			var oBundle = jQuery.sap.resources({
				url: "i18n/messageBundle.properties",
				locale: sLocale
			});
			return oBundle.getText(sKey, mArgs);
		},
		_deleteSubRequest: function (request, subrequest, oEvt, that) {
			var setname = "/GLItemSet(FimReq='" + request + "',SubreqNo='" + subrequest +
				"')";
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			that.oGlobalBusyDialog.open();
			oDataModel.remove(setname, {
				method: "DELETE",
				success: function (data) {
					that._clearScreenValues(that);
					that.onNavigateBack(oEvt, that, request);
					MessageToast.show(that.getMessageBundleText("msg.suc.DeleteSubRequest", [subrequest]));
					that.oGlobalBusyDialog.close();
				},
				error: function (e) {
					MessageToast.show(that.getMessageBundleText("msg.err.DeleteSubRequestError", [subrequest]));
					that.oGlobalBusyDialog.close();
				}
			});
		},
		_validateGl: function (glnum, msg, that) {
			if (glnum.getValue().length !== 7) {
				glnum.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText(msg));
				return false;
			} else {
				that.resetValueState(glnum);
				return true;
			}
		},
		_validateValue: function (id, msg, that) {
			if (id.getValue() === undefined || id.getValue() === null || id.getValue() === "") {
				id.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText(msg));
				return false;
			} else {
				that.resetValueState(id);
				return true;
			}
		},
		onSubmitGroupAcc: function (oEvent) {
			if (!this._validateGl(this.getView().byId("ip_groupac"), "msg.val.GroupError", this)) {
				return false;
			}
		},
		onChangerecon: function (oEvent) {
			var recon = oEvent.getSource().getSelectedKey();
			var value = oEvent.mParameters.newValue;
			if (value !== "") {
				if (!this.checkOnSelection(oEvent)) {
					return;
				}
			} else {
				this.getView().byId("cb_recon").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("cb_recon").setValueStateText("");
			}
			var oModel = this.getView().getModel("EditModel");
			if (recon !== undefined && recon !== null && recon !== "") {
				oModel.setProperty("/Openitem", false);
				this.getView().byId("cb_openitem").setSelected(false);
			} else {
				oModel.setProperty("/Openitem", true);
				this.getView().byId("cb_openitem").setSelected(false);
			}
			this.getView().setModel(oModel, "EditModel");
		},
		_loadBSValue: function () {
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/BSAccDirSet", "directModel", "msg.err.DirectorFetchError");
		},
		_loadChartGroup: function (sGl, that) {
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);

			that.oGlobalBusyDialog.open();
			oDataModel.read("/ChartGroupSet('" + sGl + "')", {
				success: function (oData, response) {
					that.getView().byId("ip_chartgroup").setValue(oData.ExGrpCode);
					that.oGlobalBusyDialog.close();
				},
				error: function (oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
				}
			});
		},
		/**
		 * Navigates back in the browser history, if the entry was created by this app.
		 * If not, it navigates to a route passed to this function.
		 * 
		 * @public
		 * @param {string} sRoute the name of the route if there is no history entry
		 * @param {object} mData the parameters of the route, if the route does not need parameters, it may be omitted.
		 */
		onNavigateBack: function (oEvt, that, request, routename) {
			if (request !== undefined && request !== null && request !== "") {
				that.oRouter = that.getOwnerComponent().getRouter();
				if (routename !== undefined && routename !== null && routename !== "") {
					that.oRouter.getRoute(routename).detachPatternMatched(that._onRouteFound, that);
				}
				that.oRouter.navTo("subrequest", {
					layout: fioriLibrary.LayoutType.TwoColumnsMidExpanded,
					request: request,
				});
			} else {
				var oHistory, sPreviousHash;
				oHistory = History.getInstance();
				sPreviousHash = oHistory.getPreviousHash();

				if (sPreviousHash !== undefined) {
					window.history.go(-1);
				} else {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					oRouter.navTo("", true);
				}
			}
		},
		_validateRac: function (rac, msg, that) {
			if (rac.getValue().length !== 7 || rac.getValue()[0] !== "5") {
				rac.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText(msg));
				return false;
			} else {
				that.resetValueState(rac);
				return true;
			}
		},
		_odatareadset: function (sURL, osetName, oModelName, sMessage, ofilter) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			that.oGlobalBusyDialog.open();
			ODataHelper.callODataREAD(oDataModel, osetName, ofilter)
				.then(function onSuccess(oData, oResponse) {
					var oModel = new JSONModel();
					oModel.setData({
						data: oData.results
					});
					that.getView().setModel(oModel, oModelName);
					that.oGlobalBusyDialog.close();
				})
				.catch(function onError(oError) {
					MessageToast.show(that.getMessageBundleText(sMessage));
					that.oGlobalBusyDialog.close();
				});
		},
		//Adds new line in the table for company code and FSG
		_addNewRowGL: function (oEvent, tbl_id, oModel, req, subreq) {
			var oTableModel = this.getView().byId(tbl_id).getModel(oModel);
			var items = oTableModel.getProperty("/data");
			if (items.length < Constants.MAX_TAGS) {
				var simpleData = {
					"ItemNo": items.length + 1,
					"FimReq": req,
					"SubreqNo": subreq,
					"CompCode": "",
					"FldStgrp": ""
				};
				items.push(simpleData);
				oTableModel.setProperty("/data", items);
			} else {
				MessageToast.show(this.getMessageBundleText("msg.val.maxTagLimitReached", [Constants.MAX_TAGS]));
			}
		},
		//Delete the row in table for company code ans FSG
		_removeRowGL: function (oEvent, tbl_id, oModel) {
			var sPath = oEvent.getSource().getBindingContext(oModel).getPath();
			var iRowIndex = sPath.split('/')[2];
			var oTableModel = this.getView().byId(tbl_id).getModel(oModel);
			var aItems = oTableModel.getProperty("/data");
			aItems.splice(iRowIndex, 1);
			//Refresh the row numbers (Item No.) in the table
			for (var i = 0; i < aItems.length; i++) {
				aItems[i].ItemNo = i + 1;
			}
			oTableModel.setProperty("/data", aItems);
			oTableModel.refresh();
		},
		/**
		 * Validation method to check if the entered value in combobox field matches with one of the keys
		 * @public
		 * @returns {boolean} the resourceModel of the component
		 */
		validateComboBox: function (oField, sMsgKey) {
			var sSelectedKey = oField.getSelectedKey();
			var sValue = oField.getValue();
			if (!sSelectedKey && sValue) {
				oField.setValueState(sap.ui.core.ValueState.Error);
				oField.setValueStateText(this.getMessageBundleText(sMsgKey));
				return false;
			} else {
				oField.setValueState(sap.ui.core.ValueState.None);
				oField.setValueStateText("");
			}
			return true;
		},
		checkOnSelection: function (oEvent) {
			var oInput = oEvent.getSource();
			var bValid = oInput.getSelectedKey();
			oInput.setValueState(!bValid ? "Error" : "None");
			return bValid;
		},
		//Validate GlRevenue Manually
		_validateGlrevenue: function (glrev, msg, that) {
			if (glrev.getValue().length !== 7) {
				glrev.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText(msg));
				return false;
			} else {
				if (glrev.getValue()[0] !== "4") {
					glrev.setValueState(sap.ui.core.ValueState.Error);
					var Glrevmsg = that.getResourceBundleText("msg.err.GlrevmatchError");
					MessageToast.show(that.getMessageBundleText(Glrevmsg));
					return false;
				} else {
					that.resetValueState(glrev);
					return true;
				}
			}
		},
		_validateRac: function (rac, msg, that) {
			if (rac.getValue().length !== 7) {
				rac.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText(msg));
				return false;
			} else {
				if (rac.getValue()[0] !== "5") {
					rac.setValueState(sap.ui.core.ValueState.Error);
					var Racmsg = that.getResourceBundleText("msg.err.Racmatcherror");
					MessageToast.show(that.getMessageBundleText(Racmsg));
					return false;
				} else {
					that.resetValueState(rac);
					return true;
				}
			}
		},
		/**
		 * Validation method to check if the entered value in input field matches with one of the entries
		 * @public
		 * @returns {boolean} the resourceModel of the component
		 */
		validateSuggestions: function (oField, sValue, sKeyName, data, sMsgKey) {
			var found = false;
			for (var i = 0; i < data.length; i++) {
				if (data[i][sKeyName] === sValue) {
					found = true;
				}
			}
			if (!found) {
				oField.setValueState(sap.ui.core.ValueState.Error);
				oField.setValueStateText(this.getMessageBundleText(sMsgKey));
			} else {
				oField.setValueState(sap.ui.core.ValueState.None);
				oField.setValueStateText("");
			}
			return found;
		},

		/**
		 * Validation method to check if value in the provided field is empty
		 * @public
		 * @returns {boolean} the resourceModel of the component
		 */
		validateFieldNotEmpty: function (oField, sMsgKey) {
			var sValue = oField.getValue();
			if (sValue === null || sValue === "") {
				oField.setValueState(sap.ui.core.ValueState.Error);
				oField.setValueStateText(this.getMessageBundleText(sMsgKey));
				// MessageToast.show(this.getMessageBundleText(sMsgKey));
				return false;
			}
			return true;
		},

		/**
		 * Validate field value greater than zero
		 * @public
		 * @returns {boolean}
		 */
		validateGTZero: function (oField, sMsgKey) {
			var sValue = Utility.parseFloatValue(oField.getValue());
			if (sValue <= 0) {
				oField.setValueState(sap.ui.core.ValueState.Error);
				oField.setValueStateText(this.getMessageBundleText(sMsgKey));
				return false;
			} else {
				oField.setValueState(sap.ui.core.ValueState.None);
				oField.setValueStateText("");
			}
			return true;
		},

		resetValueState: function (oField) {
			oField.setValueState(sap.ui.core.ValueState.None);
			oField.setValueStateText("");
		},
		onOnlyInteger: function (oEvent) {
			var value = oEvent.getSource().getValue().replace(/[^\d]/g, '');
			oEvent.getSource().setValue(value);
		},
		onPressCancel: function (oEvt) {
			var GLSubModel = this.getView().getModel("GLSubModel");
			var oFsgTableModel = new JSONModel();
			oFsgTableModel.setData({
				"data": [{
					"ItemNo": 1,
					"FimReq": GLSubModel.getData().data.FimReq,
					"SubreqNo": GLSubModel.getData().data.subreqno,
					"CompCode": "",
					"FldStgrp": ""
				}]
			});
			this.getView().setModel(oFsgTableModel, "FsgTableModel");
			this._clearScreenValues(this);
			var oModel = new JSONModel();
			oModel.setData({
				"EditFields": true,
				"EditGLField": true,
				"EditRefFields": true,
				"BSVisible": false,
				"Openitem": true,
				"REVVisible": false,
				"Groupac": true,
				"DirectorEdit": false,
				"PLVisible": false
			});
			this.getView().setModel(oModel, "EditModel");
		},
		_FormatDate: function (sDate) {
			if (!sDate) {
				return sDate;
			}
			var sdateformat = DateFormat.getDateTimeInstance({
					pattern: "yyyy.MM.dd"
				},
				sap.ui.getCore().getConfiguration().getLocale());
			var modifieddate = sdateformat.format(sDate, true); // returns: "2020/08/09"
			return modifieddate;
		},
		_populateTaxCat: function () {
			var oTaxCatModel = new JSONModel();
			oTaxCatModel.setData({
				"data": [{
					"TaxCategory": this.getResourceBundleText("item.taxcat1"),
					"TaxCatDen": this.getResourceBundleText("item.taxdesc1"),
					"TaxCatWhen": this.getResourceBundleText("item.taxwhen1"),
					"TaxCatNot": this.getResourceBundleText("item.taxnot1"),
					"TaxCatCheck": this.getResourceBundleText("item.taxnot1")
				}, {
					"TaxCategory": this.getResourceBundleText("item.taxcat2"),
					"TaxCatDen": this.getResourceBundleText("item.taxdesc2"),
					"TaxCatWhen": this.getResourceBundleText("item.taxwhen2"),
					"TaxCatNot": this.getResourceBundleText("item.taxnot2"),
					"TaxCatCheck": this.getResourceBundleText("item.taxcheck2")
				}, {
					"TaxCategory": this.getResourceBundleText("item.taxcat3"),
					"TaxCatDen": this.getResourceBundleText("item.taxdesc3"),
					"TaxCatWhen": this.getResourceBundleText("item.taxwhen3"),
					"TaxCatNot": this.getResourceBundleText("item.taxnot3"),
					"TaxCatCheck": this.getResourceBundleText("item.taxcheck3")
				}, {
					"TaxCategory": this.getResourceBundleText("item.taxcat4"),
					"TaxCatDen": this.getResourceBundleText("item.taxdesc4"),
					"TaxCatWhen": this.getResourceBundleText("item.taxwhen4"),
					"TaxCatNot": this.getResourceBundleText("item.taxnot4"),
					"TaxCatCheck": this.getResourceBundleText("item.taxcheck4")
				}, {
					"TaxCategory": this.getResourceBundleText("item.taxcat5"),
					"TaxCatDen": this.getResourceBundleText("item.taxdesc5"),
					"TaxCatWhen": this.getResourceBundleText("item.taxwhen5"),
					"TaxCatNot": this.getResourceBundleText("item.taxnot4"),
					"TaxCatCheck": this.getResourceBundleText("item.taxcheck4")
				}, {
					"TaxCategory": this.getResourceBundleText("item.taxcat6"),
					"TaxCatDen": this.getResourceBundleText("item.taxdesc6"),
					"TaxCatWhen": this.getResourceBundleText("item.taxwhen6"),
					"TaxCatNot": this.getResourceBundleText("item.taxnot2"),
					"TaxCatCheck": this.getResourceBundleText("item.taxcheck2")
				}]
			});
			this.getView().setModel(oTaxCatModel, "TaxCatModel");
		},
		onPressTaxHelp: function (oEvt) {
			var oView = this.getView();
			var fragmenttaxcat = "FIM.FIM.view.fragment.TaxCatHelp";
			this.oGlobalBusyDialog.open();
			if (!this.byId("dlg_taxcathelp")) {
				Fragment.load({
					id: oView.getId(),
					name: fragmenttaxcat,
					type: "XML",
					controller: this
				}).then(function (oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
				this._oDialogfragmenttaxcat = sap.ui.xmlfragment(fragmenttaxcat, this);
			} else {
				this.byId("dlg_taxcathelp").open();
			}
			this.oGlobalBusyDialog.close();
		},
		onCloseF4TaxCat: function (oEvt) {
			this.byId("dlg_taxcathelp").close();
		},
		_revTypecodeHelpText: function () {
			var oRevTypeCodeModel = new JSONModel();
			oRevTypeCodeModel.setData({
				"data": [{
					"Number": this.getResourceBundleText("row1item.number"),
					"CodeDesc": this.getResourceBundleText("row1item.codedesc"),
					"Whento": this.getResourceBundleText("row1item.whento")
				}, {
					"Number": this.getResourceBundleText("row2item.number"),
					"CodeDesc": this.getResourceBundleText("row2item.codedesc"),
					"Whento": this.getResourceBundleText("row2item.whento")

				}, {
					"Number": this.getResourceBundleText("row3item.number"),
					"CodeDesc": this.getResourceBundleText("row3item.codedesc"),
					"Whento": this.getResourceBundleText("row3item.whento")

				}, {
					"Number": this.getResourceBundleText("row4item.number"),
					"CodeDesc": this.getResourceBundleText("row4item.codedesc"),
					"Whento": this.getResourceBundleText("row4item.whento")
				}, {
					"Number": this.getResourceBundleText("row5item.number"),
					"CodeDesc": this.getResourceBundleText("row5item.codedesc"),
					"Whento": this.getResourceBundleText("row5item.whento")

				}, {
					"Number": this.getResourceBundleText("row6item.number"),
					"CodeDesc": this.getResourceBundleText("row6item.codedesc"),
					"Whento": this.getResourceBundleText("row6item.whento")

				}, {
					"Number": this.getResourceBundleText("row7item.number"),
					"CodeDesc": this.getResourceBundleText("row7item.codedesc"),
					"Whento": this.getResourceBundleText("row7item.whento")

				}, {
					"Number": this.getResourceBundleText("row8item.number"),
					"CodeDesc": this.getResourceBundleText("row8item.codedesc"),
					"Whento": this.getResourceBundleText("row8item.whento")
				}]
			});
			this.getView().setModel(oRevTypeCodeModel, "RevTypeCodeModel");
		},
		onPressrevcodeHelp: function (oEvt) {
			var oView = this.getView();
			var fragmentrevtypecode = "FIM.FIM.view.fragment.RevTypeCodeHelp";
			this.oGlobalBusyDialog.open();
			if (!this.byId("dlg_revtypecodehelp")) {
				Fragment.load({
					id: oView.getId(),
					name: fragmentrevtypecode,
					type: "XML",
					controller: this
				}).then(function (oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
				this._oDialogfragmentrevtypecode = sap.ui.xmlfragment(fragmentrevtypecode, this);
			} else {
				this.byId("dlg_revtypecodehelp").open();
			}
			this.oGlobalBusyDialog.close();
		},
		// onSubmitPstamt: function (oEvt) {
		// 	var balance = this.getView().byId("ip_pstamt").getValue();
		// 	if (balance.length > 9 && balance !== null && balance !== undefined && balance[0] !== "$") {
		// 		this.getView().byId("ip_pstamt").setValueState(sap.ui.core.ValueState.Error);
		// 		this.getView().byId("ip_pstamt").setValue("");
		// 		MessageToast.show(this.getMessageBundleText("msg.err.Invalidlength"));
		// 		return false;
		// 	} else {
		// 		this.resetValueState(this.getView().byId("ip_pstamt"));
		// 	}
		// 	if (balance[0] !== "$") {
		// 		var val = this.formatamount(balance);
		// 		this.getView().byId("ip_pstamt").setValue(val);
		// 	}
		// 	return true;
		// },
		onSubmitAnnual: function (oEvt) {
			// if (!this._validateValue(this.getView().byId("ip_balance"), "msg.val.invalidannual", this)) {
			// 	return false;
			// }
			// return true;
			var balance = this.getView().byId("ip_balance").getValue();
			if (balance.length > 9 && balance !== null && balance !== undefined && balance[0] !== "$") {
				this.getView().byId("ip_balance").setValueState(sap.ui.core.ValueState.Error);
				this.getView().byId("ip_balance").setValue("");
				MessageToast.show(this.getMessageBundleText("msg.err.Invalidlength"));
				return false;
			} else {
				this.resetValueState(this.getView().byId("ip_balance"));
			}
			if (balance[0] !== "$") {
				if (balance[0] === "0" && balance.length > 1) {
					balance = this.trimLeadingZeros(balance);
				}
				var val = this.formatamount(balance);
				this.getView().byId("ip_balance").setValue(val);
			}
			return true;
		},
		trimLeadingZeros: function (sVal) {
			var sResult = "";
			if (sVal) {
				sResult = sVal.replace(/^0+/, '');
				// if only zeros, return one 0
				if (!sResult) {
					sResult = "0";
				}
			}
			return sResult;
		},
		onSubmitPstamt: function (oEvt) {
			
			var balance = this.getView().byId("ip_pstamt").getValue();
			if (balance.length > 9 && balance !== null && balance !== undefined && balance[0] !== "$") {
				this.getView().byId("ip_pstamt").setValueState(sap.ui.core.ValueState.Error);
				this.getView().byId("ip_pstamt").setValue("");
				MessageToast.show(this.getMessageBundleText("msg.err.Invalidlength"));
				return false;
			} else {
				this.resetValueState(this.getView().byId("ip_pstamt"));
			}
			if (balance[0] !== "$") {
				//remove leading zeros as they are not valid
				if (balance[0] === "0" && balance.length > 1) {
					balance = this.trimLeadingZeros(balance);
				}
				var val = this.formatamount(balance);
				this.getView().byId("ip_pstamt").setValue(val);
			}
			return true;
		},
		formatamount: function (balance) {

			var sapLanguage = sap.ui.getCore().getConfiguration().getLanguage();

			sap.ui.getCore().getConfiguration().setLanguage("en");
			var oCurrencyFormat = NumberFormat.getCurrencyInstance({
				currencyCode: false
			});
			var result = oCurrencyFormat.format(balance.split(" ")[0], "USD").split('.')[0];

			sap.ui.getCore().getConfiguration().setLanguage(sapLanguage);
			return result;
		},
		parseamount: function (balance) {
			var sapLanguage = sap.ui.getCore().getConfiguration().getLanguage();
			sap.ui.getCore().getConfiguration().setLanguage("en");
			var oCurrencyFormat = NumberFormat.getCurrencyInstance({
				currencyCode: false
			});
			var result = oCurrencyFormat.parse(balance)[0];
			sap.ui.getCore().getConfiguration().setLanguage(sapLanguage);
			return result.toString();
		},
		onCloseF4RevTypeCode: function (oEvt) {
			this.byId("dlg_revtypecodehelp").close();
		},
		_loadcheckbox: function (oData, that) {
			//CheckBoxes
			if (oData.RelCashFlow === "X") {
				that.getView().byId("cb_relevantcash").setSelected(true);
			}
			if (oData.LineItemDis === "X") {
				that.getView().byId("cb_lineitem").setSelected(true);
			}
			var oEditModel = that.getView().getModel("EditModel");
			if (oData.ReconAcTyp !== undefined && oData.ReconAcTyp !== null && oData.ReconAcTyp !== "") {
				oEditModel.setProperty("/Openitem", false);
				that.getView().byId("cb_openitem").setSelected(false);
			} else if (oData.OpenItemMt === "X") {
				oEditModel.setProperty("/Openitem", true);
				that.getView().byId("cb_openitem").setSelected(true);
			}
			that.getView().setModel(oEditModel, "EditModel");
			if (oData.BalLocCurr === "X") {
				that.getView().byId("cb_balancelocal").setSelected(true);
			}
			if (oData.PostingWta === "X") {
				that.getView().byId("cb_withouttax").setSelected(true);
			}
		}
	});
});