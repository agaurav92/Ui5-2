sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"../Util/OdataHelper",
	"../Util/Constants",
	"sap/f/library",
	"../Util/Utility"
], function (BaseController, MessageBox, JSONModel, Filter, MessageToast, Fragment, ODataHelper, Constants, fioriLibrary, Utility) {
	"use strict";

	return BaseController.extend("FIM.FIM.controller.RacCancel", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf FIM.FIM.view.RacCancel
		 */
		onInit: function () {
			//Initialize busy indicator
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			this.oGlobalBusyDialog.open();
			// // Router login
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteRacCancel").attachMatched(this._onRouteFound, this);
			//populate RAC code
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/RAVTypeSet", "RAVTypeModel",
				"msg.err.RevTypeFetchError");
			// //populate Tax Status
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/TaxStatSet", "TaxStatusModel",
				"msg.err.TaxStatusFetchError");
			// RevType code Help text
			this._revTypecodeHelpText();
			this.oGlobalBusyDialog.close();
		},

		_onRouteFound: function (oEvt) {
			var oArgument = oEvt.getParameter("arguments");
			var oModel = new JSONModel();
			if ((oArgument.SelectItem === Constants.EDITREQUEST)) {
				oModel.setData({
					"EditFields": true,
					"EditRACField": true,
				});
			} else {
				oModel.setData({
					"EditFields": false,
					"EditRACField": false,
				});
			}
			this.getView().setModel(oModel, "EditModel");
			//Initialize and bind input elements
			if (oArgument.SubReq !== undefined && oArgument.SubReq !== "") {
				var oGLSubModel = new JSONModel();
				oGLSubModel.setData({
					"FimReq": oArgument.request,
					"subreqno": oArgument.SubReq,
				});
				this.getView().setModel(oGLSubModel, "RACCancelSubModel");
				//load existing data of the Subrequest which is already saved in the table
				this._loadsubrequest(oArgument.request, oArgument.SubReq, Constants.GL_SRV_URL);
			}
		},

		_loadsubrequest: function (request, subrequest, sURL) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			this.oGlobalBusyDialog.open();
			oDataModel.read("/GLItemSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')", {
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						"GlNum": oData.GlNum,
						"RecycleCode": oData.RecycleCode,
						"Coa": oData.Coa,
						"GlRev": oData.GlRev,
						"RevTypeCode": oData.RevTypeCode,
						"TeleTaxStatus": oData.TeleTaxStatus,
						"Type": oData.Type,
						"Explanation": oData.Explanation,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
						"Notes": oData.Notes
					});
					that.getView().setModel(oModel, "RACCancelModel");
					if (oData.GlNum !== undefined && oData.GlNum !== null && oData.GlNum !== "") {
						that._setEditModel(that);
					}
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "RACCancelModel");
					MessageToast.show(that.getMessageBundleText("msg.err.subreqFetchError", [subrequest]));

				}
			});
		},
		_setEditModel: function (that) {
			var oEditModel = that.getView().getModel("EditModel");
			oEditModel.setProperty("/EditRACField", false);
			that.getView().setModel(oEditModel, "EditModel");
		},
		_loadExpl: function (sGl) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			// oFilter.push(new sap.ui.model.Filter("ImGl", "EQ", sGl));
			this.oGlobalBusyDialog.open();
			var setname = "/GLModifySet(GlNum='" + sGl + "',Category='" + Constants.RAC + "')";
			oDataModel.read(setname, {
				success: function (oData, response) {
					// that.getView().byId("ip_explain").setValue(oData.Explanation);
					that.getView().byId("ip_descen").setValue(oData.DescEn);
					that.getView().byId("ip_descfr").setValue(oData.DescFr);
					that.getView().byId("ip_titleen").setValue(oData.LtextEn);
					that.getView().byId("ip_titlefr").setValue(oData.LtextFr);
					that.getView().byId("cb_revtypecode").setSelectedKey(oData.RevTypeCode);
					that.getView().byId("cb_taxstatus").setSelectedKey(oData.TeleTaxStatus);
					that.oGlobalBusyDialog.close();
				},
				error: function (oError) {
					// MessageToast.show("Error fetching Explanation based on GL");
					that.oGlobalBusyDialog.close();
				}
			});
		},

		//Combobox validations
		onValidateCombo: function (oEvent) {
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (sComboId === "cb_revtypecode" || sComboId === "cb_taxstatus") {
				if (!this.checkOnSelection(oEvent)) {
					this.getView().byId(sComboId).setSelectedKey("");
					return;
				}
			} else if (value !== "") {
				if (!this.checkOnSelection(oEvent)) return;
			} else {
				oEvent.getSource().setValueState("None");
			}
		},

		onPressCancelRac: function (oEvt) {
			this._clearScreenValues(this);
		},
		_clearScreenValues: function (that) {
			this.resetValueState(this.getView().byId("cb_revtypecode"));
			this.resetValueState(this.getView().byId("cb_taxstatus"));
			this.resetValueState(this.getView().byId("ip_raccode"));

			var oEditModel = that.getView().getModel("EditModel");
			oEditModel.setProperty("/EditRACField", true);
			that.getView().setModel(oEditModel, "EditModel");
			var oRACCreateModel = new JSONModel();
			that.getView().setModel(oRACCreateModel, "RACCancelModel");
			// Account Tab
			that.getView().byId("ip_raccode").setValue("");
			that.getView().byId("ip_sapglrev").setValue("");
			that.getView().byId("cb_revtypecode").setSelectedKey("");
			that.getView().byId("cb_taxstatus").setSelectedKey("");
			// Explanation Tab
			that.getView().byId("ip_explain").setValue("");
			// Description Tab
			that.getView().byId("ip_titleen").setValue();
			that.getView().byId("ip_titlefr").setValue();
			that.getView().byId("ip_descen").setValue();
			that.getView().byId("ip_descfr").setValue();
			// CoCd tab
			that.getView().byId("ip_notes").setValue();

			//set the first tab as default
			that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
			that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
			that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
		},
		//For Save Button
		onPressSaveRac: function (oEvt) {
			var Rac = this.getView().byId("ip_raccode");
			if (!this._validateRac(Rac, "msg.val.RacError", this)) {
				return false;
			}

			var oEntry = {};
			var oRACSubModel = this.getView().getModel("RACCancelModel");
			var oRACRequestModel = this.getView().getModel("RACCancelSubModel");
			// Account Tab
			oEntry.GlNum = oRACSubModel.getData().GlNum;
			oEntry.FimReq = oRACRequestModel.getData().FimReq;
			oEntry.SubreqNo = oRACRequestModel.getData().subreqno;
			oEntry.Actionid = Constants.CANCEL;
			oEntry.Category = Constants.RAC;
			oEntry.Coa = this.getView().byId("ip_chartacc").getValue();
			oEntry.RevTypeCode = this.getView().byId("cb_revtypecode").getSelectedKey();
			oEntry.GlRev = this.getView().byId("ip_sapglrev").getValue();
			oEntry.Type = Constants.RAC;
			oEntry.TeleTaxStatus = this.getView().byId("cb_taxstatus").getSelectedKey();
			oEntry.Explanation = this.getView().byId("ip_explain").getValue();
			// Description Tab
			oEntry.LtextEn = this.getView().byId("ip_titleen").getValue();
			oEntry.LtextFr = this.getView().byId("ip_titlefr").getValue();
			oEntry.DescEn = this.getView().byId("ip_descen").getValue();
			oEntry.DescFr = this.getView().byId("ip_descfr").getValue();
			// CoCd tab
			// oEntry.Notes = oRACSubModel.getData().Notes;
			oEntry.Notes = this.getView().byId("ip_notes").getValue();
			var subModel = this.getView().getModel("RACCancelSubModel");
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			var setname = "/GLItemSet(FimReq='" + oRACRequestModel.getData().FimReq + "',SubreqNo='" + oRACRequestModel.getData().subreqno +
				"')";
			ODataHelper.callODataUPDATE(oDataModel, setname, oEntry)
				.then(function onSuccess(oResult, oResponse) {
					that.oGlobalBusyDialog.close();
					that._clearScreenValues(that);
					var msg = that.getMessageBundleText("msg.success.submitForm", [subModel.getData().subreqno]);
					//Show success message and return to 1st screen
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								that.onNavigateBack(oEvt, that, subModel.getData().FimReq, "RouteRacCancel");
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				});
		},
		//Validations for RAC Code
		onSubmitManualRAC: function (oEvt) {
			var Rac = this.getView().byId("ip_raccode");
			if (!this._validateRac(Rac, "msg.val.RacError", this)) {
				return false;
			}
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			var oRACCreateModel = this.getView().getModel("RACCancelModel");
			var oFilter = [];
			this.oGlobalBusyDialog.open();
			var setname = "/RACValidSet('" + Rac.getValue() + "')";
			oDataModel.read(setname, {
				success: function (oData, response) {
					oRACCreateModel.setProperty("/GlNum", Rac.getValue()); //RacNum deleted from Odata/Table
					that.getView().byId("ip_sapglrev").setValue(oData.Newacct);
					that._loadExpl(Rac.getValue());
					that.getView().setModel(oRACCreateModel, "RACCancelModel");
					that._setEditModel(that);
					that.oGlobalBusyDialog.close();
				},
				error: function (oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
				}
			});
		},
		onPressDeleteSub: function (oEvt) {
			var RacSubModel = this.getView().getModel("RACCancelSubModel");
			this._deleteSubRequest(RacSubModel.getData().FimReq, RacSubModel.getData().subreqno, oEvt, this);
		},
		onNavBack: function (oEvt) {
			var subModel = this.getView().getModel("RACCancelSubModel");
			var request = subModel.getData().FimReq;
			this._clearScreenValues(this);
			this.onNavigateBack(oEvt, this, request, "RouteRacCancel");
		}

	});

});