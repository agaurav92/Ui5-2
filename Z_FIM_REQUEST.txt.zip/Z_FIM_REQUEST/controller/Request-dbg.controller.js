sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/format/DateFormat",
	"../Util/Constants",
	"../Util/MyFormatter",
	"../Util/OdataHelper",
	'sap/ui/model/Sorter',
	'sap/m/MessageBox',
	"sap/ui/core/Fragment",
	"sap/m/MessageToast",
	'sap/f/library'
], function (BaseController, JSONModel, Filter, FilterOperator, DateFormat, Constants, MyFormatter, ODataHelper, Sorter, MessageBox,
	Fragment,
	MessageToast, fioriLibrary) {
	"use strict";

	return BaseController.extend("FIM.FIM.controller.Request", {
		onInit: function () {
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			this._bDescendingSort = false;
			this.oRequestTable = this.oView.byId("tbl_request");

			this.oRouter = this.getOwnerComponent().getRouter();

			this.oRouter.getRoute("request").attachMatched(this._onloadRequest, this);
			this.oRouter.getRoute("subrequest").attachMatched(this._onloadRequest, this);
			var oModel = new JSONModel();
			var erdat = this._FormatDate(new Date());
			oModel.setData({
				"Erdat": erdat,
				"statusDate": erdat
			});
			this.getView().setModel(oModel, "CreateReqModel");
			this._getUserInfo();
			// this._odatareadset(Constants.VALUEHELP_SRV_URL, "/UserInfoSet", "UserModel", "msg.err.UserdetailsError");

		},
		_getUserInfo: function () {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			oDataModel.read("/UserInfoSet", {
				success: function onSuccess(oData, oResponse) {
					that.oGlobalBusyDialog.close();
					var oUserModel = new JSONModel();
					oUserModel.setData({
						data: oData.results
					});
					that.getView().setModel(oUserModel, "UserModel");
					if (oData.results[0].Admin !== "X" && oData.results[0].GLReq !== "X") {
						that.getView().byId("bt_create").setVisible(false);
						that.getView().byId("sf_search").setVisible(false);
						that.getView().byId("cb_status").setVisible(false);
						that.getView().byId("tbl_request").setVisible(false);
						var sVal = that.getMessageBundleText("msg.err.requestcheck");
						var msgTitle = that.getResourceBundleText("title.errorMessage");
						sap.m.MessageBox.error(sVal, {
							title: msgTitle, // default
							onClose: null, // default
							styleClass: "", // default
							actions: sap.m.MessageBox.Action.CLOSE, // default
							emphasizedAction: null, // default
							initialFocus: null, // default
							textDirection: sap.ui.core.TextDirection.Inherit // default
						});
					} else {
						that.getView().byId("bt_create").setVisible(true);
						that.getView().byId("sf_search").setVisible(true);
						that.getView().byId("cb_status").setVisible(true);
						that.getView().byId("tbl_request").setVisible(true);
					}
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					MessageToast.show(that.getMessageBundleText("msg.err.UserdetailsError", []));
				}
			});
		},
		handleChange: function (oEvent) {
			var oDP = oEvent.getSource(),
				sValue = oEvent.getParameter("value"),
				bValid = oEvent.getParameter("valid");
			if (bValid) {
				oDP.setValueState(sap.ui.core.ValueState.None);
			} else {
				this.getView().byId("ip_effective").setValue("");
				oDP.setValueState(sap.ui.core.ValueState.Error);
			}
		},
		_onloadRequest: function (oEvt) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			ODataHelper.callODataREAD(oDataModel, "/GLHeaderSet")
				.then(function onSuccess(oData, oResponse) {
					var oRequestModel = new JSONModel();
					var value = oData;
					//Format data 
					var tDate = "";
					for (var i = 0; i < value.results.length; i++) {
						tDate = value.results[i].Erdat;
						if (tDate !== undefined && tDate !== null) {
							value.results[i].Erdat = that._FormatDate(tDate);
						}
					}
					oRequestModel.setData({
						data: value.results
					});

					that.getView().setModel(oRequestModel, "RequestModel");

					that.oGlobalBusyDialog.close();
				})
				.catch(function onError(oError) {
					MessageToast.show(that.getMessageBundleText("msg.err.RequestFetchError", []));

					that.oGlobalBusyDialog.close();
				});
		},
		_ParseDate: function (sDate) {
			if (!sDate) {
				return sDate;
			}
			var sdateformat = DateFormat.getDateTimeInstance({
					pattern: "yyyy.MM.dd"
				},
				sap.ui.getCore().getConfiguration().getLocale());
			return sdateformat.parse(sDate); // parse to, for ex: Sat Aug 01 2020 00:00:00 <timezone information,ex:GMT-0400>
		},
		onSearch: function (oEvent) {
			var oTableSearchState = [],
				sQuery = oEvent.getParameter("query");
			if (sQuery && sQuery.length > 0) {
				oTableSearchState = [new Filter("FimReq", FilterOperator.Contains, sQuery)];
			}
			this.oRequestTable.getBinding("items").filter(oTableSearchState, "Application");
		},
		onSelectStatus: function (oEvent) {
			var bValid = oEvent.getSource().getSelectedKey();
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (value !== "") {
				if (!this.checkOnSelection(oEvent)) {
					// this.getView().byId("cb_status").setSelectedKey("");
					return;
				}
			} else {
				this.getView().byId(sComboId).setValueState(sap.ui.core.ValueState.None);
				this.getView().byId(sComboId).setValueStateText("");
			}
			var oFilter = [];
			var oValue = oEvent.mParameters.newValue;
			// if (oValue === "All") {
			// 	oValue = "";
			// }
			var oTableId = this.getView().byId("tbl_request");
			oFilter = [new Filter("Status", FilterOperator.Contains, oValue)];
			oTableId.getBinding("items").filter(oFilter);
		},

		onCreateRequest: function (oEvent) {
			var oView = this.getView();
			var fragmentCreateRequest = "FIM.FIM.view.fragment.CreateRequest";
			if (!this.dlg_req) {
				this.dlg_req = this.loadFragment({
					name: fragmentCreateRequest
				});
				this.dlg_req.then(function (oDialog) {
					oDialog.open();
				});
			} else {
				this.byId("dlg_createrequest").open();
			}
		},
		onCloseCreateRequest: function (oEvent) {
			this._clearCreateRequest();
			this.byId("dlg_createrequest").close();
		},
		_clearCreateRequest: function () {
			this.resetValueState(this.getView().byId("ip_Company"));
			this.resetValueState(this.getView().byId("ip_Dept"));
			this.resetValueState(this.getView().byId("ip_effective"));
			this.getView().byId("ip_Company").setValue("");
			this.getView().byId("ip_Dept").setValue("");
			this.getView().byId("ip_effective").setValue("");
			this.resetValueState(this.getView().byId("ip_effective"));
		},
		onSaveRequest: function (oEvent) {
			var oRequestModel = this.getView().byId("tbl_request").getModel("RequestModel");
			var that = this;
			var oEntry = {};
			oEntry.Ernam = this.getView().byId("ip_createdby").getValue();
			oEntry.Zname = this.getView().byId("ip_name").getValue();
			var erdat = this.getView().byId("ip_Creationdate").getValue();
			oEntry.Erdat = this._correctDateFormat(erdat);
			oEntry.Erzet = "PT10H51M03S";
			oEntry.Status = this.getView().byId("ip_Status").getValue();
			var statusdate = this.getView().byId("ip_Statusdate").getValue();

			oEntry.StatusDtTim = this._correctDateFormat(statusdate);
			oEntry.CompName = this.getView().byId("ip_Company").getValue();
			oEntry.Dept = this.getView().byId("ip_Dept").getValue();
			var effdate = this.getView().byId("ip_effective").getValue();
			oEntry.Effdate = this._correctDateFormat(effdate);
			if (oEntry.CompName === "" || oEntry.CompName === undefined || oEntry.CompName === null) {
				this.getView().byId("ip_Company").setValueState(sap.ui.core.ValueState.Error);
				return false;
			} else {
				this.resetValueState(this.getView().byId("ip_Company"));
			}
			if (oEntry.Dept === "" || oEntry.Dept === undefined || oEntry.Dept === null) {
				this.getView().byId("ip_Dept").setValueState(sap.ui.core.ValueState.Error);
				return false;
			} else {
				this.resetValueState(this.getView().byId("ip_Dept"));
			}
			if (oEntry.Effdate === "T00:00:00" || oEntry.Effdate === "") {
				this.getView().byId("ip_effective").setValueState(sap.ui.core.ValueState.Error);
				this.getView().byId("ip_effective").setValue("");
				return false;
			} else {
				this.resetValueState(this.getView().byId("ip_effective"));
			}
			this.oGlobalBusyDialog.open();
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			ODataHelper.callODataCREATE(oDataModel, "/GLHeaderSet", oEntry)
				.then(function onSuccess(oResult, oResponse) {
					//Scenario: Submission is successful. 
					var items = oRequestModel.getProperty("/data");
					oResult.Erdat = that._FormatDate(oResult.Erdat);
					// items.push(createdrequest);
					items.push(oResult);
					oRequestModel.setProperty("/data", items);
					sap.ui.getCore().setModel(oRequestModel, "RequestModel");
					var msg = that.getMessageBundleText("msg.suc.RequestCreate", [oResult.FimReq]);
					that.oGlobalBusyDialog.close();
					//Show success message and return to 1st screen
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								return;
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});

				})
				.catch(function onError(oError) {
					MessageToast.show(that.getMessageBundleText("msg.err.CreateRequestError", []));
					that.oGlobalBusyDialog.close();
					return;
				});
			this._clearCreateRequest();
			this.byId("dlg_createrequest").close();
		},

		onRequestNavigate: function (oEvent) {
			var sPath = oEvent.getSource().getBindingContextPath(); //spath will return data/rowindex selected
			var iRowIndex = sPath.split('/')[2];
			var oRequestModel = this.getView().getModel("RequestModel");
			var requestdata = oRequestModel.getData().data[iRowIndex].FimReq;
			var layout = fioriLibrary.LayoutType.TwoColumnsMidExpanded;
			this.oRouter.navTo("subrequest", {
				layout: layout,
				request: requestdata,
			});
		}
	});

});