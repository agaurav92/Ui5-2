sap.ui.define([
			"./BaseController",
			"sap/m/MessageBox",
			"sap/ui/model/json/JSONModel",
			"sap/ui/model/Filter",
			"sap/m/MessageToast",
			"sap/ui/core/Fragment",
			"../Util/OdataHelper",
			"../Util/Constants",
			"../Util/Utility"
		], function (BaseController, MessageBox, JSONModel, Filter, MessageToast, Fragment, ODataHelper, Constants, Utility) {
			"use strict";

			return BaseController.extend("FIM.FIM.controller.GLCancel", {
					/**
					 * Called when a controller is instantiated and its View controls (if available) are already created.
					 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
					 * @memberOf FIM.FIM.view.GLCancel
					 */
					onInit: function () {
						//Initialize busy indicator
						this.oGlobalBusyDialog = new sap.m.BusyDialog();
						this.oGlobalBusyDialog.open();
						// // Router login
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.getRoute("RouteGLCancel").attachMatched(this._onRouteFound, this);
						this._odatareadset(Constants.VALUEHELP_SRV_URL, "/BSCombinedSet", "directModel", "msg.err.DirectorFetchError");

						this.oGlobalBusyDialog.close();
					},
					_onRouteFound: function (oEvt) {
						var oArgument = oEvt.getParameter("arguments");
						var oModel = new JSONModel();
						if ((oArgument.SelectItem === Constants.EDITREQUEST)) {

							oModel.setData({
								"EditFields": true,
								"EditGLField": true,
								"BSVisible": false
							});
						} else {
							oModel.setData({
								"EditFields": false,
								"EditGLField": false,
								"BSVisible": true
							});
						}
						this.getView().setModel(oModel, "EditModel");
						//Initialize and bind input elements
						if (oArgument.SubReq !== undefined && oArgument.SubReq !== "") {
							var oGLSubModel = new JSONModel();
							oGLSubModel.setData({
								"FimReq": oArgument.request,
								"subreqno": oArgument.SubReq
							});
							this.getView().setModel(oGLSubModel, "GLCancelModel");
							//load existing data of the Subrequest which is already saved in the table
							this._loadsubrequest(oArgument.request, oArgument.SubReq, Constants.GL_SRV_URL);
						}
					},
					_loadsubrequest: function (request, subrequest, sURL) {
						var that = this;
						var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
						this.oGlobalBusyDialog.open();
						oDataModel.read("/GLItemSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')", {

							success: function onSuccess(oData, oResponse) {
								//Store Selection Screen Entries
								var oModel = new JSONModel();
								oModel.setData({
									"GlNum": oData.GlNum,
									"Explanation": oData.Explanation,
									"TitleEn": oData.TitleEn,
									"TitleFr": oData.TitleFr,
									"LtextEn": oData.LtextEn,
									"LtextFr": oData.LtextFr,
									"DescEn": oData.DescEn,
									"DescFr": oData.DescFr,
									"Notes": oData.Notes,
									"AccType": oData.AccType,
								});
								that.getView().byId("ip_glaccount").setValue(oData.GlNum);
								that.getView().byId("ip_acctypebs").setValue(oData.AccType);
								that.getView().byId("ip_chartgroup").setValue(oData.ChartGrp);
								that.getView().byId("cb_direct").setSelectedKey(oData.Director);
								that.getView().byId("ip_explain").setValue(oData.Explanation);
								that.getView().byId("ip_st_eng").setValue(oData.TitleEn);
								that.getView().byId("ip_st_fr").setValue(oData.TitleFr);
								that.getView().byId("ip_lo_eng").setValue(oData.LtextEn);
								that.getView().byId("ip_lo_fr").setValue(oData.LtextFr);
								that.getView().byId("ip_desc_eng").setValue(oData.DescEn);
								that.getView().byId("ip_desc_fr").setValue(oData.DescFr);
								that.getView().byId("ip_notes").setValue(oData.Notes);

								that._setEditModel(oData.GlNum, that);

								that.oGlobalBusyDialog.close();
							},
							error: function onError(oError) {
								that.oGlobalBusyDialog.close();
								var oModel = new JSONModel();
								that.getView().setModel(oModel, "GLCreateModel");
								MessageToast.show(that.getMessageBundleText("msg.err.subreqFetchError", [subrequest]));

							}
						});

					},
					_loadChartGroup: function (sGl) {
						var that = this;
						var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);

						this.oGlobalBusyDialog.open();
						oDataModel.read("/ChartGroupSet('" + sGl + "')", {
							success: function (oData, response) {
								that.getView().byId("ip_chartgroup").setValue(oData.ExGrpCode);
								that.oGlobalBusyDialog.close();
							},
							error: function (oError) {
								that.oGlobalBusyDialog.close();
							}
						});
					},

					_loadExpl: function (sGl) {
						var that = this;
						var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);

						this.oGlobalBusyDialog.open();
						oDataModel.read("/BSLegcySet('" + sGl + "')", {
							success: function (oData, response) {
								// that.getView().byId("ip_explain").setValue(oData.Explaination);
								that.getView().byId("ip_desc_eng").setValue(oData.DesEn);
								that.getView().byId("ip_desc_fr").setValue(oData.DesFr);
								if (sGl[0] === "1" || sGl[0] === "2" || sGl[0] === "3") {
									that.getView().byId("cb_direct").setSelectedKey(oData.CpId);
								}
								that.oGlobalBusyDialog.close();
							},
							error: function (oError) {

								that.oGlobalBusyDialog.close();

							}
						});
					},

					_loadDesc: function (sGl) {
						var that = this;
						var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);

						this.oGlobalBusyDialog.open();
						oDataModel.read("/GLDescSet('" + sGl + "')", {
							success: function (oData, response) {
								that.getView().byId("ip_st_eng").setValue(oData.ExShtxt);
								that.getView().byId("ip_st_fr").setValue(oData.ExShtxtFr);
								that.getView().byId("ip_lo_eng").setValue(oData.ExLgtxt);
								that.getView().byId("ip_lo_fr").setValue(oData.ExLgtxtFr);
								that.oGlobalBusyDialog.close();
							},
							error: function (oError) {
								MessageToast.show(that.getMessageBundleText("msg.err.GlCanceldesc", []));

								that.oGlobalBusyDialog.close();
							}
						});
					},
					onValidateCombo: function (oEvent) {
						var sId = oEvent.mParameters.id;
						var value = oEvent.mParameters.value;
						var sComboId = sId.split('-')[2]; //id name
						if (sComboId === "cb_direct") {
							if (!this.checkOnSelection(oEvent)) {
								this.getView().byId("cb_direct").setSelectedKey("");
								return;
							}
						}
					},
					_setEditModel: function (sSelectedGl, that) {
						var oModel = that.getView().getModel("EditModel");

						//BS
						if (sSelectedGl[0] === "1" || sSelectedGl[0] === "2" || sSelectedGl[0] === "3") {
							oModel.setProperty("/BSVisible", true);
							that.getView().byId("ip_acctypebs").setValue(Constants.BS);
						} //PL account
						else if (sSelectedGl[0] === "4" || sSelectedGl[0] === "6" || sSelectedGl[0] === "7") {
							oModel.setProperty("/BSVisible", false);
							that.getView().byId("ip_acctypebs").setValue(Constants.PL);
						}

						if (sSelectedGl !== undefined && sSelectedGl !== null && sSelectedGl !== "") {
							oModel.setProperty("/EditGLField", false);
						}
						that.getView().setModel(oModel, "EditModel");
					},
					onSubmitManualGl: function (oEvent) {
						var gl = this.getView().byId("ip_glaccount");
						if (!this._validateGl(gl, "msg.val.GlError", this)) {
							return false;
						}
						var that = this;
						var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
						var oFilter = [];
						this.oGlobalBusyDialog.open();
						var i = "X";
						var setname = "/GLCancelSet(ImSaknr='" + gl.getValue() + "',ImCancel='" + i + "')";
						oDataModel.read(setname, {
							success: function (oData, response) {
								that._loadChartGroup(gl.getValue());
								that._loadExpl(gl.getValue());
								that._loadDesc(gl.getValue());
								that._setEditModel(gl.getValue(), that);
								that.oGlobalBusyDialog.close();
							},
							error: function (oError) {
								var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
								var sVal = "";
								for (var i = 1; i < arr.length; i++) {
									sVal = sVal + "\n" + arr[i].message + "\n";
								}
								var msgTitle = that.getResourceBundleText("title.errorMessage");
								sap.m.MessageBox.error(sVal, {
									title: msgTitle, // default
									onClose: null, // default
									styleClass: "", // default
									actions: sap.m.MessageBox.Action.CLOSE, // default
									emphasizedAction: null, // default
									initialFocus: null, // default
									textDirection: sap.ui.core.TextDirection.Inherit // default
								});
								// MessageToast.show("Rac Code does not exist");
								that.oGlobalBusyDialog.close();
							}
						});
					},
					onPressSave: function (oEvt) {
						//Validate Gl value
						if (!this._validateGl(this.getView().byId("ip_glaccount"), "msg.val.GlError", this)) {
							return false;
						}
						var oGLSubModel = this.getView().getModel("GLCancelModel");
						var oEntry = {};
						// Account Tab
						oEntry.GlNum = oGLSubModel.getData().GlNum;
						oEntry.FimReq = oGLSubModel.getData().FimReq;
						oEntry.SubreqNo = oGLSubModel.getData().subreqno;
						oEntry.Actionid = Constants.CANCEL;
						oEntry.Category = Constants.GL;
						oEntry.Explanation = this.getView().byId("ip_explain").getValue();
						oEntry.TitleEn = this.getView().byId("ip_st_eng").getValue();
						oEntry.TitleFr = this.getView().byId("ip_st_fr").getValue();
						oEntry.LtextEn = this.getView().byId("ip_lo_eng").getValue();
						oEntry.LtextFr = this.getView().byId("ip_lo_fr").getValue();
						oEntry.DescEn = this.getView().byId("ip_desc_eng").getValue();
						oEntry.DescFr = this.getView().byId("ip_desc_fr").getValue();
						oEntry.Notes = this.getView().byId("ip_notes").getValue();
						//begin change
						oEntry.Coa = this.getView().byId("ip_chartacc").getValue();
						oEntry.AccType = this.getView().byId("ip_acctypebs").getValue();
						oEntry.ChartGrp = this.getView().byId("ip_chartgroup").getValue();
						oEntry.Director = this.getView().byId("cb_direct").getSelectedKey();

						var subModel = this.getView().getModel("GLCancelModel");
						var that = this;
						var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
						this.oGlobalBusyDialog.open();
						var setname = "/GLItemSet(FimReq='" + oGLSubModel.getData().FimReq + "',SubreqNo='" + oGLSubModel.getData().subreqno +
							"')";
						ODataHelper.callODataUPDATE(oDataModel, setname, oEntry)
							.then(function onSuccess(oResult, oResponse) {
								that.oGlobalBusyDialog.close();
								that._clearScreenValues(that);
								var msg = that.getMessageBundleText("msg.success.submitForm", [subModel.getData().subreqno]);
								//Show success message and return to 1st screen
								MessageBox.success(msg, {
									title: that.getResourceBundleText("title.information"), // default
									onClose: function (sButton) {
										if (sButton === MessageBox.Action.OK) {
											that.onNavigateBack(oEvt, that, subModel.getData().FimReq, "RouteGLCancel");
										}
									}, // default
									styleClass: "", // default
									actions: MessageBox.Action.OK, // default
									emphasizedAction: MessageBox.Action.OK, // default
									initialFocus: null, // default
									textDirection: sap.ui.core.TextDirection.Inherit // default
								});
							})
							.catch(function onError(oError) {
								var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
								var sMsg = "";
								for (var i = 1; i < arr.length; i++) {
									sMsg = sMsg + '\n' + arr[i].message + '\n';
								}
								var msgTitle = that.getResourceBundleText("title.errorMessage");
								MessageBox.error(sMsg, {
									title: msgTitle, // default
									onClose: null, // default
									styleClass: "", // default
									actions: sap.m.MessageBox.Action.CLOSE, // default
									emphasizedAction: null, // default
									initialFocus: null, // default
									textDirection: sap.ui.core.TextDirection.Inherit // default
								});
								that.oGlobalBusyDialog.close();
								return;
							});
					},
					onPressDeleteSub: function (oEvt) {

						var GLSubModel = this.getView().getModel("GLCancelModel");
						this._deleteSubRequest(GLSubModel.getData().FimReq, GLSubModel.getData().subreqno, oEvt, this);
					},
					_clearScreenValues: function (that) {
						this.resetValueState(this.getView().byId("cb_direct"));
						this.resetValueState(this.getView().byId("ip_glaccount"));
						var oGLCancelModel = this.getView().getModel("GLCancelModel");
						//Account Tab
						that.getView().byId("ip_glaccount").setValue("");
						that.getView().byId("ip_chartgroup").setValue("");
						that.getView().byId("ip_acctypebs").setValue("");
						that.getView().byId("ip_explain").setValue("");
						that.getView().byId("cb_direct").setSelectedKey("");
						//Description Tab
						that.getView().byId("ip_st_eng").setValue("");
						that.getView().byId("ip_st_fr").setValue("");
						that.getView().byId("ip_lo_eng").setValue("");
						that.getView().byId("ip_lo_fr").setValue("");
						that.getView().byId("ip_desc_eng").setValue("");
						that.getView().byId("ip_desc_fr").setValue("");
						that.getView().byId("ip_notes").setValue("");
						//set the first tab as default
						that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
						that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
						that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
					},
					onPressCancel: function (oEvt) {
						var GLSubModel = this.getView().getModel("GLCancelModel");
						this._clearScreenValues(this);
						var oModel = new JSONModel();
						oModel.setData({
							"EditFields": true,
							"EditGLField": true,
							"BSVisible": false,
							"Openitem": true,
							"REVVisible": false,
							"PLVisible": false
						});
						this.getView().setModel(oModel, "EditModel");
					},
					onNavBack: function (oEvt) {
						var subModel = this.getView().getModel("GLCancelModel");
						var request = subModel.getData().FimReq;
						this._clearScreenValues(this);
						this.onNavigateBack(oEvt, this, request, "RouteGLCancel");
						}
					});

			});