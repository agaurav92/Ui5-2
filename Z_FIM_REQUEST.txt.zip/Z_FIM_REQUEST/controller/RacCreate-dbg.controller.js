sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"../Util/OdataHelper",
	"../Util/Constants",
	"sap/f/library",
	"../Util/Utility"
], function (BaseController, MessageBox, JSONModel, Filter, MessageToast, Fragment, ODataHelper, Constants, fioriLibrary, Utility) {
	"use strict";

	return BaseController.extend("FIM.FIM.controller.RacCreate", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf FIM.FIM.view.RacCreate
		 */
		onInit: function () {
			//Initialize busy indicator
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			this.oGlobalBusyDialog.open();
			// // Router login
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteRacCreate").attachMatched(this._onRouteFound, this);

			//populate RAC code
			// var oFilter = [];
			// oFilter.push(new sap.ui.model.Filter("ImRac", "EQ", "5*"));
			// this._odatareadset(Constants.VALUEHELP_SRV_URL, "/RACCodeSearchSet", "RACSearchModel",
			//            "msg.err.RacFetchError", oFilter);

			//populate Rev type code
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/RAVTypeSet", "RAVTypeModel",
				"msg.err.RevTypeFetchError");
			//populate Tax Status
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/TaxStatSet", "TaxStatusModel",
				"msg.err.TaxStatusFetchError");
			// RevType code Help text
			this._revTypecodeHelpText();
			this.oGlobalBusyDialog.close();
		},
		_onRouteFound: function (oEvt) {
			var oArgument = oEvt.getParameter("arguments");
			var oModel = new JSONModel();
			if ((oArgument.SelectItem === Constants.EDITREQUEST)) {
				oModel.setData({
					"EditFields": true,
					"EditRACField": true,
				});
			} else {
				oModel.setData({
					"EditFields": false,
					"EditRACField": false,
				});
			}
			this.getView().setModel(oModel, "EditModel");
			//Initialize and bind input elements
			if (oArgument.SubReq !== undefined && oArgument.SubReq !== "") {
				var oGLSubModel = new JSONModel();
				oGLSubModel.setData({
					"FimReq": oArgument.request,
					"subreqno": oArgument.SubReq,
				});
				this.getView().setModel(oGLSubModel, "RACSubModel");
				//load existing data of the Subrequest which is already saved in the table
				this._loadsubrequest(oArgument.request, oArgument.SubReq, Constants.GL_SRV_URL);
			}
		},

		//Validations for RAC Code
		onSubmitManualRAC: function (oEvt) {
			var Rac = this.getView().byId("ip_raccode");
			if (!this._validateRac(Rac, "msg.val.RacError", this)) {
				return false;
			}
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			var oRACCreateModel = this.getView().getModel("RACCreateModel");
			var oFilter = [];
			oFilter.push(new sap.ui.model.Filter("ImRac", "EQ", Rac.getValue()));
			this.oGlobalBusyDialog.open();
			oDataModel.read("/RACCodeSearchSet", {
				async: false,
				filters: oFilter,
				success: function (oData, response) {
					oRACCreateModel.setProperty("/GlNum", Rac.getValue()); //RacNum deleted from Odata/Table
					oRACCreateModel.setProperty("/RecycleCode", "");
					that.getView().setModel(oRACCreateModel, "RACCreateModel");
					that._setEditModel(that);
					that.oGlobalBusyDialog.close();
				},
				error: function (oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
				}
			});
		},

		//Validation for GL Revenue
		onSubmitGlRevenue: function (oEvt) {
			var Glrev = this.getView().byId("ip_sapglrev");
			if (!this._validateGlrevenue(Glrev, "msg.err.GlrevError", this)) {
				return false;
			}
		},

		//Validation for Value of Expected Annual posting Amount
		onPostingAmt: function (oEvt) {
			var sAmount = oEvt.getSource().getValue().replace(/[^\d]/g, '');
			oEvt.getSource().setValue(sAmount);
		},

		//Combobox validations
		onValidateCombo: function (oEvent) {
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (sComboId === "cb_revtypecode" || sComboId === "cb_taxstatus") {
				if (!this.checkOnSelection(oEvent)) {
					this.getView().byId(sComboId).setSelectedKey("");
					return;
				}
			} else if (value !== "") {
				if (!this.checkOnSelection(oEvent)) return;
			} else {
				oEvent.getSource().setValueState("None");
			}
		},

		//For Load existing data upon Save button and come again
		_loadsubrequest: function (request, subrequest, sURL) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			this.oGlobalBusyDialog.open();
			oDataModel.read("/GLItemSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')", {
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						"GlNum": oData.GlNum,
						"RecycleCode": oData.RecycleCode,
						"Coa": oData.Coa,
						"GlRev": oData.GlRev,
						"RevTypeCode": oData.RevTypeCode,
						"TeleTaxStatus": oData.TeleTaxStatus,
						"Type": oData.Type,
						"ReRecyRac": oData.ReRecyRac,
						"Explanation": oData.Explanation,
						"ValueOfExp": that.formatamount(oData.ValueOfExp),
						"BillSys": oData.BillSys,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
						"CompCode": oData.CompCode,
						"Notes": oData.Notes
					});
					that.getView().setModel(oModel, "RACCreateModel");
					if (oData.TeleTaxStatus === "" || oData.TeleTaxStatus === undefined || oData.TeleTaxStatus === null) {
						that.getView().byId("cb_taxstatus").setSelectedKey("00");
					}
					//Replacing RacNum with GlNum

					if (oData.GlNum !== undefined && oData.GlNum !== null && oData.GlNum !== "") {
						that._setEditModel(that);
					}
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "RACCreateModel");
					MessageToast.show(that.getMessageBundleText("msg.err.subreqFetchError", [subrequest]));

				}
			});
		},

		onPressRecycleRAC: function (oEvt) {
			var oView = this.getView();
			var fragmentSearchRacAccount = "FIM.FIM.view.fragment.SearchRacAccount";
			this.oGlobalBusyDialog.open();
			if (!this.byId("dlg_searchracaccount")) {
				Fragment.load({
					id: oView.getId(),
					name: fragmentSearchRacAccount,
					type: "XML",
					controller: this
				}).then(function (oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
				this._oDialogSearchRacAccount = sap.ui.xmlfragment(fragmentSearchRacAccount, this);
			} else {
				this.byId("dlg_searchracaccount").open();
				this.getView().byId("cb_racaccount").setValue("");
			}
			this.oGlobalBusyDialog.close();
		},

		// 31/11/2022
		onF4ChangeRac: function (oEvent) {
			var rac = oEvent.getSource().getValue();
			var check = false;
			if (rac === undefined || rac === null || rac === "" || rac === "*") {
				this.getView().byId("cb_racaccount").setValue("");
				this.getView().byId("cb_racaccount").setValueState(sap.ui.core.ValueState.Error);
				return;
			}
			for (var i = 0; i < rac.length; i++) {
				if (i === 0 && rac[i] !== "5") {
					this.getView().byId("cb_racaccount").setValue("");
					this.getView().byId("cb_racaccount").setValueState(sap.ui.core.ValueState.Error);
					return;
				}
				if ((rac[i].match(/^[0-9]+$/) === null) && i === 0) {
					this.getView().byId("cb_racaccount").setValue("");
					this.getView().byId("cb_racaccount").setValueState(sap.ui.core.ValueState.Error);
					return;
				} else {
					if (rac[i].match("[0-9*]+") === null) {
						this.getView().byId("cb_racaccount").setValue("");
						this.getView().byId("cb_racaccount").setValueState(sap.ui.core.ValueState.Error);
						return;
					}
					//Rac search should contain atleast one *
					if (rac[i] === "*" && rac.length !== 7) {
						check = true;
					} else if (rac.length === 7) {
						check = true;
					}
				}
			}
			if (!check) {
				this.getView().byId("cb_racaccount").setValue("");
				this.getView().byId("cb_racaccount").setValueState(sap.ui.core.ValueState.Error);
				return;
			}
			this.resetValueState(this.getView().byId("cb_racaccount"));
			//Call Odata to fill the RAC search table
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			var oFilter = [];
			oFilter.push(new sap.ui.model.Filter("ImRac", "EQ", rac));
			oFilter.push(new sap.ui.model.Filter("ImSearch", "EQ", "X"));
			this.oGlobalBusyDialog.open();
			oDataModel.read("/RACCodeSearchSet", {
				async: false,
				filters: oFilter,
				success: function (oData, response) {
					var oRacsearchModel = new sap.ui.model.json.JSONModel();
					oRacsearchModel.setData({
						data: oData.results
					});
					that.getView().byId("tbl_racsearch").setVisible((oData.results.length > 0));
					that.getView().byId("tbl_racsearch").setModel(oRacsearchModel, "RACSearchModel");
					that.oGlobalBusyDialog.close();
				},
				error: function (oError) {
					that.getView().byId("cb_racaccount").setValue("");
					that.getView().byId("cb_racaccount").setValueState(sap.ui.core.ValueState.Error);
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
				}
			});
		},
		onSelectSearchRAC: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var sSelectedRac = oSelectedItem.getCells()[0].getText();
			var oRacCreateModel = this.getView().getModel("RACCreateModel");
			if (typeof sSelectedRac !== "undefined" && sSelectedRac !== null && sSelectedRac !== "") {

				this.getView().byId("ip_raccode").setValue(sSelectedRac);
				oRacCreateModel.setProperty("/RecycleCode", "X");
				this.getView().setModel(oRacCreateModel, "RACCreateModel");
				this._setEditModel(this);

				this.byId("dlg_searchracaccount").close();
			} else {
				MessageToast.show(that.getMessageBundleText("msg.err.InvalidRac", []));
			}
		},
		onCloseF4RACAccount: function (oEvt) {
			this.resetValueState(this.getView().byId("cb_racaccount"));
			this.resetValueState(this.getView().byId("ip_raccode"));
			this.getView().byId("cb_racaccount").setValue("");
			this.getView().byId("ms_searchglaccount").setVisible(false);
			this.byId("tbl_racsearch").setVisible(false);
			var oModel = new sap.ui.model.json.JSONModel();
			this.byId("tbl_racsearch").setModel(oModel);
			this.byId("dlg_searchracaccount").close();
		},
		_setEditModel: function (that) {
			var oEditModel = that.getView().getModel("EditModel");
			oEditModel.setProperty("/EditRACField", false);
			that.getView().setModel(oEditModel, "EditModel");
		},

		onPressCancelRac: function (oEvt) {
			this._clearScreenValues(this);
		},
		onPressDeleteSub: function (oEvt) {
			var oRACSubModel = this.getView().getModel("RACSubModel");
			this._deleteSubRequest(oRACSubModel.getData().FimReq, oRACSubModel.getData().subreqno, oEvt, this);

		},
		_clearScreenValues: function (that) {
			this.resetValueState(this.getView().byId("cb_revtypecode"));
			this.resetValueState(this.getView().byId("cb_taxstatus"));
			this.resetValueState(this.getView().byId("ip_pstamt"));
			this.resetValueState(this.getView().byId("ip_raccode"));
			var oEditModel = that.getView().getModel("EditModel");
			oEditModel.setProperty("/EditRACField", true);
			that.getView().setModel(oEditModel, "EditModel");
			var oRACCreateModel = new JSONModel();
			that.getView().setModel(oRACCreateModel, "RACCreateModel");
			// Account Tab
			that.getView().byId("ip_raccode").setValue("");
			that.getView().byId("ip_sapglrev").setValue("");
			that.getView().byId("cb_revtypecode").setSelectedKey("");
			that.getView().byId("cb_taxstatus").setSelectedKey("00");
			// Explanation Tab
			that.getView().byId("ip_reason").setValue("");
			that.getView().byId("ip_explain").setValue("");
			that.getView().byId("ip_pstamt").setValue("");
			that.getView().byId("ip_billingsystem").setValue("");
			// Description Tab
			that.getView().byId("ip_titleen").setValue();
			that.getView().byId("ip_titlefr").setValue();
			that.getView().byId("ip_descen").setValue();
			that.getView().byId("ip_descfr").setValue();
			// CoCd tab
			that.getView().byId("ip_cocd").setValue();
			that.getView().byId("ip_notes").setValue();

			//set the first tab as default
			that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
			that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
			that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
		},
		//For Save Button
		onPressSaveRac: function (oEvt) {
			//Validate Rac value
			if (!this._validateRac(this.getView().byId("ip_raccode"), "msg.val.RacError", this)) {
				return false;
			}
			//Validate SAP Gl Revenue
			if (!this._validateGlrevenue(this.getView().byId("ip_sapglrev"), "msg.val.Glreverror", this)) {
				return false;
			}
			var oEntry = {};
			var oRACSubModel = this.getView().getModel("RACSubModel");
			var oRACCreateModel = this.getView().getModel("RACCreateModel");
			// Account Tab
			oEntry.GlNum = oRACCreateModel.getData().GlNum;
			oEntry.FimReq = oRACSubModel.getData().FimReq;
			oEntry.SubreqNo = oRACSubModel.getData().subreqno;
			oEntry.Actionid = Constants.CREATE;
			oEntry.Category = Constants.RAC;
			oEntry.TeleTaxStatus = oRACCreateModel.getData().TeleTaxStatus;
			oEntry.RecycleCode = oRACCreateModel.getData().RecycleCode;
			//begin change
			oEntry.Coa = this.getView().byId("ip_chartacc").getValue();
			oEntry.GlRev = oRACCreateModel.getData().GlRev;
			oEntry.RevTypeCode = oRACCreateModel.getData().RevTypeCode;

			oEntry.Type = Constants.RAC;
			// Explanation Tab
			oEntry.ReRecyRac = oRACCreateModel.getData().ReRecyRac;
			oEntry.Explanation = oRACCreateModel.getData().Explanation;
			// oEntry.ValueOfExp = oRACCreateModel.getData().ValueOfExp;
			if (!this.onSubmitPstamt()) {
				return false;
			}
			oEntry.ValueOfExp = this.parseamount(oRACCreateModel.getData().ValueOfExp);
			oEntry.BillSys = oRACCreateModel.getData().BillSys;
			// Description Tab

			oEntry.LtextEn = oRACCreateModel.getData().LtextEn;
			oEntry.LtextFr = oRACCreateModel.getData().LtextFr;
			oEntry.DescEn = oRACCreateModel.getData().DescEn;
			oEntry.DescFr = oRACCreateModel.getData().DescFr;
			// CoCd tab
			oEntry.CompCode = oRACCreateModel.getData().CompCode;
			oEntry.Notes = oRACCreateModel.getData().Notes;

			var subModel = this.getView().getModel("RACSubModel");
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			var setname = "/GLItemSet(FimReq='" + oRACSubModel.getData().FimReq + "',SubreqNo='" + oRACSubModel.getData().subreqno +
				"')";
			ODataHelper.callODataUPDATE(oDataModel, setname, oEntry)
				.then(function onSuccess(oResult, oResponse) {
					that.oGlobalBusyDialog.close();
					that._clearScreenValues(that);
					var msg = that.getMessageBundleText("msg.success.submitForm", [subModel.getData().subreqno]);
					//Show success message and return to 1st screen
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								that.onNavigateBack(oEvt, that, subModel.getData().FimReq, "RouteRacCreate");
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {

					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				});
		},
		onNavBack: function (oEvt) {
			var subModel = this.getView().getModel("RACSubModel");
			var request = subModel.getData().FimReq;
			this._clearScreenValues(this);
			this.onNavigateBack(oEvt, this, request, "RouteRacCreate");
		}

	});

});