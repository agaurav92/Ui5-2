sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"../Util/OdataHelper",
	"../Util/Constants",
	"../Util/Utility"
], function (BaseController, MessageBox, JSONModel, Filter, MessageToast, Fragment, ODataHelper, Constants, Utility) {
	"use strict";

	return BaseController.extend("FIM.FIM.controller.GLModify", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf FIM.FIM.view.GLModify
		 */
		onInit: function () {
			//Initialize busy indicator
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			this.oGlobalBusyDialog.open();
			// // Router login
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteGLModify").attachMatched(this._onRouteFound, this);
			//populate tax category
			this._populateTaxCat();
			// this._odatareadset(Constants.VALUEHELP_SRV_URL, "/TaxCatSet", "TaxCatModel", "msg.err.TaxCatFetchError");
			//populate sort key
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/SortingKeySet", "SortKeyModel", "msg.err.SortKeyFetchError");
			this.oGlobalBusyDialog.close();
		},
		_onRouteFound: function (oEvt) {
			var oArgument = oEvt.getParameter("arguments");
			var oModel = new JSONModel();
			this._loadBSValue();
			if ((oArgument.SelectItem === Constants.EDITREQUEST)) {
				oModel.setData({
					"EditFields": true,
					"EditGLField": true,
					"BSVisible": false,
					"Openitem": true,
					"Groupac": true,
					"DirectorEdit": false,
					"PLVisible": false
				});
			} else {
				oModel.setData({
					"EditFields": false,
					"EditGLField": false,
					"BSVisible": true,
					"Openitem": true,
					"Groupac": false,
					"DirectorEdit": true,
					"PLVisible": true
				});
			}
			this.getView().setModel(oModel, "EditModel");
			if (oArgument.SubReq !== undefined && oArgument.SubReq !== "") {
				var oGLSubModel = new JSONModel();
				oGLSubModel.setData({
					"data": {
						"FimReq": oArgument.request,
						"subreqno": oArgument.SubReq
					}
				});
				this.getView().setModel(oGLSubModel, "GLSubModel");
				//load existing data of the Subrequest which is already saved in the table
				this._loadsubrequest(oArgument.request, oArgument.SubReq, Constants.GL_SRV_URL, oArgument.SelectItem);
			}
		},
		_loadsubrequest: function (request, subrequest, sURL, item) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			var oModel = new JSONModel();
			that.getView().setModel(oModel, "GLModifyModel");
			that.getView().setModel(oModel, "GLExist");
			//combinedModel
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/BSCombinedSet", "combinedModel", "msg.err.DirectorFetchError");
			this.oGlobalBusyDialog.open();
			oDataModel.read("/GLItemSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')", {
				urlParameters: {
					"$expand": "GLItemToCCNav"
				},
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						"MvType": oData.MvType,
						"Director": oData.Director,
						"GrpAccNum": oData.GrpAccNum,
						"Explanation": oData.Explanation,
						"TitleEn": oData.TitleEn,
						"TitleFr": oData.TitleFr,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
						"AccCurr": oData.AccCurr,
						"TaxCat": oData.TaxCat,
						"ReconAcTyp": oData.ReconAcTyp,
						"AltAcNo": oData.AltAcNo,
						"SortKey": oData.SortKey,
						"PlanningLevel": oData.PlanningLevel,
						"HouseBank": oData.HouseBank,
						"AccId": oData.AccId,
						"IntrestCalcFr": oData.IntrestCalcFr,
						"Notes": oData.Notes,
					});
					that.getView().byId("ip_glaccount").setValue(oData.GlNum);
					if (oData.AccType === Constants.PL) {
						that.getView().byId("ip_pltype").setValue(oData.PlAccType);
					}
					if (item !== Constants.EDITREQUEST) {
						that._GetDirectorName(oData.Director, that);
					}
					//chartgroup
					that.getView().byId("ip_chartgroup").setValue(oData.ChartGrp);
					that.getView().byId("ip_acctypebs").setValue(oData.AccType);
					that._loadcheckbox(oData, that);
					var value = oData.GLItemToCCNav;
					that._loadCompTable(value, request, subrequest, that);

					that.getView().setModel(oModel, "GLModifyModel");
					that._setEditModel(oData.GlNum, oData.AccType, oData.MvType, that, item);
					if (oData.GlNum !== undefined && oData.GlNum !== null && oData.GlNum !== "") {
						that._loadexistingGL(request, subrequest, item, oData.GlNum, that);
					}
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
				}
			});
		},
		_GetDirectorName: function (id, that) {
			var setname = "/BSCombinedSet('" + id + "')";
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			ODataHelper.callODataREAD(oDataModel, setname)
				.then(function onSuccess(oData, oResponse) {
					var oModel = new JSONModel();
					oModel.setData({
						"data": [{
							"CpId": oData.CpId,
							"NameFirst": oData.NameFirst,
							"NameLast": oData.NameLast
						}]
					});
					that.getView().setModel(oModel, "directModel");
				})
				.catch(function onError(oError) {});
		},
		onPressLoadFSG: function (oEvent) {
			var oView = this.getView();
			var fragmentSearchFSG = "FIM.FIM.view.fragment.SearchFSG";
			var oTableModel = this.getView().byId("tbl_Fsg").getModel("FsgTableModel");
			var rowid = oEvent.oSource.sId;
			var iRowIndex = rowid.split('-')[4];
			var sselectComp = oTableModel.getData().data[iRowIndex].CompCode;
			if (sselectComp !== undefined && sselectComp !== null && sselectComp !== "") {
				sap.ui.core.BusyIndicator.show(0);
				var DialogComp = new JSONModel;
				DialogComp.setData({
					"Comp": sselectComp,
					"rowindex": iRowIndex
				});
				this.getView().setModel(DialogComp, "DialogComp");
				var oFilter = [];
				oFilter.push(new sap.ui.model.Filter("Bukrs", "EQ", sselectComp));
				var that = this;
				var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
				ODataHelper.callODataREAD(oDataModel, "/GLFLDSTGRPSet", oFilter)
					.then(function onSuccess(oData, oResponse) {
						var oModel = new JSONModel();
						oModel.setData({
							data: oData.results
						});
						that.getView().setModel(oModel, "FsgModel");
						sap.ui.core.BusyIndicator.hide();
						if (!that.byId("dlg_searchfsg")) {
							Fragment.load({
								id: oView.getId(),
								name: fragmentSearchFSG,
								type: "XML",
								controller: that
							}).then(function (oDialog) {
								oView.addDependent(oDialog);
								oDialog.open();
							});
							that._oDialogSearchFSG = sap.ui.xmlfragment(fragmentSearchFSG, that);
						} else {
							that.byId("dlg_searchfsg").open();
						}
					})
					.catch(function onError(oError) {
						MessageToast.show(that.getMessageBundleText("msg.err.FsgFetchError"));
						sap.ui.core.BusyIndicator.hide();
					});
			}
		},
		onSelectSearchFSG: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var sSelected = oSelectedItem.getCells()[0].getText();
			var DialogComp = this.getView().getModel("DialogComp");
			var oTableModel = this.getView().byId("tbl_Fsg").getModel("FsgTableModel");
			if (typeof sSelected !== "undefined" && sSelected !== null && sSelected !== "") {
				oTableModel.setProperty("/data/" + DialogComp.getData().rowindex + "/FldStgrp", sSelected);
				this.getView().setModel(oTableModel, "FsgTableModel");
				this.byId("dlg_searchfsg").close();
			}
		},
		_clearF4FSG: function () {
			var oModel = new JSONModel();
			this.getView().setModel(oModel, "DialogComp");
			this.getView().setModel(oModel, "FsgModel");
		},
		onCloseF4FSG: function (oEvent) {
			this._clearF4FSG();
			this.byId("dlg_searchfsg").close();
		},
		onChangeModifyDrop: function (oEvent) {
			var bValid = oEvent.getSource().getSelectedKey();
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (!this.checkOnSelection(oEvent)) {
				return;
			} else {
				this.getView().byId(sComboId).setValueState(sap.ui.core.ValueState.None);
				this.getView().byId(sComboId).setValueStateText("");
			}
			var oModel = this.getView().getModel("EditModel");
			if (bValid === "No") {
				this.getView().byId("ip_groupac").setValue("");
				oModel.setProperty("/Groupac", false);
				if (oModel.getData().BSVisible === true) {
					oModel.setProperty("/DirectorEdit", true);
				}
			} else {
				oModel.setProperty("/Groupac", true);
				oModel.setProperty("/DirectorEdit", false);
				this.getView().byId("cb_direct").setSelectedKey("");
			}
			this.getView().setModel(oModel, "EditModel");
		},

		_loadCompTable: function (value, request, subrequest, that) {
			var oFsgTableModel = new JSONModel();
			var companyCodeData = {};
			var items = [];
			if (value.results.length === 0) {
				companyCodeData = {
					"ItemNo": 1,
					"FimReq": request,
					"SubreqNo": subrequest,
					"CompCode": "",
					"Oldfsg": "",
					"FldStgrp": ""
				};
				items.push(companyCodeData);
			} else {
				for (var i = 0; i < value.results.length; i++) {
					companyCodeData = {
						"ItemNo": i + 1,
						"FimReq": request,
						"SubreqNo": subrequest,
						"CompCode": value.results[i].CompCode,
						"Oldfsg": value.results[i].Oldfsg,
						"FldStgrp": value.results[i].FldStgrp
					};
					items.push(companyCodeData);
				}
			}
			oFsgTableModel.setProperty("/data", items);
			that.getView().setModel(oFsgTableModel, "FsgTableModel");
		},
		_loadexistingGL: function (request, subrequest, item, gl, that) {
			that.oGlobalBusyDialog.open();
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			if (item === Constants.COMPLETE_REQUEST) {
				//capture From values from the new table once the request is submitted or other than draft status
				var setname = "/GLInfoOldSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')";
			} else {
				var setname = "/GLModifySet(GlNum='" + gl + "',Category='" + Constants.GL + "')";
			}
			oDataModel.read(setname, {
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						"Director": oData.Director,
						"GrpAccNum": oData.GrpAccNum,
						"Explanation": oData.Explanation,
						"TitleEn": oData.TitleEn,
						"TitleFr": oData.TitleFr,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
					});
					that.getView().setModel(oModel, "GLExist");
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "GLExist");
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				}
			});
		},
		onSubmitManualGl: function (oEvent) {
			var gl = this.getView().byId("ip_glaccount");
			if (!this._validateGl(gl, "msg.val.GlError", this)) {
				return;
			}
			this.oGlobalBusyDialog.open();
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			var setname = "/GLModifySet(GlNum='" + gl.getValue() + "',Category='" + Constants.GL + "')";
			//combinedModel
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/BSCombinedSet", "combinedModel", "msg.err.DirectorFetchError");
			oDataModel.read(setname, {
				urlParameters: {
					"$expand": "GLModToCCNav"
				},
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						"Director": oData.Director,
						"GrpAccNum": oData.GrpAccNum,
						"Explanation": oData.Explanation,
						"TitleEn": oData.TitleEn,
						"TitleFr": oData.TitleFr,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
					});
					var oModifyModel = new JSONModel();
					oModifyModel.setData({
						"AccCurr": oData.AccCurr,
						"TaxCat": oData.TaxCat,
						"ReconAcTyp": oData.ReconAcTyp,
						"AltAcNo": oData.AltAcNo,
						"SortKey": oData.SortKey,
						"PlanningLevel": oData.PlanningLevel,
						"HouseBank": oData.HouseBank,
						"AccId": oData.AccId,
						"IntrestCalcFr": oData.IntrestCalcFr,
						"Notes": oData.Notes,

					});
					if (oData.AccType === Constants.PL) {
						that.getView().byId("ip_pltype").setValue(oData.PlAccType);
					}
					//chartgroup
					that.getView().byId("ip_chartgroup").setValue(oData.ChartGrp);
					that.getView().byId("ip_acctypebs").setValue(oData.AccType);
					that._loadcheckbox(oData, that);
					var GLSubModel = that.getView().getModel("GLSubModel");
					var value = oData.GLModToCCNav;
					that._loadCompTable(value, GLSubModel.getData().data.FimReq, GLSubModel.getData().data.subreqno, that);

					that.getView().setModel(oModel, "GLExist");
					that.getView().setModel(oModifyModel, "GLModifyModel");
					that._setEditModel(oData.GlNum, oData.AccType, "", that, "");
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "GLModifyModel");
					that.getView().setModel(oModel, "GLExist");
					gl.setValue("");
					that.oGlobalBusyDialog.close();
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					return;
				}
			});
			// }
		},
		_setEditModel: function (sSelectedGl, acctype, modifydrop, that, item) {
			var oModel = that.getView().getModel("EditModel");
			var oModModel = new JSONModel();
			if (acctype === Constants.BS) {
				oModel.setProperty("/BSVisible", true);
				oModel.setProperty("/DirectorEdit", true); //add
				oModel.setProperty("/PLVisible", false);
				//Belongs to PL so set it empty when value is changed
				that.getView().byId("ip_pltype").setValue("");
				oModModel.setData({
					"data": [{
						"Key": "No",
						"Value": "No Move"
					}, {
						"Key": "B/S",
						"Value": "B/S Movement"
					}]
				});
			} //PL account
			else if (acctype === Constants.PL) {
				oModel.setProperty("/PLVisible", true);
				oModel.setProperty("/BSVisible", false);
				oModel.setProperty("/DirectorEdit", false); //add
				that.getView().byId("ip_pltype").setValue(Constants.RE);
				//Belongs to BS so set it empty when value is changed
				that.getView().byId("cb_direct").setSelectedKey("");
				oModModel.setData({
					"data": [{
						"Key": "No",
						"Value": "No Move"
					}, {
						"Key": "Inter",
						"Value": "Inter Movement"
					}, {
						"Key": "Intra",
						"Value": "Intra Movement"
					}]
				});
			}
			if (sSelectedGl !== undefined && sSelectedGl !== null && sSelectedGl !== "") {
				oModel.setProperty("/EditGLField", false);
			}
			if (modifydrop !== undefined && modifydrop !== null && modifydrop !== "") {
				if (modifydrop === "No") {
					this.getView().byId("ip_groupac").setValue("");
					oModel.setProperty("/Groupac", false);
					if (acctype === Constants.BS) {
						oModel.setProperty("/DirectorEdit", true);
					}
				} else {
					oModel.setProperty("/Groupac", true);
					oModel.setProperty("/DirectorEdit", false);
					this.getView().byId("cb_direct").setSelectedKey("");
				}
				// if (item !== Constants.EDITREQUEST) {
				// 	oModel.setProperty("/DirectorEdit", false);
				// }
			}
			that.getView().setModel(oModel, "EditModel");
			that.getView().setModel(oModModel, "ModGlDrop");
		},
		onValidateCombo: function (oEvent) {
			var bValid = oEvent.getSource().getSelectedKey();
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (sComboId === "cb_modifygl") {
				if (!this.checkOnSelection(oEvent)) {
					return;
				}
			} else if (value !== "" && value !== " - BLANK") {
				if (!this.checkOnSelection(oEvent)) {
					return;
				}
			} else {
				this.getView().byId(sComboId).setValueState(sap.ui.core.ValueState.None);
				this.getView().byId(sComboId).setValueStateText("");
			}
		},
		onAddNewRow: function (oEvent) {
			//Pass table id and model name
			var oGLSubModel = this.getView().getModel("GLSubModel");
			this._addNewRowGL(oEvent, "tbl_Fsg", "FsgTableModel", oGLSubModel.getData().data.FimReq, oGLSubModel.getData().data.subreqno);

		},
		onRemoveRow: function (oEvent) {
			this._removeRowGL(oEvent, "tbl_Fsg", "FsgTableModel");
		},
		_resetvaluestatus: function (that) {
			that.resetValueState(that.getView().byId("ip_glaccount"));
			//combo box
			that.resetValueState(that.getView().byId("cb_direct"));
			that.resetValueState(that.getView().byId("cb_recon"));
			that.resetValueState(that.getView().byId("cb_sortkey"));
			that.resetValueState(that.getView().byId("cb_currency"));
			that.resetValueState(that.getView().byId("cb_taxcat"));

		},
		_clearScreenValues: function (that) {
			that._resetvaluestatus(that);
			var oModel = new JSONModel();
			that.getView().byId("ip_glaccount").setValue("");
			that.getView().byId("ip_chartgroup").setValue("");
			that.getView().byId("ip_acctypebs").setValue("");
			that.getView().byId("cb_relevantcash").setSelected(false);
			that.getView().byId("cb_lineitem").setSelected(false);
			that.getView().byId("cb_openitem").setSelected(false);
			that.getView().byId("cb_balancelocal").setSelected(false);
			that.getView().byId("cb_withouttax").setSelected(false);
			that.getView().setModel(oModel, "GLModifyModel");
			that.getView().setModel(oModel, "GLExist");
			var oEditModel = that.getView().getModel("EditModel");
			that.getView().byId("cb_openitem").setSelected(false);
			oEditModel.setProperty("/Openitem", true);
			that.getView().setModel(oEditModel, "EditModel");
			//set the first tab as default
			that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
			that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
			that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
		},
		onPressSaveModify: function (oEvt) {
			if (!this._validateGl(this.getView().byId("ip_glaccount"), "msg.val.GlError", this)) {
				return false;
			}
			var oEntry = {};
			var oGLModifyModel = this.getView().getModel("GLModifyModel");
			var oGLSubModel = this.getView().getModel("GLSubModel");

			oEntry.FimReq = oGLSubModel.getData().data.FimReq;
			oEntry.SubreqNo = oGLSubModel.getData().data.subreqno;
			oEntry.Actionid = Constants.MODIFY;
			oEntry.Category = Constants.GL;
			oEntry.GlNum = this.getView().byId("ip_glaccount").getValue();
			oEntry.ChartGrp = this.getView().byId("ip_chartgroup").getValue();
			oEntry.AccType = this.getView().byId("ip_acctypebs").getValue();
			oEntry.Coa = this.getView().byId("ip_chartacc").getValue();
			if (oEntry.AccType === Constants.PL) {
				oEntry.PlAccType = this.getView().byId("ip_pltype").getValue();
			}

			var oFsgTableModel = this.getView().getModel("FsgTableModel");
			var oTableList = oFsgTableModel.getProperty("/data");
			var oCompanyList = oTableList.map(function (obj) {
				return {
					FimReq: obj.FimReq,
					SubreqNo: obj.SubreqNo,
					CompCode: obj.CompCode,
					FldStgrp: obj.FldStgrp
				};
			});
			oEntry.GLItemToCCNav = oCompanyList;
			oEntry.GrpAccNum = oGLModifyModel.getData().GrpAccNum;
			oEntry.MvType = oGLModifyModel.getData().MvType;
			oEntry.Explanation = oGLModifyModel.getData().Explanation;
			oEntry.TitleEn = oGLModifyModel.getData().TitleEn;
			oEntry.TitleFr = oGLModifyModel.getData().TitleFr;
			oEntry.LtextEn = oGLModifyModel.getData().LtextEn;
			oEntry.LtextFr = oGLModifyModel.getData().LtextFr;
			oEntry.DescEn = oGLModifyModel.getData().DescEn;
			oEntry.DescFr = oGLModifyModel.getData().DescFr;
			oEntry.Director = oGLModifyModel.getData().Director;
			oEntry.AccCurr = oGLModifyModel.getData().AccCurr;
			oEntry.TaxCat = oGLModifyModel.getData().TaxCat;
			oEntry.ReconAcTyp = oGLModifyModel.getData().ReconAcTyp;
			oEntry.AltAcNo = oGLModifyModel.getData().AltAcNo;
			oEntry.SortKey = oGLModifyModel.getData().SortKey;
			oEntry.PlanningLevel = oGLModifyModel.getData().PlanningLevel;
			oEntry.HouseBank = oGLModifyModel.getData().HouseBank;
			oEntry.AccId = oGLModifyModel.getData().AccId;
			oEntry.IntrestCalcFr = oGLModifyModel.getData().IntrestCalcFr;
			oEntry.Notes = oGLModifyModel.getData().Notes;

			oEntry.PostingWta = " ";
			oEntry.BalLocCurr = " ";
			oEntry.OpenItemMt = " ";
			oEntry.LineItemDis = " ";
			oEntry.RelCashFlow = " ";
			//CheckBox
			if (this.getView().byId("cb_relevantcash").getSelected()) {
				oEntry.RelCashFlow = "X";
			}
			if (this.getView().byId("cb_lineitem").getSelected()) {
				oEntry.LineItemDis = "X";
			}
			if (this.getView().byId("cb_openitem").getSelected()) {
				if (oEntry.ReconAcTyp === undefined || oEntry.ReconAcTyp === null || oEntry.ReconAcTyp === "") {
					oEntry.OpenItemMt = "X";
				}
			}
			if (this.getView().byId("cb_balancelocal").getSelected()) {
				oEntry.BalLocCurr = "X";
			}
			if (this.getView().byId("cb_withouttax").getSelected()) {
				oEntry.PostingWta = "X";
			}
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			ODataHelper.callODataCREATE(oDataModel, "/GLItemSet", oEntry)
				.then(function onSuccess(oResult, oResponse) {
					that.oGlobalBusyDialog.close();
					that._clearScreenValues(that);
					//Data submitted successfully!
					var msg = that.getMessageBundleText("msg.success.submitForm", [oGLSubModel.getData().data.subreqno]);
					//Show success message and return to 1st screen
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								that.onNavigateBack(oEvt, that, oGLSubModel.getData().data.FimReq, "RouteGLModify");
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {
					// MessageToast.show("Error while saving the request");
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				});
		},
		onPressDeleteSub: function (oEvt) {
			var GLSubModel = this.getView().getModel("GLSubModel");
			this._deleteSubRequest(GLSubModel.getData().data.FimReq, GLSubModel.getData().data.subreqno, oEvt, this);
		},
		onNavBack: function (oEvt) {
			var subModel = this.getView().getModel("GLSubModel");
			var request = subModel.getData().data.FimReq;
			this._clearScreenValues(this);
			this.onNavigateBack(oEvt, this, request, "RouteGLModify");
		}
	});

});