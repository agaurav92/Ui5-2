sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"../Util/OdataHelper",
	"../Util/Constants",
	"../Util/Utility"
], function (BaseController, MessageBox, JSONModel, Filter, MessageToast, Fragment, ODataHelper, Constants, Utility) {
	"use strict";

	return BaseController.extend("FIM.FIM.controller.GLBlock", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf FIM.FIM.view.GLExtend
		 */
		onInit: function () {
			//Initialize busy indicator
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			this.oGlobalBusyDialog.open();
			// Router login
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteGLBlock").attachMatched(this._onRouteFound, this);
			// this._odatareadset(Constants.VALUEHELP_SRV_URL, "/BSAccDirSet", "directModel", "msg.err.DirectorFetchError");
			// this._initializeModel();
			//combinedModel
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/BSCombinedSet", "combinedModel", "msg.err.DirectorFetchError");
			this.oGlobalBusyDialog.close();
		},
		onAddNewRow: function (oEvent) {
			this._addNewRowGL(oEvent, "tbl_Fsg", "FsgTableModel");
		},
		onRemoveRow: function (oEvent) {
			this._removeRowGL(oEvent, "tbl_Fsg", "FsgTableModel");
		},
		// _initializeModel: function () {
		//           var oFsgTableModel = new JSONModel();
		//           oFsgTableModel.setData({
		//                         "data": [{
		//                                        "ItemNo": 1,
		//                                        "CompCode": "",
		//                                        "Fsg": ""
		//                         }]
		//           });
		//           this.getView().setModel(oFsgTableModel, "FsgTableModel");
		// },
		_onRouteFound: function (oEvt) {
			var oArgument = oEvt.getParameter("arguments");
			//Initialize and bind input elements
			var oModel = new JSONModel();

			if ((oArgument.SelectItem === Constants.EDITREQUEST)) {

				oModel.setData({
					"EditFields": true,
					"EditGLField": true,
					"BSVisible": false

				});

			} else {
				oModel.setData({
					"EditFields": false,
					"EditGLField": false,
					"BSVisible": true

				});

			}

			this.getView().setModel(oModel, "EditModel");
			if (oArgument.SubReq !== undefined && oArgument.SubReq !== "") {
				var oGLBlockModel = new JSONModel();
				oGLBlockModel.setData({
					"FimReq": oArgument.request,
					"subreqno": oArgument.SubReq
				});
				this.getView().setModel(oGLBlockModel, "GLBlockModel");
				this._loadsubrequest(oArgument.request, oArgument.SubReq, Constants.GL_SRV_URL);
			}
		},
		_loadsubrequest: function (request, subrequest, sURL) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			this.oGlobalBusyDialog.open();
			oDataModel.read("/GLItemSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')", {
				urlParameters: {
					"$expand": "GLItemToCCNav"
				},
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						"GlNum": oData.GlNum,
						"Explanation": oData.Explanation,
						"TitleEn": oData.TitleEn,
						"TitleFr": oData.TitleFr,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
						"GrpAccNum": oData.GrpAccNum,
						"Notes": oData.Notes,
					});
					that.getView().byId("ip_glaccount").setValue(oData.GlNum);
					that.getView().byId("ip_acctypebs").setValue(oData.AccType);
					that.getView().byId("ip_chartgroup").setValue(oData.ChartGrp);
					that.getView().byId("cb_direct").setSelectedKey(oData.Director);
					that.getView().byId("ip_Block").setSelectedKey(oData.Actionid);
					that.getView().byId("ip_explain").setValue(oData.Explanation);
					that.getView().byId("ip_st_eng").setValue(oData.TitleEn);
					that.getView().byId("ip_st_fr").setValue(oData.TitleFr);
					that.getView().byId("ip_lo_eng").setValue(oData.LtextEn);
					that.getView().byId("ip_lo_fr").setValue(oData.LtextFr);
					that.getView().byId("ip_desc_eng").setValue(oData.DescEn);
					that.getView().byId("ip_desc_fr").setValue(oData.DescFr);
					that.getView().byId("ip_notes").setValue(oData.Notes);
					var oFsgTableModel = new JSONModel();
					var companyCodeData = {};
					var items = [];
					var value = oData.GLItemToCCNav;
					var status_blk = "BLOCKED";
					if (oData.Actionid === "BLOCK") {
						status_blk = "UNBLOCKED";
					}
					if (value.results.length === 0) {
						companyCodeData = {
							"ItemNo": 1,
							"FimReq": request,
							"SubreqNo": subrequest,
							"CompCode": "",
							"Status": ""

						};
						items.push(companyCodeData);
					} else {
						for (var i = 0; i < value.results.length; i++) {

							companyCodeData = {
								"ItemNo": i + 1,
								"FimReq": request,
								"SubreqNo": subrequest,
								"CompCode": value.results[i].CompCode,
								"Status": status_blk
							};
							items.push(companyCodeData);
						}
					}
					oFsgTableModel.setProperty("/data", items);
					that.getView().byId("tbl_Fsg").setModel(oFsgTableModel, "FsgTableModel");

					that._setEditModel(oData.GlNum, that);
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "GLBlockModel");
					MessageToast.show(that.getMessageBundleText("msg.err.subreqFetchError", [subrequest]));

				}
			});
		},
		_loadChartGroup: function (sGl) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);

			this.oGlobalBusyDialog.open();
			oDataModel.read("/ChartGroupSet('" + sGl + "')", {
				success: function (oData, response) {
					that.getView().byId("ip_chartgroup").setValue(oData.ExGrpCode);
					that.oGlobalBusyDialog.close();
				},
				error: function (oError) {
					MessageToast.show("Error fetching Chart Group based on GL");
					that.oGlobalBusyDialog.close();
				}
			});
		},
		_setEditModel: function (sSelectedGl, that) {
			var oModel = that.getView().getModel("EditModel");

			//BS
			if (sSelectedGl[0] === "1" || sSelectedGl[0] === "2" || sSelectedGl[0] === "3") {
				oModel.setProperty("/BSVisible", true);
				that.getView().byId("ip_acctypebs").setValue(Constants.BS);
			} //PL account
			else if (sSelectedGl[0] === "4" || sSelectedGl[0] === "6" || sSelectedGl[0] === "7") {
				oModel.setProperty("/BSVisible", false);
				that.getView().byId("ip_acctypebs").setValue(Constants.PL);
			}

			if (sSelectedGl !== undefined && sSelectedGl !== null && sSelectedGl !== "") {
				oModel.setProperty("/EditGLField", false);
			}
			that.getView().setModel(oModel, "EditModel");
		},
		_loadExpl: function (sGl) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);

			this.oGlobalBusyDialog.open();
			oDataModel.read("/BSLegcySet('" + sGl + "')", {
				success: function (oData, response) {
					that.getView().byId("ip_explain").setValue(oData.Explaination);
					that.getView().byId("ip_desc_eng").setValue(oData.DesEn);
					that.getView().byId("ip_desc_fr").setValue(oData.DesFr);
					if (sGl[0] === "1" || sGl[0] === "2" || sGl[0] === "3") {
						that.getView().byId("cb_direct").setSelectedKey(oData.CpId);
					}
					that.oGlobalBusyDialog.close();
				},
				error: function (oError) {
					that.oGlobalBusyDialog.close();
				}
			});
		},
		_loadDesc: function (sGl) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			oDataModel.read("/GLDescSet('" + sGl + "')", {
				success: function (oData, response) {
					that.getView().byId("ip_st_eng").setValue(oData.ExShtxt);
					that.getView().byId("ip_st_fr").setValue(oData.ExShtxtFr);
					that.getView().byId("ip_lo_eng").setValue(oData.ExLgtxt);
					that.getView().byId("ip_lo_fr").setValue(oData.ExLgtxtFr);
					that.oGlobalBusyDialog.close();
				},
				error: function (oError) {
					MessageToast.show(that.getMessageBundleText("msg.err.GlCanceldesc", []));

					that.oGlobalBusyDialog.close();
				}
			});
		},
		_validateGlBlk: function (glnum, msg, that) {
			if (glnum.getValue().length !== 7) {
				glnum.setValueState(sap.ui.core.ValueState.Error);

				MessageToast.show(that.getMessageBundleText(msg));
				return false;
			} else {
				if (glnum.getValue()[0] === "5" || glnum.getValue()[0] === "8" || glnum.getValue()[0] === "9" || glnum.getValue()[0] === "0") {
					glnum.setValueState(sap.ui.core.ValueState.Error);
					var GlBlkmsg = that.getResourceBundleText("msg.err.GlBlkmatchError");
					MessageToast.show(that.getMessageBundleText(GlBlkmsg));
					return false;
				} else {
					that.resetValueState(glnum);
					return true;
				}
			}
		},
		onValidateCombo: function (oEvent) {
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var status = "X";
			if (value === "Unblock") {
				status = "";
			}
			var sComboId = sId.split('-')[2]; //id name
			if (sComboId === "cb_direct" || sComboId === "ip_Block") {
				if (!this.checkOnSelection(oEvent)) {
					this.getView().byId(sComboId).setSelectedKey("");
					return;
				} else if (sComboId === "ip_Block") {
					var glval = this.getView().byId("ip_glaccount").getValue();
					if (glval !== "") {
						var that = this;
						var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
						var oFilter = [];
						oFilter.push(new sap.ui.model.Filter("GlNum", "EQ", glval));
						oFilter.push(new sap.ui.model.Filter("Status", "EQ", status));
						this.oGlobalBusyDialog.open();
						oDataModel.read("/CCModifySet", {
							async: false,
							filters: oFilter,
							success: function (oData, response) {
								var GLSubModel = that.getView().getModel("GLBlockModel");
								var value = oData;
								that._loadCompTable(value, GLSubModel.getData().FimReq, GLSubModel.getData().subreqno, that);
								that.oGlobalBusyDialog.close();
							},
							error: function onError(oError) {
								var GLBlockModel = that.getView().getModel("GLBlockModel");
								var oFsgTableModel = new JSONModel();
								oFsgTableModel.setData({
									"data": [{
										"ItemNo": 1,
										"FimReq": GLBlockModel.getData().FimReq,
										"SubreqNo": GLBlockModel.getData().subreqno,
										"CompCode": "",
										"Status": ""
									}]
								});
								that.getView().byId("tbl_Fsg").setModel(oFsgTableModel, "FsgTableModel");
								var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
								var sVal = "";
								for (var i = 1; i < arr.length; i++) {
									sVal = sVal + "\n" + arr[i].message + "\n";
								}
								var msgTitle = that.getResourceBundleText("title.errorMessage");
								sap.m.MessageBox.error(sVal, {
									title: msgTitle, // default
									onClose: null, // default
									styleClass: "", // default
									actions: sap.m.MessageBox.Action.CLOSE, // default
									emphasizedAction: null, // default
									initialFocus: null, // default
									textDirection: sap.ui.core.TextDirection.Inherit // default
								});
								that.oGlobalBusyDialog.close();
							}
						});
					} else {
						this.getView().byId("ip_Block").setSelectedKey("");
						MessageToast.show(this.getMessageBundleText("msg.val.GlError"));
					}
				} else if (value !== "") {
					if (!this.checkOnSelection(oEvent)) return;
				} else {
					oEvent.getSource().setValueState("None");
				}
			}
		},
		_loadCompTable: function (value, request, subrequest, that) {
			var oFsgTableModel = new JSONModel();
			var companyCodeData = {};
			var items = [];
			if (value.results.length === 0) {
				companyCodeData = {
					"ItemNo": 1,
					"FimReq": request,
					"SubreqNo": subrequest,
					"CompCode": "",
					"Status": ""
				};
				items.push(companyCodeData);
			} else {
				for (var i = 0; i < value.results.length; i++) {
					companyCodeData = {
						"ItemNo": i + 1,
						"FimReq": request,
						"SubreqNo": subrequest,
						"CompCode": value.results[i].CompCode,
						"Status": value.results[i].Status
					};
					items.push(companyCodeData);
				}
			}
			oFsgTableModel.setProperty("/data", items);
			that.getView().byId("tbl_Fsg").setModel(oFsgTableModel, "FsgTableModel");
		},
		onSubmitManualGl: function (oEvent) {
			var gl = this.getView().byId("ip_glaccount");
			if (!this._validateGlBlk(gl, "msg.val.GlError", this)) {
				return false;
			}
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			var setname = "/GLModifySet(GlNum='" + gl.getValue() + "',Category='" + Constants.GL + "')";
			oDataModel.read(setname, {
				// urlParameters: {
				//           "$expand": "GLModToCCNav"
				// },
				async: false,
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						"Director": oData.Director,
						// "Explanation": oData.Explanation,
						"TitleEn": oData.TitleEn,
						"TitleFr": oData.TitleFr,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
					});

					//chartgroup
					// if (oData.Explanation !== undefined && oData.Explanation !== null && oData.Explanation !== "") {
					// 		that.getView().byId("ip_explain").setValue(oData.Explanation);
					// 	}
					// that.getView().byId("ip_explain").setValue(oData.Explanation);
					that.getView().byId("ip_desc_eng").setValue(oData.DescEn);
					that.getView().byId("ip_desc_fr").setValue(oData.DescFr);
					that.getView().byId("ip_st_eng").setValue(oData.TitleEn);
					that.getView().byId("ip_st_fr").setValue(oData.TitleFr);
					that.getView().byId("ip_lo_eng").setValue(oData.LtextEn);
					that.getView().byId("ip_lo_fr").setValue(oData.LtextFr);
					that.getView().byId("ip_chartgroup").setValue(oData.ChartGrp);
					that.getView().byId("ip_Block").setSelectedKey(null);
					that._setEditModel(gl.getValue(), that);
					that.getView().byId("cb_direct").setSelectedKey(oData.Director);
					// var GLSubModel = that.getView().getModel("GLBlockModel");
					// var value = oData.GLModToCCNav;
					// that._loadCompTable(value, GLSubModel.getData().FimReq, GLSubModel.getData().subreqno, that);
					// that.resetValueState(that.getView().byId("ip_Block"));
					
					var GLBlockModel = that.getView().getModel("GLBlockModel");
					var oFsgTableModel = new JSONModel();
					oFsgTableModel.setData({
						"data": [{
							"ItemNo": 1,
							"FimReq": GLBlockModel.getData().FimReq,
							"SubreqNo": GLBlockModel.getData().subreqno,
							"CompCode": "",
							"Status": ""
						}]
					});
					that.getView().byId("tbl_Fsg").setModel(oFsgTableModel, "FsgTableModel");
					
					
					that.getView().setModel(oModel, "GLExist");
					// that.getView().setModel(oModifyModel, "GLBlockModel");
					that._setEditModel(gl.getValue(), that);
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
				}
			});
		},
		onPressSave: function (oEvt) {
			if (!this._validateGlBlk(this.getView().byId("ip_glaccount"), "msg.val.GlError", this)) {
				return false;
			}
			var oEntry = {};
			var oGLSubModel = this.getView().getModel("GLBlockModel");
			oEntry.FimReq = oGLSubModel.getData().FimReq;
			oEntry.SubreqNo = oGLSubModel.getData().subreqno;
			oEntry.Category = Constants.GL;
			oEntry.GlNum = this.getView().byId("ip_glaccount").getValue();
			oEntry.ChartGrp = this.getView().byId("ip_chartgroup").getValue();
			oEntry.AccType = this.getView().byId("ip_acctypebs").getValue();

			var oFsgTableModel = this.getView().byId("tbl_Fsg").getModel("FsgTableModel");
			var oTableList = oFsgTableModel.getProperty("/data");
			var oCompanyList = oTableList.map(function (obj) {
				return {
					FimReq: obj.FimReq,
					SubreqNo: obj.SubreqNo,
					CompCode: obj.CompCode
						// Status: obj.Status
				};
			});
			oEntry.GLItemToCCNav = oCompanyList;
			oEntry.Actionid = this.getView().byId("ip_Block").getSelectedKey();
			oEntry.Coa = this.getView().byId("ip_chartacc").getValue();
			oEntry.Director = this.getView().byId("cb_direct").getSelectedKey();
			oEntry.Explanation = this.getView().byId("ip_explain").getValue();
			oEntry.TitleEn = this.getView().byId("ip_st_eng").getValue();
			oEntry.TitleFr = this.getView().byId("ip_st_fr").getValue();
			oEntry.LtextEn = this.getView().byId("ip_lo_eng").getValue();
			oEntry.LtextFr = this.getView().byId("ip_lo_fr").getValue();
			oEntry.DescEn = this.getView().byId("ip_desc_eng").getValue();
			oEntry.DescFr = this.getView().byId("ip_desc_fr").getValue();
			oEntry.Notes = this.getView().byId("ip_notes").getValue();
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			ODataHelper.callODataCREATE(oDataModel, "/GLItemSet", oEntry)
				.then(function onSuccess(oResult, oResponse) {
					that.oGlobalBusyDialog.close();
					that._clearScreenValues(that);
					//Data submitted successfully!
					var msg = that.getMessageBundleText("msg.success.submitForm", [oGLSubModel.getData().subreqno]);
					//Show success message and return to 1st screen
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								that.onNavigateBack(oEvt, that, oGLSubModel.getData().FimReq, "RouteGLBlock");
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				});
		},
		onPressDeleteSub: function (oEvt) {
			var GLSubModel = this.getView().getModel("GLBlockModel");
			this._deleteSubRequest(GLSubModel.getData().FimReq, GLSubModel.getData().subreqno, oEvt, this);
		},
		_clearScreenValues: function (that) {
			var GLBlockModel = this.getView().getModel("GLBlockModel");
			var oFsgTableModel = new JSONModel();
			oFsgTableModel.setData({
				"data": [{
					"ItemNo": 1,
					"FimReq": GLBlockModel.getData().FimReq,
					"SubreqNo": GLBlockModel.getData().subreqno,
					"CompCode": "",
					"Status": ""
				}]
			});
			this.getView().byId("tbl_Fsg").setModel(oFsgTableModel, "FsgTableModel");
			this.resetValueState(this.getView().byId("cb_direct"));
			this.resetValueState(this.getView().byId("ip_Block"));
			this.resetValueState(this.getView().byId("ip_glaccount"));
			var oGLBlockModel = this.getView().getModel("ip_Block");
			//Account Tab
			that.getView().byId("ip_glaccount").setValue("");
			that.getView().byId("ip_acctypebs").setValue("");
			that.getView().byId("ip_chartgroup").setValue("");
			that.getView().byId("ip_explain").setValue("");
			that.getView().byId("cb_direct").setSelectedKey("");
			that.getView().byId("ip_Block").setSelectedKey("");
			//Description Tab
			that.getView().byId("ip_st_eng").setValue("");
			that.getView().byId("ip_st_fr").setValue("");
			that.getView().byId("ip_lo_eng").setValue("");
			that.getView().byId("ip_lo_fr").setValue("");
			that.getView().byId("ip_desc_eng").setValue("");
			that.getView().byId("ip_desc_fr").setValue("");
			that.getView().byId("ip_notes").setValue("");
			//set the first tab as default
			that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
			that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
			that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
		},
		onPressCancel: function (oEvt) {
			var GLBlockModel = this.getView().getModel("GLBlockModel");
			var oFsgTableModel = new JSONModel();
			oFsgTableModel.setData({
				"data": [{
					"ItemNo": 1,
					"FimReq": GLBlockModel.getData().FimReq,
					"SubreqNo": GLBlockModel.getData().subreqno,
					"CompCode": "",
					"Status": ""
				}]
			});
			this.getView().byId("tbl_Fsg").setModel(oFsgTableModel, "FsgTableModel");
			this._clearScreenValues(this);
			var oModel = new JSONModel();
			oModel.setData({
				"EditFields": true,
				"EditGLField": true,
				"BSVisible": false,
				"Openitem": true,
				"REVVisible": false,
				"PLVisible": false
			});
			this.getView().setModel(oModel, "EditModel");
		},
		onNavBack: function (oEvt) {
			var subModel = this.getView().getModel("GLBlockModel");
			var request = subModel.getData().FimReq;
			this._clearScreenValues(this);
			this.onNavigateBack(oEvt, this, request, "RouteGLBlock");
		}

	});

});