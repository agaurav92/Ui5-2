sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"../Util/OdataHelper",
	"../Util/Constants",
	"sap/f/library",
	"../Util/Utility"
], function (BaseController, MessageBox, JSONModel, Filter, MessageToast, Fragment, ODataHelper, Constants, fioriLibrary, Utility) {
	"use strict";

	return BaseController.extend("FIM.FIM.controller.RacModify", {

		onInit: function () {
			//Initialize busy indicator
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			this.oGlobalBusyDialog.open();
			// Router login
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteRacModify").attachMatched(this._onRouteFound, this);

			//populate Rev type code
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/RAVTypeSet", "RAVTypeModel",
				"msg.err.RevTypeFetchError");

			//populate Tax Status
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/TaxStatSet", "TaxStatusModel",
				"msg.err.TaxStatusFetchError");
			// RevType code Help text
			this._revTypecodeHelpText();
			this.oGlobalBusyDialog.close();

		},

		_onRouteFound: function (oEvt) {
			var oArgument = oEvt.getParameter("arguments");
			var oModel = new JSONModel();
			if ((oArgument.SelectItem === Constants.EDITREQUEST)) {
				oModel.setData({
					"EditFields": true,
					"EditRACField": true,
				});
			} else {
				oModel.setData({
					"EditFields": false,
					"EditRACField": false,
				});
			}
			this.getView().setModel(oModel, "EditModel");
			//Initialize and bind input elements
			if (oArgument.SubReq !== undefined && oArgument.SubReq !== "") {
				var oGLSubModel = new JSONModel();
				oGLSubModel.setData({
					"FimReq": oArgument.request,
					"subreqno": oArgument.SubReq,
				});
				this.getView().setModel(oGLSubModel, "RACSubModel");

				//load existing data of the Subrequest 

				this._loadsubrequest(oArgument.request, oArgument.SubReq, oArgument.SelectItem, Constants.GL_SRV_URL);
			}
		},

		//For Load existing data upon Save button 
		_loadsubrequest: function (request, subrequest, item, sURL) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);

			var oModel = new JSONModel();
			that.getView().setModel(oModel, "RACModifyModel");
			that.getView().setModel(oModel, "RACExistingModel");

			this.oGlobalBusyDialog.open();
			oDataModel.read("/GLItemSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')", {
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						// "GlNum": oData.GlNum,
						"Coa": oData.Coa,
						"GlRev": oData.GlRev,
						"Type": oData.Type,
						"TeleTaxStatus": oData.TeleTaxStatus,
						"RevTypeCode": oData.RevTypeCode,
						"Explanation": oData.Explanation,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
						"CompCode": oData.CompCode,
						"Notes": oData.Notes
					});
					that.getView().setModel(oModel, "RACModifyModel");
					that.getView().byId("ip_raccode").setValue(oData.GlNum);

					if (oData.GlNum !== undefined && oData.GlNum !== null && oData.GlNum !== "") {
						// that._setEditModel(that);  // 30/09
						that._loadexistingRAC(oData.GlNum, that, request, subrequest, item);
					}
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "RACModifyModel");
					MessageToast.show(that.getMessageBundleText("msg.err.subreqFetchError", [subrequest]));
				}

			});
		},

		//Load Existing RAC 
		_loadexistingRAC: function (rac, that, request, subrequest, item) {
			that.oGlobalBusyDialog.open();
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			if (item === Constants.COMPLETE_REQUEST) {
				//capture From values from the new table once the request is submitted or other than draft status
				var setname = "/GLInfoOldSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')";
			} else {
				var setname = "/GLModifySet(GlNum='" + rac + "',Category='" + Constants.RAC + "')";
			}
			oDataModel.read(setname, {
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						"Coa": oData.Coa,
						"GlRev": oData.GlRev,
						"RevTypeCode": oData.RevTypeCode,
						"TeleTaxStatus": oData.TeleTaxStatus,
						"Type": oData.Type,
						"Explanation": oData.Explanation,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,
					});
					// that.getView().byId("ip_raccode").setValue(oData.GlNum);
					that.getView().setModel(oModel, "RACExistingModel");
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "RACExistingModel");
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				}
			});
		},
		//Combobox validations
		onValidateCombo: function (oEvent) {
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (sComboId === "cb_revtypecode1" || sComboId === "cb_taxstatus1") {
				if (!this.checkOnSelection(oEvent)) {
					this.getView().byId(sComboId).setSelectedKey("");
					return;
				}
			} else if (value !== "") {
				if (!this.checkOnSelection(oEvent)) return;
			} else {
				oEvent.getSource().setValueState("None");
			}
		},

		//Cancel RAC Modify
		onCancelRacModify: function (oEvt) {
			this._clearScreenValues(this);
		},

		//Delete Sub Request
		onDeletRacModify: function (oEvt) {
			var oRACSubModel = this.getView().getModel("RACSubModel");
			this._deleteSubRequest(oRACSubModel.getData().FimReq, oRACSubModel.getData().subreqno, oEvt, this);
		},

		//onSubmitManualRAC - To get existing values from GL Item table based on Rac Num
		onSubmitManualRAC: function (oEvent) {
			var Rac = this.getView().byId("ip_raccode");
			if (!this._validateRac(Rac, "msg.val.RacError", this)) {
				return false;
			}
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);
			// this.oGlobalBusyDialog.open();
			that.oGlobalBusyDialog.open();
			var setname = "/GLModifySet(GlNum='" + Rac.getValue() + "',Category='" + Constants.RAC + "')";
			oDataModel.read(setname, {
				async: false,
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({

						"Coa": oData.Coa,
						"GlRev": oData.GlRev,
						"RevTypeCode": oData.RevTypeCode,
						"TeleTaxStatus": oData.TeleTaxStatus,
						"Type": oData.Type,
						"Explanation": oData.Explanation,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"DescEn": oData.DescEn,
						"DescFr": oData.DescFr,

					});
					that.getView().byId("ip_raccode").setValue(oData.GlNum);
					that.getView().byId("ip_cocd").setValue(oData.CompCode);
					that.getView().byId("ip_notes").setValue(oData.Notes);
					that.getView().byId("cb_revtypecode").setSelectedKey(oData.RevTypeCode);
					that.getView().byId("cb_taxstatus").setSelectedKey(oData.TeleTaxStatus);

					that.getView().setModel(oModel, "RACExistingModel");

					if (oData.GlNum !== undefined && oData.GlNum !== null && oData.GlNum !== "") {
						that._setEditModel(that);
					}
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "RACExistingModel");
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				}
			});

		},
		//Validation for GL Revenue
		onSubmitGlRevenue: function (oEvt) {
			var Glrev = this.getView().byId("ip_sapglrev1");
			if (!this._validateGlrevenue(Glrev, "msg.err.GlrevError", this)) {
				return false;
			}
		},

		_setEditModel: function (that) {
			var oEditModel = that.getView().getModel("EditModel");
			oEditModel.setProperty("/EditRACField", false);
			that.getView().setModel(oEditModel, "EditModel");
		},

		//For Save RAC Modify
		onSaveRacModify: function (oEvt) {
			//Validate Rac value
			if (!this._validateRac(this.getView().byId("ip_raccode"), "msg.val.RacError", this)) {
				return false;
			}
			//Validate SAP Gl Revenue
			// if (!this._validateGlrevenue(this.getView().byId("ip_sapglrev1"), "msg.val.Glreverror", this)) {
			//            return false;
			// }
			var oEntry = {};
			var oRACSubModel = this.getView().getModel("RACSubModel");

			// Assigning Parameters with Modified values
			oEntry.FimReq = oRACSubModel.getData().FimReq;
			oEntry.SubreqNo = oRACSubModel.getData().subreqno;
			oEntry.Type = Constants.RAC;
			oEntry.Actionid = Constants.MODIFY;
			oEntry.Category = Constants.RAC;
			// Account Tab
			oEntry.GlNum = this.getView().byId("ip_raccode").getValue();
			oEntry.Coa = this.getView().byId("ip_chartacc").getValue();
			// oEntry.GlRev = this.getView().byId("ip_sapglrev").getValue();
			oEntry.GlRev = this.getView().byId("ip_sapglrev1").getValue();
			oEntry.TeleTaxStatus = this.getView().byId("cb_taxstatus1").getSelectedKey();
			oEntry.RevTypeCode = this.getView().byId("cb_revtypecode1").getSelectedKey();
			oEntry.Explanation = this.getView().byId("ip_explain1").getValue();

			//Descriptions
			oEntry.LtextEn = this.getView().byId("ip_titleen1").getValue();
			oEntry.LtextFr = this.getView().byId("ip_titlefr1").getValue();
			oEntry.DescEn = this.getView().byId("ip_descen1").getValue();
			oEntry.DescFr = this.getView().byId("ip_descfr1").getValue();

			//Cocd
			oEntry.CompCode = this.getView().byId("ip_cocd").getValue();
			oEntry.Notes = this.getView().byId("ip_notes").getValue();

			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.GL_SRV_URL, false);

			that.oGlobalBusyDialog.open();
			var setname = "/GLItemSet(FimReq='" + oEntry.FimReq + "',SubreqNo='" + oEntry.SubreqNo + "')";

			ODataHelper.callODataUPDATE(oDataModel, setname, oEntry)
				.then(function onSuccess(oResult, oResponse) {
					that.oGlobalBusyDialog.close();
					that._clearScreenValues(that);
					var msg = that.getMessageBundleText("msg.success.submitForm", [oEntry.SubreqNo]);
					//Show success message and return to 1st screen
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								that.onNavigateBack(oEvt, that, oEntry.FimReq, "RouteRacModify");
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {
					// console.log("error");
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				});
		},

		//Clear Screen values
		_clearScreenValues: function (that) {
			this.resetValueState(this.getView().byId("cb_revtypecode1"));
			this.resetValueState(this.getView().byId("cb_taxstatus1"));
			this.resetValueState(this.getView().byId("ip_sapglrev1"));
			this.resetValueState(this.getView().byId("ip_raccode"));

			var oEditModel = that.getView().getModel("EditModel");
			oEditModel.setProperty("/EditRACField", true);
			that.getView().setModel(oEditModel, "EditModel");

			// Account Tab
			that.getView().byId("ip_raccode").setValue("");
			that.getView().byId("ip_sapglrev").setValue("");
			that.getView().byId("ip_sapglrev1").setValue("");
			that.getView().byId("cb_revtypecode").setValue("");
			that.getView().byId("cb_revtypecode1").setSelectedKey("");
			that.getView().byId("cb_taxstatus").setValue("");
			that.getView().byId("cb_taxstatus1").setSelectedKey("");

			// Explanation Tab

			that.getView().byId("ip_explain").setValue("");
			that.getView().byId("ip_explain1").setValue("");

			// Description Tab
			that.getView().byId("ip_titleen").setValue("");
			that.getView().byId("ip_titleen1").setValue("");
			that.getView().byId("ip_titlefr").setValue("");
			that.getView().byId("ip_titlefr1").setValue("");
			that.getView().byId("ip_descen").setValue("");
			that.getView().byId("ip_descen1").setValue("");
			that.getView().byId("ip_descfr").setValue("");
			that.getView().byId("ip_descfr1").setValue("");

			// CoCd tab
			that.getView().byId("ip_cocd").setValue("");
			that.getView().byId("ip_notes").setValue("");

			//set the first tab as default
			that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
			that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
			that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
		},
		onNavBack: function (oEvt) {
			var subModel = this.getView().getModel("RACSubModel");
			var request = subModel.getData().FimReq;
			this._clearScreenValues(this);
			this.onNavigateBack(oEvt, this, request, "RouteRacModify");
		}

	});

});