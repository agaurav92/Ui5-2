sap.ui.define([],
	function () {
		'use strict';

		var constants = {
			// APP_URL:"bell/piam/bmr/ATAG",
			VALUEHELP_SRV_URL: "/sap/opu/odata/sap/ZFI_FIM_VALUEHELP_SRV/",
			GL_SRV_URL: "/sap/opu/odata/sap/ZFI_FIM_GL_SRV/",
			DATE_FORMAT: "yyyy.MM.dd",
			EDITREQUEST: "1",
			COMPLETE_REQUEST: "3",
			DRAFT: "DRAFT",
			DRAFT_FR: "PR�LIM",
			COMPLETE: "COMPLETED",
			COMPLETE_FR: "COMPL�T�",
			REJECT: "RJCT",
			REJECT_FR: "REJET�",
			VALUE_CREATE: "1",
			VALUE_MODIFY: "2",
			CREATE: "CREATE",
			MODIFY: "MODIFY",
			EXTEND: "EXTEND",
			CANCEL: "CANCEL",
			BLOCK1: "BLOCK/UNBLOCK",
			BLOCK: "BLK/UNBLK",
			BLK: "BLOCK",
			UNBLK: "UNBLOCK",
			SUBMIT: "SUBMITTED",
			MAX_TAGS: 20,
			BS: "B/S",
			PL: "P&L",
			RE: "RE",
			GL: "GL",
			RAC: "RAC"
		};
		return constants;
	});