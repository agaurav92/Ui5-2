/**
 * Utility Class - Provides generic utility functions
 */
sap.ui.define([],
	function (Constants, Utility) {
		'use strict';

		return {
			callODataREAD: function (oDataModel, sPath, oFilter) {
				return new Promise(function (resolve, reject) {
					oDataModel.read(sPath, {
						filters: oFilter,
						success: function onSuccess(oResult, oResponse) {
							resolve(oResult, oResponse);
						},
						error: function onError(oError) {
							reject(oError);
						}
					});
				});
			},
			callODataUPDATE: function (oDataModel, sPath, oEntry) {
				return new Promise(function (resolve, reject) {
					oDataModel.update(sPath, oEntry, {
						success: function onSuccess(oResult, oResponse) {
							resolve(oResult, oResponse);
						},
						error: function onError(oError) {
							reject(oError);
						}
					});
				});
			},
			callODataCREATE: function (oDataModel, sPath, oEntry) {
				return new Promise(function (resolve, reject) {
					oDataModel.create(sPath, oEntry, {
						success: function onSuccess(oResult, oResponse) {
							resolve(oResult, oResponse);
						},
						error: function onError(oError) {
							reject(oError);
						}
					});
				});
			}
		};
	});