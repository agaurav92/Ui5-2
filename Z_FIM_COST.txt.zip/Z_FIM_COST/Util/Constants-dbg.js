sap.ui.define([],
	function () {
		'use strict';

		var constants = {
			VALUEHELP_SRV_URL: "/sap/opu/odata/sap/ZFI_FIM_VALUEHELP_SRV/",
			COSTCENTER_SRV_URL: "/sap/opu/odata/sap/ZFI_FIM_COST_CENTER_SRV/",
			DATE_FORMAT: "yyyy.MM.dd",
			EDITREQUEST: "1",
			DRAFT: "DRAFT",
			DRAFT_FR: "PR�LIM",
			VALUE_CREATE: "1",
			VALUE_MODIFY: "2",
			NO: "NO",
			CC: "CC",
			CREATE: "CREATE",
			MODIFY: "MODIFY",
			CANCEL: "CANCEL",
			BLK: "BLK/UNBLK",
			SUBMIT: "SUBMITTED"
		};
		return constants;
	});