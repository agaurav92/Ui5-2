/*global QUnit*/

sap.ui.define([
	"fim/costcenter/Z_FIM_COSTCENTER/controller/block.controller"
], function (Controller) {
	"use strict";

	QUnit.module("block Controller");

	QUnit.test("I should test the block controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});