sap.ui.define([
	"FIM/COSTCENTER/CostCenter/test/unit/controller/View1.controller"
], function () {
	"use strict";
});