sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"../Util/OdataHelper",
	"../Util/Constants",
	"../Util/Utility"
], function (BaseController, MessageBox, JSONModel, Filter, MessageToast, Fragment, ODataHelper, Constants, Utility) {
	"use strict";

	return BaseController.extend("FIM.COSTCENTER.CostCenter.controller.CCModify", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 */
		onInit: function () {
			//Initialize busy indicator
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			this.oGlobalBusyDialog.open();
			// // Router login
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._loadDropDown();
			oRouter.getRoute("RouteCCModify").attachMatched(this._onRouteFound, this);
			this.oGlobalBusyDialog.close();
		},
		_loadDropDown: function () {
			var oModModel = new JSONModel();
			oModModel.setData({
				"data": [{
					"Key": "NO",
					"Value": "No Movement"
				}, {
					"Key": "INTER",
					"Value": "Inter Movement"
				}, {
					"Key": "INTRA",
					"Value": "Intra Movement"
				}]
			});
			this.getView().setModel(oModModel, "ModGlDrop");
			//Category drop down
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/CCCategorySet", "CategoryModel", "msg.err.CategoryFetchError");
			// Department drop down
			// this._odatareadset(Constants.VALUEHELP_SRV_URL, "/CCDeptSet", "DepartmentModel", "msg.err.DeptFetchError");
			// BizType drop down
			// this._odatareadset(Constants.VALUEHELP_SRV_URL, "/CCBizTypeSet", "BizTypeModel", "msg.err.BiztypsFetchError");
		},
		_onRouteFound: function (oEvt) {
			var oArgument = oEvt.getParameter("arguments");
			var oModel = new JSONModel();
			//Company code drop down
			var oFilter = [];
			if ((oArgument.SelectItem === Constants.EDITREQUEST)) {
				oFilter.push(new sap.ui.model.Filter("CostCenterCheckox", "EQ", "YES"));
				oModel.setData({
					"EditFields": true, //all fields
					"EditCompField": true, //compcode
					"EditCCField": true, //costcenter
					"DisplayHier": true,
					"HierMandate": false,
					"DisplayBiz": true,
					"DisplayLock": false
				});
			} else {
				oFilter.push(new sap.ui.model.Filter("CostCenterCheckox", "EQ", "SUB"));
				oModel.setData({
					"EditFields": false,
					"EditCompField": false,
					"EditCCField": false,
					"DisplayHier": false,
					"HierMandate": false,
					"DisplayBiz": false,
					"DisplayLock": false
				});
			}
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/TCompCodeSet", "CompModel", "msg.err.CompFetchError", oFilter);
			this.getView().setModel(oModel, "EditModel");
			if (oArgument.SubReq !== undefined && oArgument.SubReq !== "") {
				var oCCSubModel = new JSONModel();
				oCCSubModel.setData({
					"data": {
						"FimReq": oArgument.request,
						"subreqno": oArgument.SubReq
					}
				});
				this.getView().setModel(oCCSubModel, "CCSubModel");
				//load existing data of the Subrequest which is already saved in the table
				this._loadsubrequest(oArgument.request, oArgument.SubReq, Constants.COSTCENTER_SRV_URL, oArgument.SelectItem);
			}
		},
		_loadsubrequest: function (request, subrequest, sURL, item) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			var oModel = new JSONModel();
			that.getView().setModel(oModel, "CCModifyModel");
			that.getView().setModel(oModel, "CCExist");
			this.oGlobalBusyDialog.open();
			var setname = "/CostCenterModifySet(FimReq='" + request + "',SubreqNo='" + subrequest +
				"',Actionid='',CostCenter='',CtrlArea='',CompCode='')";
			oDataModel.read(setname, {
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModifyModel = new JSONModel();
					var oModel = new JSONModel();
					that.getView().byId("cb_compcode").setSelectedKey(oData.CompCode);
					that.getView().byId("ip_controlarea").setValue(oData.CtrlArea);
					that.getView().byId("ip_costcenter").setValue(oData.CostCenter);
					//set to values
					oModifyModel.setData({
						"PersResp": oData.PersResp,
						"Department": oData.Department,
						"Biztype": oData.Biztype,
						"CostCategory": oData.CostCategory,
						"TitleEn": oData.TitleEn,
						"TitleFr": oData.TitleFr,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"HierArea": oData.HierArea,
						"HierDesc": oData.HierDesc,
						"NotesHier": oData.NotesHier,
						"Bizflag": oData.Bizflag,
						"NotesBiz": oData.NotesBiz,
						"Notes": oData.Notes,
						"MvtTyp": oData.MvtTyp,
						"ModifyType": oData.ModifyType,
						"Explanation": oData.Explanation,
					});
					that.getView().setModel(oModifyModel, "CCModifyModel");
					//set from values in the model
					oModel.setData({
						"FrmHarea": oData.FrmHarea, //hier area
						"FromHaDes": oData.FromHaDes, //Desc
						"FrmBiz": oData.FrmBiz, //Biz type
						"FromTen": oData.FromTen, //short text en
						"FromTfr": oData.FromTfr, //shrt text fr
						"FromLte": oData.FromLte, //long text en
						"FromLfr": oData.FromLfr, //long text fr
						"FromPerrsp": oData.FromPerrsp, //person resp
						"FromDept": oData.FromDept, //Dep
						"FromCcat": oData.FromCcat, //category
						//checkbox from values
						"FrmAprime": oData.FrmAprime,
						"FrmAsecond": oData.FrmAsecond,
						"FrmArev": oData.FrmArev,
						"FrmPlPrime": oData.FrmPlPrime,
						"FrmPlSec": oData.FrmPlSec,
						"FrmPlRev": oData.FrmPlRev,
						"FromCommit": oData.FromCommit
					});
					that.getView().setModel(oModel, "CCExist");
					// to checkbox values

					that.getView().byId("ip_validfrom").setValue(that._FormatDate(oData.ValidFrom));
					that.getView().byId("ip_validto").setValue(that._FormatDate(oData.ValidTo));

					that.setcheckbox(oData.ActPrime, "ip_actpri", that); //actual prime
					that.setcheckbox(oData.ActSecond, "ip_actsec", that); //actualsec
					that.setcheckbox(oData.ActRev, "ip_actrev", that); //actualrev
					that.setcheckbox(oData.PlanPrime, "ip_plnpri", that); //Plan prime
					that.setcheckbox(oData.PlanSecond, "ip_plnsec", that); //plan sec
					that.setcheckbox(oData.PlanRev, "ip_plnrev", that); //planrev
					that.setcheckbox(oData.CommitUpdt, "ip_comm", that); //commit
					//from check box
					that.setcheckbox(oData.FrmAprime, "ip_actpri_frm", that); //actual prime
					that.setcheckbox(oData.FrmAsecond, "ip_actsec_frm", that); //actualsec
					that.setcheckbox(oData.FrmArev, "ip_actrev_frm", that); //actualrev
					that.setcheckbox(oData.FrmPlPrime, "ip_plnpri_frm", that); //Plan prime
					that.setcheckbox(oData.FrmPlSec, "ip_plnsec_frm", that); //plan sec
					that.setcheckbox(oData.FrmPlRev, "ip_plnrev_frm", that); //planrev
					that.setcheckbox(oData.FromCommit, "ip_comm_frm", that); //commit
					that._setEditModel(oData.Bizflag, oData.MvtTyp, oData.ModifyType, oData.CompCode, oData.CostCenter, that);
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that._onErrorOdata(oError, that);
					that.oGlobalBusyDialog.close();
				}
			});
		},
		setcheckbox(oData, id, that) {
			if (oData === "X") {
				that.getView().byId(id).setSelected(true);
			} else {
				that.getView().byId(id).setSelected(false);
			}
		},
		onChangeCCComp: function (oEvent) {
			var Comp = oEvent.getSource().getSelectedKey();
			if (!this.checkOnSelection(oEvent)) {
				return;
			} else {
				this.getView().byId("cb_compcode").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("cb_compcode").setValueStateText("");
			}
			this.oGlobalBusyDialog.open();
			var oModel = this.getView().getModel("EditModel");
			var oCCModifyModel = this.getView().getModel("CCModifyModel");
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			var setname = "/CCCtrlAreaSet('" + Comp + "')";
			oDataModel.read(setname, {
				success: function onSuccess(oData, oResponse) {
					that.getView().byId("ip_controlarea").setValue(oData.ExKokrs);
					if (oData.ExKokrs !== undefined && oData.ExKokrs !== null && oData.ExKokrs !== "") {
						oCCModifyModel.setProperty("/Bizflag", oData.ExFlag);
						that.getView().setModel(oCCModifyModel, "CCModifyModel");
						if (oData.ExFlag === "X") {
							oModel.setProperty("/DisplayBiz", true);
						} else {
							oModel.setProperty("/DisplayBiz", false);
						}
						//make compcode field not editable as soon as its choosen
						oModel.setProperty("/EditCompField", false);
						that.getView().setModel(oModel, "EditModel");
					}
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that._onErrorOdata(oError, that);
					that.oGlobalBusyDialog.close();
					return;
				}
			});
		},
		onChangeModifyType: function (oEvent) { //Modify/Block
			var value = oEvent.getSource().getSelectedKey();
			if (!this.checkOnSelection(oEvent)) {
				return;
			} else {
				this.getView().byId("cb_modifytype").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("cb_modifytype").setValueStateText("");
			}
			var oModel = this.getView().getModel("EditModel");
			if (value === Constants.BLK) {
				oModel.setProperty("/DisplayLock", true);
			} else {
				oModel.setProperty("/DisplayLock", false);
			}
			this.getView().setModel(oModel, "EditModel");
			//clear the To values everytime
			this.setcheckbox("", "ip_actpri", this); //actual prime
			this.setcheckbox("", "ip_actsec", this); //actualsec
			this.setcheckbox("", "ip_actrev", this); //actualrev
			this.setcheckbox("", "ip_plnpri", this); //Plan prime
			this.setcheckbox("", "ip_plnsec", this); //plan sec
			this.setcheckbox("", "ip_plnrev", this); //planrev
			this.setcheckbox("", "ip_comm", this); //commit
		},
		onChangeHier: function (oEvt) {
			// var value = oEvt.mParameters.value;
			var value = this.getView().byId("ip_hierarea").getValue();
			var splitid = value.split(' '); //id name
			if (splitid.length > 1) {
				this.getView().byId("ip_hierarea").setValue("");
				this.getView().byId("ip_hierarea").setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(this.getMessageBundleText("msg.val.hier"));
				return;
			} else {
				this.resetValueState(this.getView().byId("ip_hierarea"));
			}
			var coa = this.getView().byId("ip_controlarea").getValue();
			if (value !== undefined && value !== "" && value !== null && coa !== undefined && coa !== null && coa !== "") {
				var that = this;
				var oModel = this.getView().getModel("EditModel");
				that.oGlobalBusyDialog.open();
				var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
				var setname = "/CCHierSet(HierArea='" + value + "',Kokrs='" + coa + "')";
				oDataModel.read(setname, {
					success: function onSuccess(oData, oResponse) {
						that.getView().byId("ip_hdesc").setValue(oData.Desc);
						that.getView().byId("ip_hierarea").setValue(oData.HierArea);
						// if (oData.Flag === "X") { //new hier area so open the desc field
						// 	oModel.setProperty("/EditHierdesc", true);
						// } else {
						// 	that.getView().byId("ip_hdesc").setValue(oData.Desc);
						// 	oModel.setProperty("/EditHierdesc", false);
						// }
						//make compcode field not editable as soon as its choosen
						// that.getView().setModel(oModel, "EditModel");
						that.oGlobalBusyDialog.close();
					},
					error: function onError(oError) {
						that.oGlobalBusyDialog.close();
						that._onErrorOdata(oError, that);
						return;
					}
				});
			}

		},
		onChangeMoveType: function (oEvent) { //No Move/Inter/Intra
			var value = oEvent.getSource().getSelectedKey();
			if (!this.checkOnSelection(oEvent)) {
				return;
			} else {
				this.getView().byId("cb_movetype").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("cb_movetype").setValueStateText("");
			}
			this._setModifyDrop(value, this);
		},
		_setModifyDrop: function (value, that) {
			var oModel = that.getView().getModel("EditModel");
			if (value === Constants.NO) {
				that.getView().byId("ip_hierarea").setValue("");
				that.getView().byId("ip_hdesc").setValue("");
				oModel.setProperty("/DisplayHier", false);
				oModel.setProperty("/HierMandate", false);
				// oModel.setProperty("/EditHierdesc", false);
			} else {
				oModel.setProperty("/DisplayHier", true);
				oModel.setProperty("/HierMandate", true);
				// oModel.setProperty("/EditHierdesc", false);
			}
			that.getView().setModel(oModel, "EditModel");
		},
		onSubmitManualCC: function (oEvent) {
			var cc = this.getView().byId("ip_costcenter");
			var comp = this.getView().byId("cb_compcode").getSelectedKey();
			var that = this;
			var control = that.getView().byId("ip_controlarea").getValue();
			if (control === undefined || control === null || control === "") {
				that.getView().byId("cb_compcode").setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText("msg.val.CompCode"));
				return;
			} else {
				this.resetValueState(this.getView().byId("cb_compcode"));
			}
			if (cc.getValue() !== undefined && cc.getValue() !== null && cc.getValue() !== "") {
				this.oGlobalBusyDialog.open();
				var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.COSTCENTER_SRV_URL, false);
				var setname = "/CostCenterModifySet(FimReq='',SubreqNo='',Actionid='',CostCenter='" + cc.getValue() + "',CompCode='" + comp +
					"',CtrlArea='" + control + "')";
				oDataModel.read(setname, {
					success: function onSuccess(oData, oResponse) {
						var oModel = new JSONModel();
						//set from values
						oModel.setData({
							"FrmHarea": oData.FrmHarea, //hier area
							"FromHaDes": oData.FromHaDes, //desc
							"FrmBiz": oData.FrmBiz, //Biz type
							"FromTen": oData.FromTen, //short text en
							"FromTfr": oData.FromTfr, //shrt text fr
							"FromLte": oData.FromLte, //long text en
							"FromLfr": oData.FromLfr, //long text fr
							"FromPerrsp": oData.FromPerrsp, //person resp
							"FromDept": oData.FromDept, //Dep
							"FromCcat": oData.FromCcat, //category
							//checkbox from values
							"FrmAprime": oData.FrmAprime,
							"FrmAsecond": oData.FrmAsecond,
							"FrmArev": oData.FrmArev,
							"FrmPlPrime": oData.FrmPlPrime,
							"FrmPlSec": oData.FrmPlSec,
							"FrmPlRev": oData.FrmPlRev,
							"FromCommit": oData.FromCommit
						});
						that.getView().setModel(oModel, "CCExist");

						that.getView().byId("ip_validfrom").setValue(that._FormatDate(oData.ValidFrom));
						that.getView().byId("ip_validto").setValue(that._FormatDate(oData.ValidTo));
						//from check box
						that.setcheckbox(oData.FrmAprime, "ip_actpri_frm", that); //actual prime
						that.setcheckbox(oData.FrmAsecond, "ip_actsec_frm", that); //actualsec
						that.setcheckbox(oData.FrmArev, "ip_actrev_frm", that); //actualrev
						that.setcheckbox(oData.FrmPlPrime, "ip_plnpri_frm", that); //Plan prime
						that.setcheckbox(oData.FrmPlSec, "ip_plnsec_frm", that); //plan sec
						that.setcheckbox(oData.FrmPlRev, "ip_plnrev_frm", that); //planrev
						that.setcheckbox(oData.FromCommit, "ip_comm_frm", that); //commit

						var oModel = that.getView().getModel("EditModel");
						oModel.setProperty("/EditCCField", false);
						that.getView().setModel(oModel, "EditModel");

						that.oGlobalBusyDialog.close();
					},
					error: function onError(oError) {
						that._onErrorOdata(oError, that);
						that.oGlobalBusyDialog.close();
						return;
					}
				});
			};
		},
		_setEditModel: function (biztype, movtype, modifytype, comp, costcenter, that) {
			var oModel = that.getView().getModel("EditModel");
			if (costcenter !== null && costcenter !== "" && costcenter !== undefined) {
				oModel.setProperty("/EditCCField", false);
			} else {
				oModel.setProperty("/EditCCField", true);
			}
			if (comp !== null && comp !== "" && comp !== undefined) {
				oModel.setProperty("/EditCompField", false);
			} else {
				oModel.setProperty("/EditCompField", true);
			}
			//Movement type details
			if (movtype === Constants.NO) {
				that.getView().byId("ip_hierarea").setValue("");
				that.getView().byId("ip_hdesc").setValue("");
				oModel.setProperty("/DisplayHier", false);
				oModel.setProperty("/HierMandate", false);
				// oModel.setProperty("/EditHierdesc", false);

			} else {
				oModel.setProperty("/DisplayHier", true);
				oModel.setProperty("/HierMandate", true);
				// oModel.setProperty("/EditHierdesc", false);
			}
			//Modifytype details
			if (modifytype === "BLK/UNBLK") {
				oModel.setProperty("/DisplayLock", true);
			} else {
				oModel.setProperty("/DisplayLock", false);
			}
			//Biz type details
			if (biztype === "X") {
				oModel.setProperty("/DisplayBiz", true);
			} else {
				oModel.setProperty("/DisplayBiz", false);
			}

			that.getView().setModel(oModel, "EditModel");
		},
		onValidateCombo: function (oEvent) {
			var bValid = oEvent.getSource().getSelectedKey();
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (value !== "") {
				if (!this.checkOnSelection(oEvent)) {
					return;
				}
			} else {
				this.getView().byId(sComboId).setValueState(sap.ui.core.ValueState.None);
				this.getView().byId(sComboId).setValueStateText("");
			}
		},
		_resetvaluestatus: function (that) {
			that.resetValueState(that.getView().byId("cb_compcode"));
			that.resetValueState(that.getView().byId("ip_costcenter"));
			that.resetValueState(that.getView().byId("cb_dept"));
			that.resetValueState(that.getView().byId("cb_category"));
			that.resetValueState(that.getView().byId("ip_biz"));
			that.resetValueState(that.getView().byId("ip_notehier"));
			that.resetValueState(that.getView().byId("ip_hierarea"));
		},
		_clearScreenValues: function (that) {
			that._resetvaluestatus(that);
			that.getView().byId("ip_costcenter").setValue("");
			that.getView().byId("ip_controlarea").setValue("");
			that.getView().byId("cb_compcode").setSelectedKey("");
			that.getView().byId("ip_validfrom").setValue("");
			that.getView().byId("ip_validto").setValue("");
			var oModel = new JSONModel();
			var oModifyModel = new JSONModel();
			oModifyModel.setData({
				"PersResp": "",
				"Department": "",
				"Biztype": "",
				"CostCategory": "",
				"TitleEn": "",
				"TitleFr": "",
				"LtextEn": "",
				"LtextFr": "",
				"HierArea": "",
				"HierDesc": "",
				"NotesHier": "",
				"Bizflag": "",
				"NotesBiz": "",
				"Notes": "",
				"MvtTyp": "",
				"ModifyType": "",
				"Explanation": "",
			});
			that.getView().setModel(oModifyModel, "CCModifyModel");
			//set from values in the model
			oModel.setData({
				"FrmHarea": "", //hier area
				"FromHaDes": "", //Desc
				"FrmBiz": "", //Biz type
				"FromTen": "", //short text en
				"FromTfr": "", //shrt text fr
				"FromLte": "", //long text en
				"FromLfr": "", //long text fr
				"FromPerrsp": "", //person resp
				"FromDept": "", //Dep
				"FromCcat": "", //category
				//checkbox from values
				"FrmAprime": "",
				"FrmAsecond": "",
				"FrmArev": "",
				"FrmPlPrime": "",
				"FrmPlSec": "",
				"FrmPlRev": "",
				"FromCommit": ""
			});
			that.getView().setModel(oModel, "CCExist");
			//checkbox
			//to values
			that.getView().byId("ip_actpri").setSelected(false);
			that.getView().byId("ip_actsec").setSelected(false);
			that.getView().byId("ip_actrev").setSelected(false);
			that.getView().byId("ip_plnpri").setSelected(false);
			that.getView().byId("ip_plnsec").setSelected(false);
			that.getView().byId("ip_plnrev").setSelected(false);
			that.getView().byId("ip_comm").setSelected(false);
			//from values
			that.getView().byId("ip_actpri_frm").setSelected(false);
			that.getView().byId("ip_actsec_frm").setSelected(false);
			that.getView().byId("ip_actrev_frm").setSelected(false);
			that.getView().byId("ip_plnpri_frm").setSelected(false);
			that.getView().byId("ip_plnsec_frm").setSelected(false);
			that.getView().byId("ip_plnrev_frm").setSelected(false);
			that.getView().byId("ip_comm_frm").setSelected(false);
			//set the first tab as default
			that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
			that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
			that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
		},
		onPressSaveModify: function (oEvt) {
			var oCCModifyModel = this.getView().getModel("CCModifyModel");
			var oCCExist = this.getView().getModel("CCExist");
			var oCCSubModel = this.getView().getModel("CCSubModel");
			var oEntry = {};
			var value = this.getView().byId("ip_hierarea").getValue();
			var splitid = value.split(' '); //id name
			if (splitid.length > 1) {
				this.getView().byId("ip_hierarea").setValue("");
				MessageToast.show(this.getMessageBundleText("msg.val.hier"));
				this.getView().byId("ip_hierarea").setValueState(sap.ui.core.ValueState.Error);
				return;
			} else {
				this.resetValueState(this.getView().byId("ip_hierarea"));
			}

			oEntry.FimReq = oCCSubModel.getData().data.FimReq;
			oEntry.SubreqNo = oCCSubModel.getData().data.subreqno;
			oEntry.Actionid = Constants.MODIFY;
			oEntry.Category = Constants.CC;

			oEntry.CompCode = this.getView().byId("cb_compcode").getSelectedKey();
			oEntry.CtrlArea = this.getView().byId("ip_controlarea").getValue();
			oEntry.CostCenter = this.getView().byId("ip_costcenter").getValue();
			if (oEntry.CompCode === undefined || oEntry.CompCode === "" || oEntry.CompCode === null || oEntry.CtrlArea === undefined || oEntry.CtrlArea ===
				"" || oEntry.CtrlArea === null || oEntry.CostCenter === undefined || oEntry.CostCenter === "" || oEntry.CostCenter === null
			) {
				MessageToast.show(this.getMessageBundleText("msg.Val.Mandatory"));
				return;
			}
			//from values
			oEntry.FrmHarea = oCCExist.getData().FrmHarea;
			oEntry.FromHaDes = oCCExist.getData().FromHaDes;
			oEntry.FrmBiz = oCCExist.getData().FrmBiz;
			oEntry.FromTen = oCCExist.getData().FromTen;
			oEntry.FromTfr = oCCExist.getData().FromTfr;
			oEntry.FromLte = oCCExist.getData().FromLte;
			oEntry.FromLfr = oCCExist.getData().FromLfr;
			oEntry.FromPerrsp = oCCExist.getData().FromPerrsp;
			oEntry.FromDept = oCCExist.getData().FromDept;
			oEntry.FromCcat = oCCExist.getData().FromCcat;
			var ValidFrom = this.getView().byId("ip_validfrom").getValue();
			var ValidTo = this.getView().byId("ip_validto").getValue();

			if (ValidFrom !== undefined && ValidFrom !== null && ValidFrom !== "") {
				oEntry.ValidFrom = this._correctDateFormat(ValidFrom);
			}
			if (ValidTo !== undefined && ValidTo !== null && ValidTo !== "") {
				oEntry.ValidTo = this._correctDateFormat(ValidTo);
			}
			//To values
			oEntry.Bizflag = oCCModifyModel.getData().Bizflag;
			oEntry.Biztype = oCCModifyModel.getData().Biztype;
			oEntry.NotesBiz = oCCModifyModel.getData().NotesBiz;

			oEntry.MvtTyp = oCCModifyModel.getData().MvtTyp;
			oEntry.Explanation = oCCModifyModel.getData().Explanation;
			oEntry.TitleEn = oCCModifyModel.getData().TitleEn;
			oEntry.TitleFr = oCCModifyModel.getData().TitleFr;
			oEntry.LtextEn = oCCModifyModel.getData().LtextEn;
			oEntry.LtextFr = oCCModifyModel.getData().LtextFr;
			oEntry.ModifyType = oCCModifyModel.getData().ModifyType;
			oEntry.PersResp = oCCModifyModel.getData().PersResp;
			oEntry.Department = oCCModifyModel.getData().Department;
			oEntry.CostCategory = oCCModifyModel.getData().CostCategory;
			if (Constants.NO) {
				oEntry.HierArea = oCCModifyModel.getData().HierArea;
				oEntry.HierDesc = oCCModifyModel.getData().HierDesc;
			}
			oEntry.NotesHier = oCCModifyModel.getData().NotesHier;
			oEntry.Notes = oCCModifyModel.getData().Notes;
			//checkbox from values
			oEntry.FrmAprime = oCCExist.getData().FrmAprime;
			oEntry.FrmAsecond = oCCExist.getData().FrmAsecond;
			oEntry.FrmArev = oCCExist.getData().FrmArev;
			oEntry.FrmPlPrime = oCCExist.getData().FrmPlPrime;
			oEntry.FrmPlSec = oCCExist.getData().FrmPlSec;
			oEntry.FrmPlRev = oCCExist.getData().FrmPlRev;
			oEntry.FromCommit = oCCExist.getData().FromCommit;

			// //To values of check box
			oEntry.ActPrime = " ";
			oEntry.ActSecond = " ";
			oEntry.ActRev = " ";
			oEntry.PlanSecond = " ";
			oEntry.PlanRev = " ";
			oEntry.CommitUpdt = " ";
			if (this.getView().byId("ip_actpri").getSelected()) {
				oEntry.ActPrime = "X";
			}
			if (this.getView().byId("ip_actsec").getSelected()) {
				oEntry.ActSecond = "X";
			}
			if (this.getView().byId("ip_actrev").getSelected()) {
				oEntry.ActRev = "X";
			}
			if (this.getView().byId("ip_plnpri").getSelected()) {
				oEntry.PlanPrime = "X";
			}
			if (this.getView().byId("ip_plnsec").getSelected()) {
				oEntry.PlanSecond = "X";
			}
			if (this.getView().byId("ip_plnrev").getSelected()) {
				oEntry.PlanRev = "X";
			}
			if (this.getView().byId("ip_comm").getSelected()) {
				oEntry.CommitUpdt = "X";
			}
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.COSTCENTER_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			var setname = "/CostCenterModifySet(FimReq='" + oCCSubModel.getData().data.FimReq + "',SubreqNo='" + oCCSubModel.getData().data.subreqno +
				"',Actionid='',CostCenter='',CtrlArea='',CompCode='')";
			ODataHelper.callODataUPDATE(oDataModel, setname, oEntry)
				.then(function onSuccess(oResult, oResponse) {
					that.oGlobalBusyDialog.close();
					that._clearScreenValues(that);
					var msg = that.getMessageBundleText("msg.success.submitForm", [oCCSubModel.getData().data.subreqno]);
					//Show success message and return to 1st screen
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								that.onNavigateBack(oEvt, that, oCCSubModel.getData().data.FimReq, "RouteCCModify");
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {
					that._onErrorOdata(oError, that);
					that.oGlobalBusyDialog.close();
					return;
				});
		},

		onNavBack: function (oEvt) {
			var subModel = this.getView().getModel("CCSubModel");
			var request = subModel.getData().data.FimReq;
			this._clearScreenValues(this);
			this.onNavigateBack(oEvt, this, request, "RouteCCModify");
		}
	});

});