sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("fim.costcenter.Z_FIM_COSTCENTER.controller.block", {
		onInit: function () {

		},

		onValidateCombo: function (oEvent) {
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[6]; //id name
			if (sComboId === "ip_Block") {
				if (!this.checkOnSelection(oEvent)) {
					this.getView().byId("ip_Block").setSelectedKey("");
					return;
				}
			}
		},
		checkOnSelection: function (oEvent) {
			var oInput = oEvent.getSource();
			var bValid = oInput.getSelectedKey();
			oInput.setValueState(!bValid ? "Error" : "None");
			return bValid;
		}
	});
});