sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/f/library",
	"sap/ui/core/Fragment",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/format/NumberFormat",
	"../Util/OdataHelper",
	"../Util/Constants",
	"../Util/Utility"
], function (jQuery, Controller, MessageToast, MessageBox, JSONModel, History, fioriLibrary, Fragment, DateFormat, NumberFormat,
	ODataHelper,
	Constants, Utility) {
	"use strict";

	return Controller.extend("FIM.COSTCENTER.CostCenter.controller.BaseController", {
		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return this.getOwnerComponent().getRouter();
		},

		/**
		 * Convenience method to get the resource bundle.
		 * @public
		 * @returns resource text in the i18n resourceModel that corresponds to the sKey
		 */
		getResourceBundleText: function (sKey) {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sKey);
		},
		//while passing the date to the backend date is considered to be yesterday's date
		_correctDateFormat: function (sDate) {
			if (!sDate) {
				return sDate;
			}
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var oDate = dateFormat.format(new Date(sDate));
			oDate = oDate + "T00:00:00";
			return oDate;
		},
		/**
		 * Convenience method to get a resource text from the message bundle based on the provided key
		 * @public
		 * @returns messageText in the message Bundle that corresponds to the sKey
		 */
		getMessageBundleText: function (sKey, mArgs) {
			jQuery.sap.require("jquery.sap.resources");
			var sLocale = sap.ui.getCore().getConfiguration().getLanguage();
			var oBundle = jQuery.sap.resources({
				url: "i18n/messageBundle.properties",
				locale: sLocale
			});
			return oBundle.getText(sKey, mArgs);
		},
		_deleteSubRequest: function (request, subrequest, oEvt, that) {
			var setname = "/CostCenterItemSet(FimReq='" + request + "',SubreqNo='" + subrequest +
				"')";
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.COSTCENTER_SRV_URL, false);
			that.oGlobalBusyDialog.open();
			oDataModel.remove(setname, {
				method: "DELETE",
				success: function (data) {
					that._clearScreenValues(that);
					that.onNavigateBack(oEvt, that, request);
					MessageToast.show(that.getMessageBundleText("msg.suc.DeleteSubRequest", [subrequest]));
					that.oGlobalBusyDialog.close();
				},
				error: function (e) {
					MessageToast.show(that.getMessageBundleText("msg.err.DeleteSubRequest", [subrequest]));
					that.oGlobalBusyDialog.close();
				}
			});
		},
		_validateCC: function (CC, msg, that) {
			if (CC.getValue().length !== 10) {
				CC.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText(msg));
				return false;
			} else {
				that.resetValueState(CC);
				return true;
			}
		},
		_validateValue: function (id, msg, that) {
			if (id.getValue() === undefined || id.getValue() === null || id.getValue() === "") {
				id.setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText(msg));
				return false;
			} else {
				that.resetValueState(id);
				return true;
			}
		},
		/**
		 * Navigates back in the browser history, if the entry was created by this app.
		 * If not, it navigates to a route passed to this function.
		 * 
		 * @public
		 * @param {string} sRoute the name of the route if there is no history entry
		 * @param {object} mData the parameters of the route, if the route does not need parameters, it may be omitted.
		 */
		onNavigateBack: function (oEvt, that, request, routename) {
			if (request !== undefined && request !== null && request !== "") {
				that.oRouter = that.getOwnerComponent().getRouter();
				if (routename !== undefined && routename !== null && routename !== "") {
					that.oRouter.getRoute(routename).detachPatternMatched(that._onRouteFound, that);
				}
				that.oRouter.navTo("subrequest", {
					layout: fioriLibrary.LayoutType.TwoColumnsMidExpanded,
					request: request,
				});
			} else {
				var oHistory, sPreviousHash;
				oHistory = History.getInstance();
				sPreviousHash = oHistory.getPreviousHash();

				if (sPreviousHash !== undefined) {
					window.history.go(-1);
				} else {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
					oRouter.navTo("", true);
				}
			}
		},
		_odatareadset: function (sURL, osetName, oModelName, sMessage, ofilter) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			that.oGlobalBusyDialog.open();
			ODataHelper.callODataREAD(oDataModel, osetName, ofilter)
				.then(function onSuccess(oData, oResponse) {
					var oModel = new JSONModel();
					oModel.setData({
						data: oData.results
					});
					that.getView().setModel(oModel, oModelName);
					that.oGlobalBusyDialog.close();
				})
				.catch(function onError(oError) {
					MessageToast.show(that.getMessageBundleText(sMessage));
					that.oGlobalBusyDialog.close();
				});
		},
		/**
		 * Validation method to check if the entered value in combobox field matches with one of the keys
		 * @public
		 * @returns {boolean} the resourceModel of the component
		 */
		validateComboBox: function (oField, sMsgKey) {
			var sSelectedKey = oField.getSelectedKey();
			var sValue = oField.getValue();
			if (!sSelectedKey && sValue) {
				oField.setValueState(sap.ui.core.ValueState.Error);
				oField.setValueStateText(this.getMessageBundleText(sMsgKey));
				return false;
			} else {
				oField.setValueState(sap.ui.core.ValueState.None);
				oField.setValueStateText("");
			}
			return true;
		},
		checkOnSelection: function (oEvent) {
			var oInput = oEvent.getSource();
			var bValid = oInput.getSelectedKey();
			oInput.setValueState(!bValid ? "Error" : "None");
			return bValid;
		},
		_onErrorOdata: function (oError, that) {
			var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
			var sMsg = "";
			for (var i = 1; i < arr.length; i++) {
				sMsg = sMsg + '\n' + arr[i].message + '\n';
			}
			var msgTitle = that.getResourceBundleText("title.errorMessage");
			MessageBox.error(sMsg, {
				title: msgTitle, // default
				onClose: null, // default
				styleClass: "", // default
				actions: sap.m.MessageBox.Action.CLOSE, // default
				emphasizedAction: null, // default
				initialFocus: null, // default
				textDirection: sap.ui.core.TextDirection.Inherit // default
			});
		},
		/**
		 * Validation method to check if the entered value in input field matches with one of the entries
		 * @public
		 * @returns {boolean} the resourceModel of the component
		 */
		validateSuggestions: function (oField, sValue, sKeyName, data, sMsgKey) {
			var found = false;
			for (var i = 0; i < data.length; i++) {
				if (data[i][sKeyName] === sValue) {
					found = true;
				}
			}
			if (!found) {
				oField.setValueState(sap.ui.core.ValueState.Error);
				oField.setValueStateText(this.getMessageBundleText(sMsgKey));
			} else {
				oField.setValueState(sap.ui.core.ValueState.None);
				oField.setValueStateText("");
			}
			return found;
		},

		/**
		 * Validation method to check if value in the provided field is empty
		 * @public
		 * @returns {boolean} the resourceModel of the component
		 */
		validateFieldNotEmpty: function (oField, sMsgKey) {
			var sValue = oField.getValue();
			if (sValue === null || sValue === "") {
				oField.setValueState(sap.ui.core.ValueState.Error);
				oField.setValueStateText(this.getMessageBundleText(sMsgKey));
				// MessageToast.show(this.getMessageBundleText(sMsgKey));
				return false;
			}
			return true;
		},

		/**
		 * Validate field value greater than zero
		 * @public
		 * @returns {boolean}
		 */
		validateGTZero: function (oField, sMsgKey) {
			var sValue = Utility.parseFloatValue(oField.getValue());
			if (sValue <= 0) {
				oField.setValueState(sap.ui.core.ValueState.Error);
				oField.setValueStateText(this.getMessageBundleText(sMsgKey));
				return false;
			} else {
				oField.setValueState(sap.ui.core.ValueState.None);
				oField.setValueStateText("");
			}
			return true;
		},

		resetValueState: function (oField) {
			oField.setValueState(sap.ui.core.ValueState.None);
			oField.setValueStateText("");
		},
		onOnlyInteger: function (oEvent) {
			var value = oEvent.getSource().getValue().replace(/[^\d]/g, '');
			oEvent.getSource().setValue(value);
		},
		onPressCancel: function (oEvt) {
			// var GLSubModel = this.getView().getModel("CCSubModel");
			this._clearScreenValues(this);
			var oModel = new JSONModel();
			oModel.setData({
				"EditFields": true, //all fields
				"EditCompField": true, //compcode
				"EditCCField": true, //costcenter
				"DisplayHier": true,
				"HierMandate": false,
				"DisplayBiz": true,
				"DisplayLock": false
			});
			this.getView().setModel(oModel, "EditModel");
		},
		_FormatDate: function (sDate) {
			if (!sDate) {
				return sDate;
			}
			var sdateformat = DateFormat.getDateTimeInstance({
					pattern: "yyyy.MM.dd"
				},
				sap.ui.getCore().getConfiguration().getLocale());
			var modifieddate = sdateformat.format(sDate, true); // returns: "2020/08/09"
			return modifieddate;
		},
		onPressDeleteSub: function (oEvt) {
			var CCSubModel = this.getView().getModel("CCSubModel");
			this._deleteSubRequest(CCSubModel.getData().data.FimReq, CCSubModel.getData().data.subreqno, oEvt, this);
		},
		trimLeadingZeros: function (sVal) {
			var sResult = "";
			if (sVal) {
				sResult = sVal.replace(/^0+/, '');
				// if only zeros, return one 0
				if (!sResult) {
					sResult = "0";
				}
			}
			return sResult;
		}
	});
});