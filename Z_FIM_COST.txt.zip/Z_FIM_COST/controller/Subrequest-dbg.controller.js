sap.ui.define([
	"./BaseController",
	"../Util/Constants",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast",
	"sap/ui/core/format/DateFormat",
	"../Util/OdataHelper",
	"sap/m/MessageBox",
	"sap/f/library"
], function (BaseController, Constants, JSONModel, Fragment, MessageToast, DateFormat, ODataHelper, MessageBox, fioriLibrary) {
	"use strict";
	return BaseController.extend("FIM.COSTCENTER.CostCenter.controller.Subrequest", {
		onInit: function () {
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			var oOwnerComponent = this.getOwnerComponent();
			this.oRouter = oOwnerComponent.getRouter();
			this.oModel = oOwnerComponent.getModel();
			this.oRouter.getRoute("request").attachPatternMatched(this._onSubrequestMatched, this);
			this.oRouter.getRoute("subrequest").attachMatched(this._onSubrequestMatched, this);
			this._getUserInfo();
			// this._odatareadset(Constants.VALUEHELP_SRV_URL, "/UserInfoSet", "UserModel", "msg.err.UserdetailsError");
		},
		_onSubrequestMatched: function (oEvt) {
			var that = this;
			var oArgument = oEvt.getParameter("arguments");
			var request = oArgument.request;
			//End of conctants
			if (request !== undefined && request !== null && request !== "") {
				var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.COSTCENTER_SRV_URL, false);
				this.oGlobalBusyDialog.open();
				oDataModel.read("/CostCenterHeaderSet('" + request + "')", {
					urlParameters: {
						"$expand": "CCHeadToItemLandNav"
					},
					success: function onSuccess(oData, oResponse) {
						//Store Selection Screen Entries
						var Effdate = "";
						if (oData.Effdate !== undefined && oData.Effdate !== null) {
							Effdate = that._FormatDate(oData.Effdate);
						}
						var oSubModel = new JSONModel();
						var oModel = new JSONModel();
						//pass header data
						oModel.setData({
							"data": {
								"ReqNo": oData.FimReq,
								"CompName": oData.CompName,
								"Dept": oData.Dept,
								"Ernam": oData.Ernam,
								"Zname": oData.Zname,
								"Status": oData.Status,
								"Effdate": Effdate,
								"Erdat": that._FormatDate(new Date())
							}
						});
						var value = oData.CCHeadToItemLandNav;
						//Format data 
						var tDate = "";
						for (var i = 0; i < value.results.length; i++) {
							tDate = value.results[i].Erdat;
							if (tDate !== undefined && tDate !== null) {
								value.results[i].Erdat = that._FormatDate(tDate);
							}
						}
						oSubModel.setData({
							data: value.results
						});
						that.getView().setModel(oModel, "SubReqModel");
						that.getView().setModel(oSubModel, "SubModel");
						that.oGlobalBusyDialog.close();
					},
					error: function onError(oError) {
						that.oGlobalBusyDialog.close();
						MessageToast.show(that.getMessageBundleText("msg.err.SubRequestFetch", []));
					}
				});
			}
		},
		_getUserInfo: function () {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			oDataModel.read("/UserInfoSet", {
				success: function onSuccess(oData, oResponse) {
					var oUserModel = new JSONModel();
					oUserModel.setData({
						data: oData.results
					});
					that.getView().setModel(oUserModel, "UserModel");
					var oModel = new JSONModel();
					if (oData.results[0].Admin === "X") {
						oModel.setData({
							"data": [{
								Object: Constants.CREATE
							}, {
								Object: Constants.MODIFY
							}, {
								Object: Constants.CANCEL
							}]
						});
					} else {
						oModel.setData({
							"data": [{
								Object: Constants.CREATE
							}, {
								Object: Constants.MODIFY
							}]
						});
					}
					that.getView().setModel(oModel, "SubReqGLModel");
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					MessageToast.show(that.getMessageBundleText("msg.err.UserdetailsError", []));
				}
			});
		},
		onCreateSubrequest: function (oEvent) {
			var oView = this.getView();
			var fragmentCreateSubrequest = "FIM.COSTCENTER.CostCenter.view.fragment.CreateSubrequest";
			if (!this.byId("dlg_createsubrequest")) {
				Fragment.load({
					id: oView.getId(),
					name: fragmentCreateSubrequest,
					type: "XML",
					controller: this
				}).then(function (oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
				this._oDialogCreateSubReq = sap.ui.xmlfragment(fragmentCreateSubrequest, this);
			} else {
				this.byId("dlg_createsubrequest").open();
			}
		},
		onValidateCombo: function (oEvent) {
			var bValid = oEvent.getSource().getSelectedKey();
			var sId = oEvent.mParameters.id;
			// var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (!this.checkOnSelection(oEvent)) {
				this.getView().byId(sComboId).setSelectedKey("");
				return;
			} else {
				this.getView().byId(sComboId).setValueState(sap.ui.core.ValueState.None);
				this.getView().byId(sComboId).setValueStateText("");
				return;
			}
		},
		onCloseCreateSubrequest: function (oEvent) {
			this._clearCreateSubrequest();
			this.byId("dlg_createsubrequest").close();
		},
		_clearCreateSubrequest: function () {
			this.getView().byId("cb_Object").setSelectedKey("");
			this.resetValueState(this.getView().byId("cb_Object"));
		},
		onSaveSubrequest: function (oEvent) {
			var oSubModel = this.getView().byId("tbl_subreq").getModel("SubModel");
			var SubReqModel = this.getView().getModel("SubReqModel");
			var that = this;
			var oEntry = {};
			oEntry.FimReq = SubReqModel.getData().data.ReqNo;
			oEntry.SubreqNo = "";
			oEntry.Category = Constants.CC;
			oEntry.Actionid = this.getView().byId("cb_Object").getSelectedKey();
			oEntry.Erdat = this.getView().byId("ip_Creationdate1").getValue();
			var SubReqGLModel = this.getView().getModel("SubReqGLModel").getData().data;
			if (!this.validateSuggestions(this.getView().byId("cb_Object"), oEntry.Actionid, "Object", SubReqGLModel, "")) {
				this.getView().byId("cb_Object").setValueState(sap.ui.core.ValueState.Error);
				return false;
			}
			oEntry.Erdat = this._correctDateFormat(oEntry.Erdat);
			this.oGlobalBusyDialog.open();
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.COSTCENTER_SRV_URL, false);
			ODataHelper.callODataCREATE(oDataModel, "/CostCenterItemSet", oEntry)
				.then(function onSuccess(oResult, oResponse) {
					//Scenario: Submission is successful.
					var items = oSubModel.getProperty("/data");
					var tDate = oResult.Erdat;
					var createdrequest = {
						"FimReq": oResult.FimReq,
						"SubreqNo": oResult.SubreqNo,
						"Category": that.getResourceBundleText("value.costcenter"),
						"Actionid": oResult.Actionid,
						"Erdat": that._FormatDate(tDate)
					};
					items.push(createdrequest);
					oSubModel.setProperty("/data", items);
					sap.ui.getCore().setModel(oSubModel, "SubModel");
					MessageToast.show(that.getMessageBundleText("msg.suc.SubRequestCreate", [oResult.SubreqNo]));
					that.oGlobalBusyDialog.close();
				})
				.catch(function onError(oError) {
					that.oGlobalBusyDialog.close();
					MessageToast.show(that.getMessageBundleText("msg.err.SubmitReqCreateError", []));
					return;
				});
			this._clearCreateSubrequest();
			this.byId("dlg_createsubrequest").close();
		},
		_ParseDate: function (sDate) {
			if (!sDate) {
				return sDate;
			}
			var sdateformat = DateFormat.getDateTimeInstance({
					pattern: "yyyy.MM.dd"
				},
				sap.ui.getCore().getConfiguration().getLocale());
			return sdateformat.parse(sDate); // parse to, for ex: Sat Aug 01 2020 00:00:00 <timezone information,ex:GMT-0400>
		},
		onSubmitRequest: function (oEvent) {
			var that = this;
			var oModel = this.getView().getModel("SubReqModel");
			var oSubModel = this.getView().getModel("SubModel");
			var sMsg = '';
			if (oSubModel === undefined) {
				var sMsg = this.getMessageBundleText("msg.err.NoSubReq", [oModel.getData().data.ReqNo]);
			} else if (oSubModel.getProperty("/data").length === 0) {
				var sMsg = this.getMessageBundleText("msg.err.NoSubReq", [oModel.getData().data.ReqNo]);
			}
			if (sMsg !== '') {
				var msgTitle = this.getResourceBundleText("title.errorMessage");
				MessageBox.error(sMsg, {
					title: msgTitle, // default
					onClose: null, // default
					styleClass: "", // default
					actions: sap.m.MessageBox.Action.CLOSE, // default
					emphasizedAction: null, // default
					initialFocus: null, // default
					textDirection: sap.ui.core.TextDirection.Inherit // default
				});
				return;
			}
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.COSTCENTER_SRV_URL, false);
			var setname = "/CCSubmitSet('" + oModel.getData().data.ReqNo + "')";
			this.oGlobalBusyDialog.open();
			ODataHelper.callODataREAD(oDataModel, setname)
				.then(function onSuccess(oData, oResponse) {
					that.oGlobalBusyDialog.close();
					that._closeSubRequest(that);
					var msg = that.getMessageBundleText("msg.suc.SubmitSuccess", [oModel.getData().data.ReqNo]);
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								return;
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				});
		},
		onSubRequestNavigate: function (oEvent) {
			var sPath = oEvent.getSource().getBindingContextPath(); //spath will return data/rowindex selected
			var iRowIndex = sPath.split('/')[2];
			var oSubReqModel = this.getView().byId("tbl_subreq").getModel("SubModel");
			var ReqModel = this.getView().getModel("SubReqModel");
			var request = ReqModel.getData().data.ReqNo;
			var subreq = oSubReqModel.getData().data[iRowIndex].SubreqNo;
			var object = oSubReqModel.getData().data[iRowIndex].Actionid;
			// var category = oSubReqModel.getData().data[iRowIndex].Category;
			var editvalue;
			var oModel = this.getView().getModel("SubReqModel");
			if (oModel.getData().data.Status === Constants.DRAFT || oModel.getData().data.Status === Constants.DRAFT_FR) {
				editvalue = "1";
			} else {
				editvalue = "2";
			}
			if (object === Constants.CREATE && subreq !== undefined) {
				this.oRouter.navTo("RouteCCCreate", {
					layout: fioriLibrary.LayoutType.EndColumnFullScreen,
					SelectItem: editvalue, //with edit access 1=edit
					request: request,
					SubReq: subreq
				});
			} else if (object === Constants.MODIFY && subreq !== undefined) {
				this.oRouter.navTo("RouteCCModify", {
					layout: fioriLibrary.LayoutType.EndColumnFullScreen,
					SelectItem: editvalue,
					request: request,
					SubReq: subreq
				});
			} else if (object === Constants.CANCEL && subreq !== undefined) {
				this.oRouter.navTo("RouteCCCancel", {
					layout: fioriLibrary.LayoutType.EndColumnFullScreen,
					SelectItem: editvalue,
					request: request,
					SubReq: subreq
				});
			}
		},
		onDeleteRequest: function (oEvt) {
			var request = this.getView().getModel("SubReqModel").getData().data.ReqNo;
			var setname = "/CostCenterHeaderSet('" + request + "')";
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.COSTCENTER_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			var that = this;
			oDataModel.remove(setname, {
				method: "DELETE",
				success: function (data) {
					that.oGlobalBusyDialog.close();
					var msg = that.getMessageBundleText("msg.suc.DeleteRequest", [request]);
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								that._closeSubRequest(that);
								return;
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				},
				error: function (e) {
					MessageToast.show(that.getMessageBundleText("msg.err.DeleteRequestError", [request]));
					that.oGlobalBusyDialog.close();
				}
			});
		},
		_closeSubRequest: function (that) {
			var sNextLayout = fioriLibrary.LayoutType.OneColumn;
			that.oRouter.navTo("request", {
				layout: sNextLayout
			});
		},
		onPressClose: function (oEvt) {
			this._closeSubRequest(this);
		}
	});
});