sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"../Util/OdataHelper",
	"../Util/Constants",
	"../Util/Utility"
], function (BaseController, MessageBox, JSONModel, Filter, MessageToast, Fragment, ODataHelper, Constants, Utility) {
	"use strict";

	return BaseController.extend("FIM.COSTCENTER.CostCenter.controller.CCCancel", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf FIM.COSTCENTER.CostCenter.view.CCCancel
		 */
		onInit: function () {
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			this.oGlobalBusyDialog.open();
			// // Router login
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteCCCancel").attachMatched(this._onRouteFound, this);
			// this._loadBSValue();
			this.oGlobalBusyDialog.close();
		},
		_onRouteFound: function (oEvt) {
			var oArgument = oEvt.getParameter("arguments");
			var oModel = new JSONModel();
			//Company code drop down
			var oFilter = [];
			if ((oArgument.SelectItem === Constants.EDITREQUEST)) {
				oFilter.push(new sap.ui.model.Filter("CostCenterCheckox", "EQ", "YES"));
				oModel.setData({
					"EditFields": true,
					"EditCompField": true, //compcode
					"EditCCField": true //costcenter
				});
			} else {
				oFilter.push(new sap.ui.model.Filter("CostCenterCheckox", "EQ", "SUB"));
				oModel.setData({
					"EditFields": false,
					"EditCompField": false,
					"EditCCField": false
				});
			}
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/TCompCodeSet", "CompModel", "msg.err.CompFetchError", oFilter);
			this.getView().setModel(oModel, "EditModel");
			if (oArgument.SubReq !== undefined && oArgument.SubReq !== "") {
				var oCCSubModel = new JSONModel();
				oCCSubModel.setData({
					"data": {
						"FimReq": oArgument.request,
						"subreqno": oArgument.SubReq
					}
				});
				this.getView().setModel(oCCSubModel, "CCSubModel");
				//load existing data of the Subrequest which is already saved in the table
				this._loadsubrequest(oArgument.request, oArgument.SubReq, Constants.COSTCENTER_SRV_URL, oArgument.SelectItem);
			}
		},
		_loadsubrequest: function (request, subrequest, sURL) {
			var oModel = this.getView().getModel("EditModel");
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			this.oGlobalBusyDialog.open();
			oDataModel.read("/CostCenterItemSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')", {

				success: function onSuccess(oData, oResponse) {
					var fmdt = that._FormatDate(oData.ValidFrom);
					var todt = that._FormatDate(oData.ValidTo);
					that.getView().byId("cb_compcode").setSelectedKey(oData.CompCode);
					that.getView().byId("ip_controlarea").setValue(oData.CtrlArea);
					that.getView().byId("ip_costcenter").setValue(oData.CostCenter);
					that.getView().byId("ip_validfrom").setValue(fmdt);
					that.getView().byId("ip_validto").setValue(todt);
					that.getView().byId("ip_explain").setValue(oData.Explanation);
					that.getView().byId("ip_nameen").setValue(oData.TitleEn);
					that.getView().byId("ip_namefr").setValue(oData.TitleFr);
					that.getView().byId("ip_descen").setValue(oData.LtextEn);
					that.getView().byId("ip_descfr").setValue(oData.LtextFr);
					that.getView().byId("ip_notes").setValue(oData.Notes);

					if (oData.CostCenter !== undefined && oData.CostCenter !== null && oData.CostCenter !== "") {
						oModel.setProperty("/EditCCField", false);
						oModel.setProperty("/EditCompField", false);
						that.getView().setModel(oModel, "EditModel");
					}
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "CCSubModel");
					MessageToast.show(that.getMessageBundleText("msg.err.subreqFetchError", [subrequest]));

				}
			});

		},
		onSubmitManualCC: function (oEvent) {
			var cc = this.getView().byId("ip_costcenter").getValue();
			var control = this.getView().byId("ip_controlarea").getValue();
			var comp = this.getView().byId("cb_compcode").getSelectedKey();
			if (control === undefined || control === null || control === "") {
				this.getView().byId("cb_compcode").setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(this.getMessageBundleText("msg.val.CompCode"));
				return;
			} else {
				this.resetValueState(this.getView().byId("cb_compcode"));
			}
			this.oGlobalBusyDialog.open();
			var oModel = this.getView().getModel("EditModel");
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.COSTCENTER_SRV_URL, false);
			var setname = "/CostCenterModifySet(FimReq='',SubreqNo='',Actionid='',CostCenter='" + cc + "',CompCode='" + comp + "',CtrlArea='" +
				control + "')";
			oDataModel.read(setname, {
				success: function onSuccess(oData, oResponse) {
					var fmdt = that._FormatDate(oData.ValidFrom);
					var todt = that._FormatDate(oData.ValidTo);
					that.getView().byId("ip_validfrom").setValue(fmdt);
					that.getView().byId("ip_validto").setValue(todt);
					that.getView().byId("ip_nameen").setValue(oData.FromTen);
					that.getView().byId("ip_namefr").setValue(oData.FromTfr);
					that.getView().byId("ip_descen").setValue(oData.FromLte);
					that.getView().byId("ip_descfr").setValue(oData.FromLfr);

					oModel.setProperty("/EditCCField", false);
					that.getView().setModel(oModel, "EditModel");

					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					// MessageToast.show("Rac Code does not exist");
					that.oGlobalBusyDialog.close();
				}
			});
		},
		onPressSaveCancel: function (oEvt) {
			var oCCSubModel = this.getView().getModel("CCSubModel");
			var oEntry = {};
			oEntry.FimReq = oCCSubModel.getData().data.FimReq;
			oEntry.SubreqNo = oCCSubModel.getData().data.subreqno;
			oEntry.Actionid = Constants.CANCEL;
			oEntry.Category = "CC";
			oEntry.CtrlArea = this.getView().byId("ip_controlarea").getValue();
			oEntry.CostCenter = this.getView().byId("ip_costcenter").getValue();
			oEntry.CompCode = this.getView().byId("cb_compcode").getSelectedKey();
			if (oEntry.CompCode === undefined || oEntry.CompCode === "" || oEntry.CompCode === null || oEntry.CtrlArea === undefined || oEntry.CtrlArea ===
				"" || oEntry.CtrlArea === null || oEntry.CostCenter === undefined || oEntry.CostCenter === "" || oEntry.CostCenter === null
			) {
				MessageToast.show(this.getMessageBundleText("msg.Val.Mandatory"));
				return;
			}
			oEntry.Explanation = this.getView().byId("ip_explain").getValue();
			oEntry.TitleEn = this.getView().byId("ip_nameen").getValue();
			oEntry.TitleFr = this.getView().byId("ip_namefr").getValue();
			oEntry.LtextEn = this.getView().byId("ip_descen").getValue();
			oEntry.LtextFr = this.getView().byId("ip_descfr").getValue();
			oEntry.Notes = this.getView().byId("ip_notes").getValue();

			var ValidFrom = this.getView().byId("ip_validfrom").getValue();
			var ValidTo = this.getView().byId("ip_validto").getValue();

			if (ValidFrom !== undefined && ValidFrom !== null && ValidFrom !== "") {
				oEntry.ValidFrom = this._correctDateFormat(ValidFrom);
			}

			if (ValidTo !== undefined && ValidTo !== null && ValidTo !== "") {
				oEntry.ValidTo = this._correctDateFormat(ValidTo);
			}

			var subModel = this.getView().getModel("CCSubModel");
			var that = this;

			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.COSTCENTER_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			var setname = "/CostCenterItemSet(FimReq='" + oCCSubModel.getData().data.FimReq + "',SubreqNo='" + oCCSubModel.getData().data.subreqno +
				"')";
			ODataHelper.callODataUPDATE(oDataModel, setname, oEntry)
				.then(function onSuccess(oResult, oResponse) {
					that.oGlobalBusyDialog.close();
					that._clearScreenValues(that);
					var msg = that.getMessageBundleText("msg.success.submitForm", [subModel.getData().data.subreqno]);
					//Show success message and return to 1st screen
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								that.onNavigateBack(oEvt, that, subModel.getData().data.FimReq, "RouteCCCancel");
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				});
		},
		onChangeCCComp: function (oEvent) {
			var Comp = oEvent.getSource().getSelectedKey();
			if (!this.checkOnSelection(oEvent)) {
				return;
			} else {
				this.getView().byId("cb_compcode").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("cb_compcode").setValueStateText("");
			}
			this.oGlobalBusyDialog.open();
			var oModel = this.getView().getModel("EditModel");
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			var setname = "/CCCtrlAreaSet('" + Comp + "')";
			oDataModel.read(setname, {
				success: function onSuccess(oData, oResponse) {
					that.getView().byId("ip_controlarea").setValue(oData.ExKokrs);
					//make compcode field not editable as soon as its choosen
					oModel.setProperty("/EditCompField", false);
					that.getView().setModel(oModel, "EditModel");
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that._onErrorOdata(oError);
					that.oGlobalBusyDialog.close();
					return;
				}
			});
		},
		_clearScreenValues: function (that) {
			this.resetValueState(this.getView().byId("cb_compcode"));
			that.resetValueState(that.getView().byId("ip_costcenter"));
			var oCancelModel = this.getView().getModel("CCSubModel");
			//Account Tab
			that.getView().byId("ip_controlarea").setValue("");
			that.getView().byId("ip_costcenter").setValue("");
			that.getView().byId("ip_validfrom").setValue("");
			that.getView().byId("ip_validto").setValue("");
			that.getView().byId("ip_explain").setValue("");
			that.getView().byId("cb_compcode").setSelectedKey("");
			//Description Tab
			that.getView().byId("ip_nameen").setValue("");
			that.getView().byId("ip_namefr").setValue("");
			that.getView().byId("ip_descen").setValue("");
			that.getView().byId("ip_descfr").setValue("");
			that.getView().byId("ip_notes").setValue("");
			//set the first tab as default
			that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
			that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
			that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
		},
		onPressCancel: function (oEvt) {
			var CCSubModel = this.getView().getModel("CCSubModel");
			this._clearScreenValues(this);
			var oModel = new JSONModel();
			oModel.setData({
				"EditFields": true,
				"EditCompField": true,
				"EditCCField": true
			});
			this.getView().setModel(oModel, "EditModel");
		},
		onNavBack: function (oEvt) {
				var subModel = this.getView().getModel("CCSubModel");
				var request = subModel.getData().data.FimReq;
				this._clearScreenValues(this);
				this.onNavigateBack(oEvt, this, request, "RouteCCCancel");
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf FIM.COSTCENTER.CostCenter.view.CCCancel
			 */
			//           onBeforeRendering: function() {
			//
			//           },

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf FIM.COSTCENTER.CostCenter.view.CCCancel
		 */
		//           onAfterRendering: function() {
		//
		//           },

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf FIM.COSTCENTER.CostCenter.view.CCCancel
		 */
		//           onExit: function() {
		//
		//           }

	});

});