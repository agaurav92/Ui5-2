sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast",
	"../Util/OdataHelper",
	"../Util/Constants"
], function (BaseController, MessageBox, Filter, JSONModel, Fragment, MessageToast, ODataHelper, Constants) {
	"use strict";
	return BaseController.extend("FIM.COSTCENTER.CostCenter.controller.CCCreate", {
		onInit: function () {
			//Initialize busy indicator
			this.oGlobalBusyDialog = new sap.m.BusyDialog();
			this.oGlobalBusyDialog.open();
			// Router login
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteCCCreate").attachMatched(this._onRouteFound, this);
			//Category drop down
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/CCCategorySet", "CategoryModel", "msg.err.CategoryFetchError");
			// Department drop down
			// this._odatareadset(Constants.VALUEHELP_SRV_URL, "/CCDeptSet", "DepartmentModel", "msg.err.DeptFetchError");
			this.oGlobalBusyDialog.close();
		},
		_onRouteFound: function (oEvt) {
			//Company code drop down
			var oFilter = [];
			var oArgument = oEvt.getParameter("arguments");
			var oModel = new JSONModel();
			if ((oArgument.SelectItem === Constants.EDITREQUEST)) {
				oFilter.push(new sap.ui.model.Filter("CostCenterCheckox", "EQ", "YES"));
				oModel.setData({
					"EditFields": true, //all fields
					"EditCompField": true, //compcode
					"EditCCField": true, //costcenter
					"DisplayHier": true,
					"EditHierdesc": true,
					"DisplayBiz": true
				});
			} else {
				oFilter.push(new sap.ui.model.Filter("CostCenterCheckox", "EQ", "SUB"));
				oModel.setData({
					"EditFields": false,
					"EditCompField": false,
					"EditCCField": false,
					"DisplayHier": false,
					"EditHierdesc": false,
					"DisplayBiz": false
				});
			}
			this._odatareadset(Constants.VALUEHELP_SRV_URL, "/TCompCodeSet", "CompModel", "msg.err.CompFetchError", oFilter);
			this.getView().setModel(oModel, "EditModel");
			if (oArgument.SubReq !== undefined && oArgument.SubReq !== "") {
				var oCCSubModel = new JSONModel();
				oCCSubModel.setData({
					"data": {
						"FimReq": oArgument.request,
						"subreqno": oArgument.SubReq
					}
				});
				this.getView().setModel(oCCSubModel, "CCSubModel");
				//load existing data of the Subrequest which is already saved in the table
				this._loadsubrequest(oArgument.request, oArgument.SubReq, Constants.COSTCENTER_SRV_URL, oArgument.SelectItem);
			}
		},
		_loadsubrequest: function (request, subrequest, sURL) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			this.oGlobalBusyDialog.open();
			oDataModel.read("/CostCenterItemSet(FimReq='" + request + "',SubreqNo='" + subrequest + "')", {
				success: function onSuccess(oData, oResponse) {
					//Store Selection Screen Entries
					var oModel = new JSONModel();
					oModel.setData({
						"TitleEn": oData.TitleEn,
						"TitleFr": oData.TitleFr,
						"LtextEn": oData.LtextEn,
						"LtextFr": oData.LtextFr,
						"Department": oData.Department,
						"CostCategory": oData.CostCategory,
						"PersResp": oData.PersResp,
						"Biztype": oData.Biztype,
						"Bizflag": oData.Bizflag,
						"NotesBiz": oData.NotesBiz,
						"Explanation": oData.Explanation,
						"HierArea": oData.HierArea,
						"NotesHier": oData.NotesHier,
						"HierDesc": oData.HierDesc,
						"RecycleCode": oData.RecycleCode,
						"Notes": oData.Notes
					});
					that.getView().byId("cb_compcode").setSelectedKey(oData.CompCode);
					that.getView().byId("ip_controlarea").setValue(oData.CtrlArea);
					that.getView().byId("ip_costcenter").setValue(oData.CostCenter);
					that.getView().byId("ip_validfrom").setValue(that._FormatDate(oData.ValidFrom));
					// that.getView().byId("ip_validto").setValue(that._FormatDate(oData.ValidTo));

					that.getView().setModel(oModel, "CostCtrCreateModel");
					if (oData.CompCode !== undefined && oData.CompCode !== null && oData.CompCode !== "") {
						that._setEditModel(oData.Bizflag, that);
					}
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that.oGlobalBusyDialog.close();
					var oModel = new JSONModel();
					that.getView().setModel(oModel, "CostCtrCreateModel");
					MessageToast.show(that.getMessageBundleText("msg.err.subreqFetchError", [subrequest]));

				}
			});
		},
		//Set Edit Model
		_setEditModel: function (biztype, that) {
			var oEditModel = that.getView().getModel("EditModel");
			var CompCode = that.getView().byId("cb_compcode").getSelectedKey();
			var CostCenter = that.getView().byId("ip_costcenter").getValue();
			//check control area
			if (CompCode !== undefined && CompCode !== null && CompCode !== "") {
				oEditModel.setProperty("/EditCompField", false);
			} else {
				oEditModel.setProperty("/EditCompField", true);
			}

			if (CostCenter !== undefined && CostCenter !== null && CostCenter !== "") {
				oEditModel.setProperty("/EditCCField", false);
			} else {
				oEditModel.setProperty("/EditCCField", true);
			}
			//Biz type details
			if (biztype === "X") {
				oEditModel.setProperty("/DisplayBiz", true);
			} else {
				oEditModel.setProperty("/DisplayBiz", false);
			}
			that.getView().setModel(oEditModel, "EditModel");
		},

		_odatareadset: function (sURL, osetName, oModelName, sMessage, ofilter) {
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(sURL, false);
			that.oGlobalBusyDialog.open();
			ODataHelper.callODataREAD(oDataModel, osetName, ofilter)
				.then(function onSuccess(oData, oResponse) {
					var oModel = new JSONModel();
					oModel.setData({
						data: oData.results
					});
					that.getView().setModel(oModel, oModelName);
					that.oGlobalBusyDialog.close();
				})
				.catch(function onError(oError) {
					MessageToast.show(that.getMessageBundleText(sMessage));
					that.oGlobalBusyDialog.close();
				});
		},
		//Cost Center Validation
		onSubmitManualCC: function (oEvent) {
			var control = this.getView().byId("ip_controlarea").getValue();
			if (control === undefined || control === null || control === "") {
				this.getView().byId("cb_compcode").setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText("msg.val.CompCode"));
				return;
			} else {
				this.resetValueState(this.getView().byId("cb_compcode"));
			}
			var costctr = this.getView().byId("ip_costcenter").getValue();
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			var oCCCreateModel = this.getView().getModel("CostCtrCreateModel");
			var setname = "/CCtrValidSet(ImCctr='" + costctr + "',ImKokrs='" + control + "')";
			this.oGlobalBusyDialog.open();
			oDataModel.read(setname, {
				success: function (oData, response) {
					oCCCreateModel.setProperty("/RecycleCode", "");
					that.getView().setModel(oCCCreateModel, "CCCreateModel");
					var oModel = that.getView().getModel("EditModel");
					oModel.setProperty("/EditCCField", false);
					that.getView().setModel(oModel, "EditModel");
					// that._setEditModel(that);
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
				}
			});
		},

		_validateCC: function (contarea, msg, that) {
			if (contarea === undefined || contarea === null || contarea === "") {
				that.getView().byId("cb_compcode").setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(that.getMessageBundleText(msg));
				return;
			} else {
				this.resetValueState(this.getView().byId("cb_compcode"));
			}
		},

		//Hierarchy Description
		onChangeHier: function (oEvt) {
			var value = this.getView().byId("ip_hierarea").getValue();
			var splitid = value.split(' '); //id name
			if (splitid.length > 1) {
				this.getView().byId("ip_hierarea").setValue("");
				MessageToast.show(this.getMessageBundleText("msg.val.hier"));
				this.getView().byId("ip_hierarea").setValueState(sap.ui.core.ValueState.Error);
				return;
			} else {
				this.resetValueState(this.getView().byId("ip_hierarea"));
			}
			var coa = this.getView().byId("ip_controlarea").getValue();
			if (value !== undefined && value !== "" && value !== null && coa !== undefined && coa !== null && coa !== "") {
				var that = this;
				var oModel = this.getView().getModel("EditModel");
				var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
				that.oGlobalBusyDialog.open();
				var setname = "/CCHierSet(HierArea='" + value + "',Kokrs='" + coa + "')";
				oDataModel.read(setname, {
					success: function onSuccess(oData, oResponse) {
						that.getView().byId("ip_hdesc").setValue(oData.Desc);
						that.getView().byId("ip_hierarea").setValue(oData.HierArea);

						that.oGlobalBusyDialog.close();
					},
					error: function onError(oError) {
						that.oGlobalBusyDialog.close();
						var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
						var sVal = "";
						for (var i = 1; i < arr.length; i++) {
							sVal = sVal + "\n" + arr[i].message + "\n";
						}
						var msgTitle = that.getResourceBundleText("title.errorMessage");
						sap.m.MessageBox.error(sVal, {
							title: msgTitle, // default
							onClose: null, // default
							styleClass: "", // default
							actions: sap.m.MessageBox.Action.CLOSE, // default
							emphasizedAction: null, // default
							initialFocus: null, // default
							textDirection: sap.ui.core.TextDirection.Inherit // default
						});

					}
				});
			}

		},

		//Combobox validations
		onValidateCombo: function (oEvent) {
			var bValid = oEvent.getSource().getSelectedKey();
			var sId = oEvent.mParameters.id;
			var value = oEvent.mParameters.value;
			var sComboId = sId.split('-')[2]; //id name
			if (value !== "") {
				if (!this.checkOnSelection(oEvent)) {
					return;
				}
			} else {
				this.getView().byId(sComboId).setValueState(sap.ui.core.ValueState.None);
				this.getView().byId(sComboId).setValueStateText("");
			}
		},

		// For Onpress of Recycled Cost Center
		onPressRecycleCost: function (oEvent) {
			var oView = this.getView();
			var fragmentSearchCostCenter = "FIM.COSTCENTER.CostCenter.view.fragment.SearchCostCenter";
			var coa = this.getView().byId("ip_controlarea").getValue();
			if (coa !== undefined && coa !== null && coa !== "") {
				this.oGlobalBusyDialog.open();
				if (!this.byId("dlg_searchcostcenter")) {
					Fragment.load({
						id: oView.getId(),
						name: fragmentSearchCostCenter,
						type: "XML",
						controller: this
					}).then(function (oDialog) {
						oView.addDependent(oDialog);
						oDialog.open();
					});
					this._oDialogSearchCostCenter = sap.ui.xmlfragment(fragmentSearchCostCenter, this);
				} else {
					this.byId("dlg_searchcostcenter").open();
					this.getView().byId("ip_recyclecc").setValue("");
				}
				this.oGlobalBusyDialog.close();
			} else {
				MessageToast.show(this.getMessageBundleText("msg.val.CompCode", []));
			}
		},

		onF4CostCenter: function (oEvent) {
			var costctr = oEvent.getSource().getValue();
			this.resetValueState(this.getView().byId("ip_recyclecc"));
			//Call Odata to fill the Cost Center search table
			var that = this;
			var control = that.getView().byId("ip_controlarea").getValue();
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			var oFilter = [];

			oFilter.push(new sap.ui.model.Filter("ImKostl", "EQ", costctr));
			oFilter.push(new sap.ui.model.Filter("ImKokrs", "EQ", control));
			oFilter.push(new sap.ui.model.Filter("Bukrs", "EQ", that.getView().byId("cb_compcode").getSelectedKey()));
			this.oGlobalBusyDialog.open();
			oDataModel.read("/CCRecycledSet", {
				async: false,
				filters: oFilter,
				success: function (oData, response) {
					var oCCsearchModel = new sap.ui.model.json.JSONModel();
					oCCsearchModel.setData({
						data: oData.results
					});
					that.getView().byId("tbl_costcentersearch").setVisible((oData.results.length > 0));
					that.getView().byId("tbl_costcentersearch").setModel(oCCsearchModel, "CostctrSearchModel");
					that.oGlobalBusyDialog.close();
				},
				error: function (oError) {
					that.getView().byId("ip_recyclecc").setValue("");
					that.getView().byId("ip_recyclecc").setValueState(sap.ui.core.ValueState.Error);
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sVal = "";
					for (var i = 1; i < arr.length; i++) {
						sVal = sVal + "\n" + arr[i].message + "\n";
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					sap.m.MessageBox.error(sVal, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
				}
			});
		},
		//Onselection of select cost center from value help
		onSelectSearchCost: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var sSelectedCC = oSelectedItem.getCells()[0].getText();
			var oCCCreateModel = this.getView().getModel("CostCtrCreateModel");
			if (typeof sSelectedCC !== "undefined" && sSelectedCC !== null && sSelectedCC !== "") {
				this.getView().byId("ip_recyclecc").setValue(sSelectedCC);
				oCCCreateModel.setProperty("/RecycleCode", "X");
				this.getView().byId("ip_costcenter").setValue(sSelectedCC);
				// this.getView().setModel(oCCCreateModel, "CostCtrCreateModel");
				// this._setEditModel(this);
				var oModel = this.getView().getModel("EditModel");
				oModel.setProperty("/EditCCField", false);
				this.getView().setModel(oModel, "EditModel");
				this._clearF4CostCenter();
				this.byId("dlg_searchcostcenter").close();
			} else {
				MessageToast.show(that.getMessageBundleText("msg.err.InvalidCC", []));
			}
		},
		//Clear all variables from Search costcenter fragment
		_clearF4CostCenter: function () {
			this.resetValueState(this.getView().byId("ip_recyclecc"));
			this.getView().byId("ip_recyclecc").setValue("");
			this.getView().byId("ms_searchcostcenter").setVisible(false);
			this.byId("tbl_costcentersearch").setVisible(false);
			var oModel = new sap.ui.model.json.JSONModel();
			// this.byId("tbl_costcentersearch").setModel(oModel);
			this.byId("tbl_costcentersearch").setModel(oModel, "CostctrSearchModel");
		},

		onChangeCCComp: function (oEvent) {
			var Comp = oEvent.getSource().getSelectedKey();
			if (!this.checkOnSelection(oEvent)) {
				return;
			} else {
				this.getView().byId("cb_compcode").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("cb_compcode").setValueStateText("");
			}
			this.oGlobalBusyDialog.open();
			var oModel = this.getView().getModel("EditModel");
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.VALUEHELP_SRV_URL, false);
			var setname = "/CCCtrlAreaSet('" + Comp + "')";
			oDataModel.read(setname, {
				success: function onSuccess(oData, oResponse) {
					that.getView().byId("ip_controlarea").setValue(oData.ExKokrs);
					if (oData.ExKokrs !== undefined && oData.ExKokrs !== null && oData.ExKokrs !== "") {
						var oCreateModel = that.getView().getModel("CostCtrCreateModel");
						oCreateModel.setProperty("/Bizflag", oData.ExFlag);
						that.getView().setModel(oCreateModel, "CostCtrCreateModel");
						if (oData.ExFlag === "X") {
							oModel.setProperty("/DisplayBiz", true);
						} else {
							oModel.setProperty("/DisplayBiz", false);
						}
						//make compcode field not editable as soon as its choosen
						oModel.setProperty("/EditCompField", false);
						that.getView().setModel(oModel, "EditModel");
					}
					that.oGlobalBusyDialog.close();
				},
				error: function onError(oError) {
					that._onErrorOdata(oError, that);
					that.oGlobalBusyDialog.close();
					return;
				}
			});
		},
		//For Save Buttons
		onPressSaveCC: function (oEvt) {
			var oEntry = {};
			var SubModel = this.getView().getModel("CCSubModel");
			var oCCCreateModel = this.getView().getModel("CostCtrCreateModel");
			var value = this.getView().byId("ip_hierarea").getValue();
			var splitid = value.split(' '); //id name
			if (splitid.length > 1) {
				this.getView().byId("ip_hierarea").setValue("");
				this.getView().byId("ip_hierarea").setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(this.getMessageBundleText("msg.val.hier"));
				return;
			} else {
				this.resetValueState(this.getView().byId("ip_hierarea"));
			}
			// Account Tab
			oEntry.FimReq = SubModel.getData().data.FimReq;
			oEntry.SubreqNo = SubModel.getData().data.subreqno;
			oEntry.Actionid = Constants.CREATE;
			oEntry.Category = Constants.CC;
			//Basic Tab details
			oEntry.CompCode = this.getView().byId("cb_compcode").getSelectedKey();
			oEntry.CtrlArea = this.getView().byId("ip_controlarea").getValue();
			oEntry.CostCenter = this.getView().byId("ip_costcenter").getValue();
			if (oEntry.CompCode === undefined || oEntry.CompCode === "" || oEntry.CompCode === null || oEntry.CtrlArea === undefined || oEntry.CtrlArea ===
				"" || oEntry.CtrlArea === null || oEntry.CostCenter === undefined || oEntry.CostCenter === "" || oEntry.CostCenter === null
			) {
				MessageToast.show(this.getMessageBundleText("msg.Val.Mandatory"));
				return;
			}
			var ValidFrom = this.getView().byId("ip_validfrom").getValue();
			if (ValidFrom !== undefined && ValidFrom !== null && ValidFrom !== "") {
				oEntry.ValidFrom = this._correctDateFormat(ValidFrom);
			}

			oEntry.ValidTo = this._correctDateFormat(this.getView().byId("ip_validto").getValue());
			oEntry.RecycleCode = oCCCreateModel.getData().RecycleCode;
			oEntry.TitleEn = oCCCreateModel.getData().TitleEn;
			oEntry.TitleFr = oCCCreateModel.getData().TitleFr;
			oEntry.LtextEn = oCCCreateModel.getData().LtextEn;
			oEntry.LtextFr = oCCCreateModel.getData().LtextFr;
			oEntry.Department = oCCCreateModel.getData().Department;
			oEntry.CostCategory = oCCCreateModel.getData().CostCategory;
			oEntry.PersResp = oCCCreateModel.getData().PersResp;
			oEntry.Bizflag = oCCCreateModel.getData().Bizflag;
			oEntry.Biztype = oCCCreateModel.getData().Biztype;
			oEntry.NotesBiz = oCCCreateModel.getData().NotesBiz;
			oEntry.Explanation = oCCCreateModel.getData().Explanation;
			//Hierarchy Tab
			oEntry.HierArea = oCCCreateModel.getData().HierArea;
			oEntry.HierDesc = oCCCreateModel.getData().HierDesc;
			oEntry.NotesHier = oCCCreateModel.getData().NotesHier;
			oEntry.Notes = oCCCreateModel.getData().Notes;
			// var subModel = this.getView().getModel("CCSubModel");
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(Constants.COSTCENTER_SRV_URL, false);
			this.oGlobalBusyDialog.open();
			var setname = "/CostCenterItemSet(FimReq='" + SubModel.getData().data.FimReq + "',SubreqNo='" + SubModel.getData().data.subreqno +
				"')";
			ODataHelper.callODataUPDATE(oDataModel, setname, oEntry)
				.then(function onSuccess(oResult, oResponse) {
					that.oGlobalBusyDialog.close();
					that._clearScreenValues(that);
					var msg = that.getMessageBundleText("msg.success.submitForm", [SubModel.getData().data.subreqno]);
					//Show success message and return to 1st screen
					MessageBox.success(msg, {
						title: that.getResourceBundleText("title.information"), // default
						onClose: function (sButton) {
							if (sButton === MessageBox.Action.OK) {
								that.onNavigateBack(oEvt, that, SubModel.getData().data.FimReq, "RouteCCCreate");
							}
						}, // default
						styleClass: "", // default
						actions: MessageBox.Action.OK, // default
						emphasizedAction: MessageBox.Action.OK, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
				})
				.catch(function onError(oError) {
					var arr = JSON.parse(oError.responseText).error.innererror.errordetails;
					var sMsg = "";
					for (var i = 1; i < arr.length; i++) {
						sMsg = sMsg + '\n' + arr[i].message + '\n';
					}
					var msgTitle = that.getResourceBundleText("title.errorMessage");
					MessageBox.error(sMsg, {
						title: msgTitle, // default
						onClose: null, // default
						styleClass: "", // default
						actions: sap.m.MessageBox.Action.CLOSE, // default
						emphasizedAction: null, // default
						initialFocus: null, // default
						textDirection: sap.ui.core.TextDirection.Inherit // default
					});
					that.oGlobalBusyDialog.close();
					return;
				});
		},

		onPressCancel: function (oEvt) {
			this._clearScreenValues(this);
		},

		_clearScreenValues: function (that) {
			that._resetvaluestatus(that);

			var oCCCreateModel = new JSONModel();
			oCCCreateModel.setData({
				"TitleEn": "",
				"TitleFr": "",
				"LtextEn": "",
				"LtextFr": "",
				"Department": "",
				"CostCategory": "",
				"PersResp": "",
				"Biztype": "",
				"Bizflag": "",
				"NotesBiz": "",
				"Explanation": "",
				"HierArea": "",
				"NotesHier": "",
				"HierDesc": "",
				"RecycleCode": "",
				"Notes": ""
			});
			that.getView().setModel(oCCCreateModel, "CostCtrCreateModel");
			// Basic Tab
			that.getView().byId("cb_compcode").setSelectedKey("");
			that.getView().byId("ip_controlarea").setValue("");
			that.getView().byId("ip_costcenter").setValue("");
			that.getView().byId("ip_validfrom").setValue("");

			var oEditModel = that.getView().getModel("EditModel");
			oEditModel.setProperty("/EditCCField", true);
			oEditModel.setProperty("/EditCompField", true);
			that.getView().setModel(oEditModel, "EditModel");

			//set the first tab as default
			that.oObjectPageLayout = that.getView().byId("ObjectPageLayout");
			that.oinitial = that.getView().byId("OPS_account"); //section name not the subsection
			that.oObjectPageLayout.setSelectedSection(that.oinitial.getId());
		},

		_resetvaluestatus: function (that) {
			that.resetValueState(that.getView().byId("cb_compcode"));
			that.resetValueState(that.getView().byId("ip_costcenter"));
			that.resetValueState(that.getView().byId("cb_dept"));
			that.resetValueState(that.getView().byId("cb_category"));
			that.resetValueState(that.getView().byId("ip_biz"));
			that.resetValueState(that.getView().byId("ip_notehier"));
			that.resetValueState(that.getView().byId("ip_hierarea"));
		},

		onCloseF4CostCenter: function (oEvent) {
			this._clearF4CostCenter();
			this.byId("dlg_searchcostcenter").close();
		},

		onNavBack: function (oEvt) {
			var subModel = this.getView().getModel("CCSubModel");
			var request = subModel.getData().data.FimReq;
			this._clearScreenValues(this);
			this.onNavigateBack(oEvt, this, request, "RouteCCCreate");
		}

	});
});